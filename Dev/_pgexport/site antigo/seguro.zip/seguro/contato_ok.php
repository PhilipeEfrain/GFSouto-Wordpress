<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


//if ($_POST['email_contato'] == "") {} else {  ////// fim verifica e-mail vazio

//////// SELECIONANDO E-MAIL DE CONTATO PRINCIPAL ////////

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_emailprincipal = "SELECT * FROM email_contato ORDER BY email_contato";
$emailprincipal = mysql_query($query_emailprincipal, $gf_souto_conect) or die(mysql_error());
$row_emailprincipal = mysql_fetch_assoc($emailprincipal);
$totalRows_emailprincipal = mysql_num_rows($emailprincipal);

/////////////// RECUPERANDO DADOS DO FORM ////////////////


  // $nome_empresa = htmlentities(@$_POST['nomema']);
   $nome = $_POST['nome_contato'];
   $email_1 = $_POST['email_contato'];
   $email_2 = $_POST['email_contato'];
   $telefone = $_POST['telefone_contato'];
   
   $condominio = $_POST['condominio'];
   $unidade = $_POST['unidade'];
   $assunto = $_POST['assunto'];
   $mensagem = $_POST['mensagem_contato'];
   
    
 
//////////////////////// INICIO DO CADASTRO NO BANCO DE DADOS //////////////////////////
	  
	// se o e-mail n�o existir cadastra o nome, email 1 e e-mail 2 no banco de dados
	$insertSQL = sprintf("INSERT INTO informativo (nome, email_1, email_2, fone) VALUES (%s, %s, %s, %s)",
						   GetSQLValueString($nome, "text"),
						   GetSQLValueString($email_1, "text"),
						   GetSQLValueString($email_2, "text"),
						   GetSQLValueString($telefone, "text"));
	
	mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
	$Result1 = mysql_query($insertSQL, $gf_souto_conect) or die(mysql_error());
	
	
/////////////////////////// FIM DO CADASTRO NO BANCO DE DADOS //////////////////////////


/////////////////////// ENVIANDO E-MAIL PARA O SETOR RESPONS�VEL ///////////////////////
$email_cadastrado = $row_emailprincipal['email_contato'];
////////////////////////////////////////////////////////////////////////////////////////

/* Destinat�rio */ 
$to = $email_cadastrado ; 
/* Assunto */ 
$subject = "Contato - GF Souto"; 
/* Mensagem */ 
$message = '<table width="600" border="0" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="4" color="#000000">GF SOUTO</font><font face="Arial, Helvetica, sans-serif" size="4" color="#000000"><br />
          Contato</font></td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td width="23%" align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Nome:</font></b></td>
        <td width="77%" align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $nome .'</font></b></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">E-mail:</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><a href="mailto:'. $email_1 .'"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $email_1 .'</font></a></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Fone:</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $telefone.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Condom&iacute;nio&nbsp;:</font></b></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $condominio .'</font></b></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Unidade:</font></b></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $unidade .'</font></b></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Assunto:</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $assunto.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Mensagem:</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $mensagem.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>'; 

$headers = "MIME-Version: 1.0\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\n"; 
$headers .= "From:". $nome ." <". $email_1 .">\n"; // de
//$headers .= "Cc: Deyvison Nery <contato@deyvisonnery.com.br>\n"; // copia
//$headers .= "Bcc: Mariah Bonita <teste@desenhartstudio.com.br>\n"; // erro/teste
$headers .= "Return-Path: Contato - GF Souto <". $row_emailprincipal['email_contato'] .">\n"; // email de retorno

$headers2 = "MIME-Version: 1.0\n"; 
$headers2 .= "Content-type: text/html; charset=iso-8859-1\n"; 
$headers2 .= "From: Contato - GF Souto <". $row_emailprincipal['email_contato'] .">\n"; // para
/* Enviando a mensagem */ 

$to2 = $nome . "<". $email_1 .">\n";
$subject2 = "Contato Recebido - GF Souto" ;
$message2 = '<table width="600" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center"><a href="http://gfsouto.com.br" target="_self"><img src="http://www.gfsouto.com.br/novo/informativos/emails-topo-01.jpg" width="600" height="300" border="0"></a></td>
      </tr>
      <tr>
        <td><table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF"><font face="Verdana, Geneva, sans-serif" size="2">
              <p>Ol&aacute; Sr.(a)<strong> <font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $nome .'</font>.</strong> !</p>
              <p>Este e-mail indica que seu contato foi recebido com sucesso, responderemos o mais breve poss&iacute;vel.</p>
              <p>&nbsp;</p>
            </font></td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF"><p>&nbsp;</p>
              <p><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><b>GF SOUTO</b> <br />
                Rua Amaro Duarte, 241, Nova Bet&acirc;nia<br />
                CEP 59.603.030 - Mossor&oacute; / RN<br />
                Fone: 	(84) 3314 - 1703<br />
                E-mail: <a href="mailto:contato@gfsouto.com.br">contato@gfsouto.com.br</a></font></p>
              <p></p></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF"><font color="#000000" size="2" style="color: #F00; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Salve nossos e-mails em sua lista de e-mails segura ou lista branca.</font> </td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF"><a href="http://gfsouto.com.br/novo/responsabilidade_ambiental.php" target="_blank"><img src="http://www.gfsouto.com.br/novo/informativos/emails-rodape-01.jpg" width="600" height="128" border="0"></a></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>';
mail($to, $subject, $message, $headers);
mail($to2, $subject2, $message2, $headers2);

mysql_free_result($emailprincipal);

//} ////// fim verifica e-mail vazio

////////////////////////////////////////////////////////////////////////

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_politica = "SELECT * FROM politica_de_privacidade";
$politica = mysql_query($query_politica, $gf_souto_conect) or die(mysql_error());
$row_politica = mysql_fetch_assoc($politica);
$totalRows_politica = mysql_num_rows($politica);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
		<!--INICIO JQUERY DS DIGITAL  -->
		<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
        <script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
        <!--FIM JQUERY DS DIGITAL-->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id="conteiner_topo">
  <div id="topo">
    <div id="logomarca">
      <p><a href="./" title="GF SOUTO"><img src="imagens/logo-marca-gf-souto.png" alt="GF SOUTO" width="330" height="191" border="0" /></a></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p class="t05">Quando voc&ecirc; precisa, 
  <br />
  n&oacute;s estamos aqui. </p>
</div>
    <div id="menu"> 
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="600" height="355">
        <param name="movie" value="menu_topo_gfsouto.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="transparent" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="menu_topo_gfsouto.swf" width="600" height="355">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="transparent" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
        <div id="titulo_informativo">Contato</div>
        <div id="texto_bemvindo">Sua palavra &eacute; muito importante para a GF Souto, entre em contato sempre que preciso</div>
      	<div id="conteudocentro">
      	  <table width="700" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><p class="t08">&nbsp;</p>
      <p class="t08">Seu contato foi enviado com sucesso.</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
<p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>

      	</div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape">
    <?php include_once('rodape2.php'); ?>
    </div>
  </div>
</div>
<script type="text/javascript">
<!--
swfobject.registerObject("FlashID");
//-->
</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($politica);
?>
