<table width="990" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="33%"><h5>&nbsp;</h5></td>
    <td width="33%">&nbsp;</td>
    <td width="33%">&nbsp;</td>
  </tr>
  <tr>
    <td rowspan="6"><p><a href="./" title="Mobiliimoveis.com.br"><img src="imagens/mb_25.jpg" alt="Mobiliimoveis.com.br" width="267" height="89" border="0" /></a></p>
      <p>&nbsp;</p>
      <div id="rua"><?php echo $row_titulo['endereco']; ?>, <?php echo $row_titulo['bairro']; ?>, <?php echo $row_titulo['cidade']; ?> - <?php echo $row_titulo['estado']; ?></div>      <div id="fone">Fone: <?php echo $row_titulo['Telefone']; ?></div></td>
    <td>Assine nossa News</td>
    <td>Compartilhe a Mobili Im&oacute;veis nas redes Sociais</td>
  </tr>
  <tr>
    <td class="tx_02">Receba novidades no seu e-mail e fique bem informado</td>
    <td class="tx_02">Seja nosso amigo(a) nas redes sociais</td>
  </tr>
  <tr>
    <td align="center"><div id="news"><form id="news" name="news" method="post" action="assinatura_news.php"  onsubmit="return checa_news()">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="66%" align="left"><label>
            <input name="nome_news" type="text" class="input" id="nome_news" />
          </label></td>
          <td width="34%" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td align="left"><label>
            <input name="email_news" type="text" class="input" id="email_news" />
          </label></td>
          <td align="left"><label>
            <input name="button" type="submit" class="botao" id="button" value="Assinar" />
          </label></td>
        </tr>
        </table>
    </form></div></td>
    <td><a href="http://twitter.com/#!/<?php echo $row_titulo['twitter']; ?>" target="_blank"><img src="imagens/grey_twitter_stamp1.png" alt="" width="80" height="80" border="0" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $row_titulo['facebook_link']; ?>" target="_blank"><img src="imagens/grey_twitter_stamp2.png" alt="" width="80" height="80" border="0" /></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $row_titulo['youtube_link']; ?>" target="_blank"><img src="imagens/grey_twitter_stamp3.png" alt="" width="80" height="80" border="0" /></a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><table width="330" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="right"><a href="http://www.dsdigital.com.br" title="By DS Digital" target="_blank"><img src="imagens/assinatura_ds_digital.png" alt="By DS Digital" width="38" height="35" border="0" /></a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
      </table>