<?php require_once('../Connections/conexao_site.php'); ?>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}


////////************************************
// resgata o nome do administrador do sistema na tabela admin
$admin = $_SESSION['MM_Username'];///
mysql_select_db($database_conexao_site, $conexao_site);
$query_administradores = "SELECT * FROM `admin` WHERE admin.login = '$admin'";
$administradores = mysql_query($query_administradores, $conexao_site) or die(mysql_error());
$row_administradores = mysql_fetch_assoc($administradores);
$totalRows_administradores = mysql_num_rows($administradores);

mysql_select_db($database_conexao_site, $conexao_site);
$query_empresa = "SELECT * FROM nome_empresa";
$empresa = mysql_query($query_empresa, $conexao_site) or die(mysql_error());
$row_empresa = mysql_fetch_assoc($empresa);
$totalRows_empresa = mysql_num_rows($empresa);

////////////***********************************

?>
<?php

$maxRows_logs = 40;
$pageNum_logs = 0;
if (isset($_GET['pageNum_logs'])) {
  $pageNum_logs = $_GET['pageNum_logs'];
}
$startRow_logs = $pageNum_logs * $maxRows_logs;

mysql_select_db($database_conexao_site, $conexao_site);
$query_logs = "SELECT * FROM logs_acesso ORDER BY logs_acesso.data_hora DESC";
$query_limit_logs = sprintf("%s LIMIT %d, %d", $query_logs, $startRow_logs, $maxRows_logs);
$logs = mysql_query($query_limit_logs, $conexao_site) or die(mysql_error());
$row_logs = mysql_fetch_assoc($logs);

if (isset($_GET['totalRows_logs'])) {
  $totalRows_logs = $_GET['totalRows_logs'];
} else {
  $all_logs = mysql_query($query_logs);
  $totalRows_logs = mysql_num_rows($all_logs);
}
$totalPages_logs = ceil($totalRows_logs/$maxRows_logs)-1;

// Initialize the Alternate Color counter
$ac_sw1 = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<link href="CSS.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php include_once('verificar_navegador/teste_ie.php'); ?>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><a href="http://www.dsdigital.com.br" target="_blank"><img src="logo-para-painel-adm.gif" width="300" height="68" border="0" /></a></td>
        <td width="476" align="center" class="t01"><?php echo $row_empresa['nome_empresa']; ?><br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_administradores['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr bgcolor="#ededed">
    <td align="center"><?php require_once('menu.php'); ?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
<td height="300" align="center" valign="top" bgcolor="#FFFFFF" class="t01"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">Bem vindo</td>
    <td width="400" align="center"><table width="400" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="3" align="left" bgcolor="#EDEDED" class="t03">&Uacute;ltimos acessos</td>
        </tr>
      <tr class="t02">
        <td height="30" align="left"><strong>Nome</strong></td>
        <td align="left">&nbsp;</td>
        <td align="left"><strong>data/hora</strong></td>
        </tr>
      <?php do { ?>
<tr bgcolor="<?php echo ($ac_sw1++%2==0)?"#ededed":"#FFFFFF"; ?>" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#FFFFCC'" class="t02">
        
          <td align="left"><?php echo $row_logs['nome_admin']; ?>&nbsp;</td>
          <td align="left">&nbsp;&nbsp;--&gt;</td>
          <td align="left">
            <?php 
	
	$data_noticia_da_hora = $row_logs['data_hora'];
	$data=explode("-",$data_noticia_da_hora);
    $dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
    //echo($dataFinal);
	//  11 19:28:38/05/2010
	$dia = substr($dataFinal,0,2);    // retorna "bcdef"
    $mes = substr($dataFinal, 12, 2); // retorna "bcd"
    $ano = substr($dataFinal, 15, 4); // retorna "abcd"
	$hora = substr($dataFinal, 3, 8); // retorna "abcd"
	//$autor = $row_noticia_da_hora['autor_noticia'];
	$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora;
	//$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora . " por ". $autor;
	//$dataok = $dia ."/". $mes . "/". $ano;
	echo $dataok;
	
	?>
          </td>

      </tr><?php } while ($row_logs = mysql_fetch_assoc($logs)); ?>
    </table></td>
  </tr>
</table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php


mysql_free_result($logs);
?>
