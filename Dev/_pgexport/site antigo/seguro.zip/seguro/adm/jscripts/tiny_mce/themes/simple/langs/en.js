tinyMCE.addI18n('en.simple',{
bold_desc:"Negrito (Ctrl+B)",
italic_desc:"Italico (Ctrl+I)",
underline_desc:"Sublinhado (Ctrl+U)",
striketrough_desc:"Tachado",
bullist_desc:"Unordered list",
numlist_desc:"Ordered list",
undo_desc:"Desfazer (Ctrl+Z)",
redo_desc:"Refazer (Ctrl+Y)",
cleanup_desc:"Apagar c�digo"
});