<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the required classes
require_once('../includes/tfi/TFI.php');
require_once('../includes/tso/TSO.php');
require_once('../includes/nav/NAV.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("id_area_nome", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Filter
$tfi_listarea_condominio1 = new TFI_TableFilter($conn_gf_souto_conect, "tfi_listarea_condominio1");
$tfi_listarea_condominio1->addColumn("areas_nome.id_area", "STRING_TYPE", "id_area_nome", "%");
$tfi_listarea_condominio1->Execute();

// Sorter
$tso_listarea_condominio1 = new TSO_TableSorter("rsarea_condominio1", "tso_listarea_condominio1");
$tso_listarea_condominio1->addColumn("areas_nome.nome_area");
$tso_listarea_condominio1->setDefault("area_condominio.id_area_nome");
$tso_listarea_condominio1->Execute();

// Navigation
$nav_listarea_condominio1 = new NAV_Regular("nav_listarea_condominio1", "rsarea_condominio1", "../", $_SERVER['PHP_SELF'], 20);

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset1 = "SELECT nome_area, id_area FROM areas_nome ORDER BY nome_area";
$Recordset1 = mysql_query($query_Recordset1, $gf_souto_conect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset2 = "SELECT nome_area, id_area FROM areas_nome ORDER BY nome_area";
$Recordset2 = mysql_query($query_Recordset2, $gf_souto_conect) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);

// Make an insert transaction instance
$ins_area_condominio = new tNG_insert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_area_condominio);
// Register triggers
$ins_area_condominio->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_area_condominio->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_area_condominio->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_area_condominios.php?id_cond=".$_GET['id_cond']);
// Add columns
$ins_area_condominio->setTable("area_condominio");
$ins_area_condominio->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond", "{GET.id_cond}");
$ins_area_condominio->addColumn("id_area_nome", "STRING_TYPE", "POST", "id_area_nome");
$ins_area_condominio->setPrimaryKey("id_area_cond", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

//NeXTenesio3 Special List Recordset
$maxRows_rsarea_condominio1 = $_SESSION['max_rows_nav_listarea_condominio1'];
$pageNum_rsarea_condominio1 = 0;
if (isset($_GET['pageNum_rsarea_condominio1'])) {
  $pageNum_rsarea_condominio1 = $_GET['pageNum_rsarea_condominio1'];
}
$startRow_rsarea_condominio1 = $pageNum_rsarea_condominio1 * $maxRows_rsarea_condominio1;

// Defining List Recordset variable
$NXTFilter_rsarea_condominio1 = "1=1";
if (isset($_SESSION['filter_tfi_listarea_condominio1'])) {
  $NXTFilter_rsarea_condominio1 = $_SESSION['filter_tfi_listarea_condominio1'];
}
// Defining List Recordset variable
$NXTSort_rsarea_condominio1 = "area_condominio.id_area_nome";
if (isset($_SESSION['sorter_tso_listarea_condominio1'])) {
  $NXTSort_rsarea_condominio1 = $_SESSION['sorter_tso_listarea_condominio1'];
}
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);

$query_rsarea_condominio1 = "SELECT areas_nome.nome_area AS id_area_nome, area_condominio.id_area_cond FROM area_condominio LEFT JOIN areas_nome ON area_condominio.id_area_nome = areas_nome.id_area WHERE {$NXTFilter_rsarea_condominio1}   AND area_condominio.id_cond = ".$_GET['id_cond']." ORDER BY {$NXTSort_rsarea_condominio1}";
$query_limit_rsarea_condominio1 = sprintf("%s LIMIT %d, %d", $query_rsarea_condominio1, $startRow_rsarea_condominio1, $maxRows_rsarea_condominio1);
$rsarea_condominio1 = mysql_query($query_limit_rsarea_condominio1, $gf_souto_conect) or die(mysql_error());
$row_rsarea_condominio1 = mysql_fetch_assoc($rsarea_condominio1);

if (isset($_GET['totalRows_rsarea_condominio1'])) {
  $totalRows_rsarea_condominio1 = $_GET['totalRows_rsarea_condominio1'];
} else {
  $all_rsarea_condominio1 = mysql_query($query_rsarea_condominio1);
  $totalRows_rsarea_condominio1 = mysql_num_rows($all_rsarea_condominio1);
}
$totalPages_rsarea_condominio1 = ceil($totalRows_rsarea_condominio1/$maxRows_rsarea_condominio1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listarea_condominio1->checkBoundries();

// Get the transaction recordset
$rsarea_condominio = $tNGs->getRecordset("area_condominio");
$row_rsarea_condominio = mysql_fetch_assoc($rsarea_condominio);
$totalRows_rsarea_condominio = mysql_num_rows($rsarea_condominio);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: false,
  duplicate_navigation: false,
  row_effects: true,
  show_as_buttons: true,
  record_counter: false
}
</script>
<style type="text/css">
  /* Dynamic List row settings */
  .KT_col_id_area_nome {width:140px; overflow:hidden;}
</style>
<?php echo $tNGs->displayValidationRules();?>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">&Aacute;reas condom&iacute;nos 
    <?php 
	
	
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$_GET['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

echo '<b>'.$row_condominio['nome_cond'].'</b>';

 ?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form2" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th"><label for="id_area_nome">nome:</label></td>
            <td><select name="id_area_nome" id="id_area_nome">
              <?php 
do {  
?>
              <option value="<?php echo $row_Recordset2['id_area']?>"<?php if (!(strcmp($row_Recordset2['id_area'], $row_rsarea_condominio['id_area_nome']))) {echo "SELECTED";} ?>><?php echo $row_Recordset2['nome_area']?></option>
              <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
  $rows = mysql_num_rows($Recordset2);
  if($rows > 0) {
      mysql_data_seek($Recordset2, 0);
	  $row_Recordset2 = mysql_fetch_assoc($Recordset2);
  }
?>
            </select>
              <?php echo $tNGs->displayFieldError("area_condominio", "id_area_nome"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar" /></td>
          </tr>
        </table>
        <input type="hidden" name="id_cond" id="id_cond" value="<?php echo KT_escapeAttribute($row_rsarea_condominio['id_cond']); ?>" />
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <div class="KT_tng" id="listarea_condominio1">
        <?php /*?><h1> Area_condominio
          <?php
  $nav_listarea_condominio1->Prepare();
  require("../includes/nav/NAV_Text_Statistics.inc.php");
?>
        </h1><?php */?>
        <div class="KT_tnglist">
          <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" id="form1">
            <div class="KT_options"> <a href="<?php echo $nav_listarea_condominio1->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
              <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listarea_condominio1'] == 1) {
?>
                <?php echo $_SESSION['default_max_rows_nav_listarea_condominio1']; ?>
                <?php 
  // else Conditional region1
  } else { ?>
                <?php echo NXT_getResource("all"); ?>
                <?php } 
  // endif Conditional region1
?>
<?php echo NXT_getResource("records"); ?></a> &nbsp;
              &nbsp; </div>
            <table cellpadding="2" cellspacing="0" class="KT_tngtable">
              <thead>
                <tr class="KT_row_order">
                  <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                  </th>
                  <th id="id_area_nome" class="KT_sorter KT_col_id_area_nome <?php echo $tso_listarea_condominio1->getSortIcon('areas_nome.nome_area'); ?>"> <a href="<?php echo $tso_listarea_condominio1->getSortLink('areas_nome.nome_area'); ?>">Nome</a></th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($totalRows_rsarea_condominio1 == 0) { // Show if recordset empty ?>
                  <tr>
                    <td colspan="3"><?php echo NXT_getResource("Nenhum resultado encontrado."); ?></td>
                  </tr>
                  <?php } // Show if recordset empty ?>
                <?php if ($totalRows_rsarea_condominio1 > 0) { // Show if recordset not empty ?>
                  <?php do { ?>
                    <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                      <td><input type="checkbox" name="kt_pk_area_condominio" class="id_checkbox" value="<?php echo $row_rsarea_condominio1['id_area_cond']; ?>" />
                        <input type="hidden" name="id_area_cond" class="id_field" value="<?php echo $row_rsarea_condominio1['id_area_cond']; ?>" /></td>
                      <td><div class="KT_col_id_area_nome"><?php echo KT_FormatForList($row_rsarea_condominio1['id_area_nome'], 20); ?></div></td>
                      <td><a class="KT_edit_link" href="atualizar_area_condominios.php?id_area_cond=<?php echo $row_rsarea_condominio1['id_area_cond']; ?>&amp;KT_back=1"><?php /*?><?php echo NXT_getResource("edit_one"); ?><?php */?></a> <a class="KT_delete_link" href="#delete"><?php echo NXT_getResource("delete_one"); ?></a></td>
                    </tr>
                    <?php } while ($row_rsarea_condominio1 = mysql_fetch_assoc($rsarea_condominio1)); ?>
                  <?php } // Show if recordset not empty ?>
              </tbody>
            </table>
            <div class="KT_bottomnav">
              <div>
                <?php
            $nav_listarea_condominio1->Prepare();
            require("../includes/nav/NAV_Text_Navigation.inc.php");
          ?>
              </div>
            </div>
            <div class="KT_bottombuttons">
              <div class="KT_operations"></div>
              <span>&nbsp;</span></div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($Recordset1);

mysql_free_result($Recordset2);

mysql_free_result($rsarea_condominio1);
?>
