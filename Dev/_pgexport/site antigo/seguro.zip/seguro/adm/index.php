<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_empresa = "SELECT * FROM nome_empresa";
$empresa = mysql_query($query_empresa, $gf_souto_conect) or die(mysql_error());
$row_empresa = mysql_fetch_assoc($empresa);
$totalRows_empresa = mysql_num_rows($empresa);
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['login_ds'])) {
  $loginUsername=$_POST['login_ds'];
  $password=$_POST['senha_ds'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "cadastrar_log.php";
  $MM_redirectLoginFailed = "erro.php";
  $MM_redirecttoReferrer = false;
  
  
  mysql_select_db($database_gf_souto_conect, $gf_souto_conect);  
  $LoginRS__query=sprintf("SELECT login, senha FROM `admin` WHERE login=%s AND senha=%s",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text"));
  $LoginRS = mysql_query($LoginRS__query, $gf_souto_conect) or die(mysql_error());
  
  
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA��O - <?php echo $row_empresa['nome_empresa']; ?></title>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-color: #000;
}
-->
</style></head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><a href="http://www.dsdigital.com.br" target="_blank"><img src="logo-para-painel-adm.gif" width="300" height="68" border="0" /></a></td>
        <td width="476" align="center" class="t01"><?php echo $row_empresa['nome_empresa']; ?></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"><form id="administracao" name="administracao" method="POST" action="<?php echo $loginFormAction; ?>">
      <table width="500" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align="center">&nbsp;</td>
        </tr>
        <tr>
          <td align="center"><img src="gpg.gif" width="128" height="128" /></td>
        </tr>
        <tr>
          <td align="center">&nbsp;</td>
        </tr>
        <tr>
          <td height="30" align="center" class="t02">Login</td>
        </tr>
        <tr>
          <td height="30" align="center"><label>
            <input type="text" name="login_ds" id="login_ds" />
          </label></td>
        </tr>
        <tr>
          <td height="30" align="center" class="t02">Senha</td>
        </tr>
        <tr>
          <td height="30" align="center"><label>
            <input type="password" name="senha_ds" id="senha_ds" />
          </label></td>
        </tr>
        <tr>
          <td align="center"><?php
         /* require_once('recaptchalib.php');
          $publickey = "6LeEvr8SAAAAAF5tIEBJyt-YBSSttu9nt2pKZWqb"; // you got this from the signup page
          echo recaptcha_get_html($publickey);
      */  ?></td>
        </tr>
        <tr>
          <td align="center"><label><br/>
<input type="submit" name="button" id="button" value="Entrar" />
          </label></td>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($empresa);
?>
