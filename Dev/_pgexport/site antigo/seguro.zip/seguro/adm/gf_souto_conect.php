<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_gf_souto_conect = "cpmy0010.servidorwebfacil.com";
$database_gf_souto_conect = "gfsoutn_gf2011";
$username_gf_souto_conect = "gfsoutn_gf2011";
$password_gf_souto_conect = "O^xcv)XUx0$#";
$gf_souto_conect = mysql_pconnect($hostname_gf_souto_conect, $username_gf_souto_conect, $password_gf_souto_conect) or trigger_error(mysql_error(),E_USER_ERROR); 
?>