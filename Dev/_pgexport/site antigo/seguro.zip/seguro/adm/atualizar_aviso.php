<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('../includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("chamada_galeria", true, "text", "", "", "", "");
$formValidation->addField("texto", true, "text", "", "", "", "");
$formValidation->addField("data_cadastro", true, "date", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_aviso_geral = new tNG_multipleInsert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_aviso_geral);
// Register triggers
$ins_aviso_geral->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_aviso_geral->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_aviso_geral->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$ins_aviso_geral->setTable("aviso_geral");
$ins_aviso_geral->addColumn("chamada_galeria", "STRING_TYPE", "POST", "chamada_galeria");
$ins_aviso_geral->addColumn("texto", "STRING_TYPE", "POST", "texto");
$ins_aviso_geral->addColumn("data_cadastro", "DATE_TYPE", "POST", "data_cadastro");
$ins_aviso_geral->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$ins_aviso_geral->setPrimaryKey("id_aviso", "NUMERIC_TYPE");

// Make an update transaction instance
$upd_aviso_geral = new tNG_multipleUpdate($conn_gf_souto_conect);
$tNGs->addTransaction($upd_aviso_geral);
// Register triggers
$upd_aviso_geral->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd_aviso_geral->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd_aviso_geral->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$upd_aviso_geral->setTable("aviso_geral");
$upd_aviso_geral->addColumn("chamada_galeria", "STRING_TYPE", "POST", "chamada_galeria");
$upd_aviso_geral->addColumn("texto", "STRING_TYPE", "POST", "texto");
$upd_aviso_geral->addColumn("data_cadastro", "DATE_TYPE", "POST", "data_cadastro");
$upd_aviso_geral->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$upd_aviso_geral->setPrimaryKey("id_aviso", "NUMERIC_TYPE", "GET", "id_aviso");

// Make an instance of the transaction object
$del_aviso_geral = new tNG_multipleDelete($conn_gf_souto_conect);
$tNGs->addTransaction($del_aviso_geral);
// Register triggers
$del_aviso_geral->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del_aviso_geral->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$del_aviso_geral->setTable("aviso_geral");
$del_aviso_geral->setPrimaryKey("id_aviso", "NUMERIC_TYPE", "GET", "id_aviso");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rsaviso_geral = $tNGs->getRecordset("aviso_geral");
$row_rsaviso_geral = mysql_fetch_assoc($rsaviso_geral);
$totalRows_rsaviso_geral = mysql_num_rows($rsaviso_geral);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="../includes/nxt/scripts/form.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/form.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: false,
  show_as_grid: true,
  merge_down_value: true
}
</script>

<!--IN�CIO DO TEXT �REA DIM�MICO-->
<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "simple",
		//theme : "advanced",
		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,sub,sup,|,bullist,numlist,|,outdent,indent,blockquote,|,cut,copy,paste,pastetext,|,undo,redo,|,link,unlink,anchor",
		/*theme_advanced_buttons2 : "tablecontrols",*/
		
		/*//* Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak",
		*/
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// ---------------------------------------
		content_css : "exemples/css/content.css",

		// --------------------------
		//template_external_list_url : "exemples/lists/template_list.js",
		//external_link_list_url : "exemples/lists/link_list.js",
		//external_image_list_url : "exemples/lists/image_list.js",
		//media_external_list_url : "exemples/lists/media_list.js",

		// --------------------------
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>
<!--FIM DO TEXT �REA DIM�MICO-->

<script type="text/javascript" src="../includes/common/js/sigslot_core.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="../includes/resources/calendar.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Atualizar aviso</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <div class="KT_tng">
        <h1>
          <?php 
// Show IF Conditional region1 
if (@$_GET['id_aviso'] == "") {
?>
            <?php echo NXT_getResource("Insert_FH"); ?>
            <?php 
// else Conditional region1
} else { ?>
            <?php echo NXT_getResource("Update_FH"); ?>
            <?php } 
// endif Conditional region1
?>
          Aviso_geral </h1>
        <div class="KT_tngform">
          <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
            <?php $cnt1 = 0; ?>
            <?php do { ?>
              <?php $cnt1++; ?>
              <?php 
// Show IF Conditional region1 
if (@$totalRows_rsaviso_geral > 1) {
?>
                <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                <?php } 
// endif Conditional region1
?>
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="chamada_galeria_<?php echo $cnt1; ?>">T�tulo:</label></td>
                  <td><input type="text" name="chamada_galeria_<?php echo $cnt1; ?>" id="chamada_galeria_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsaviso_geral['chamada_galeria']); ?>" size="32" maxlength="150" />
                    <?php echo $tNGs->displayFieldHint("chamada_galeria");?> <?php echo $tNGs->displayFieldError("aviso_geral", "chamada_galeria", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="texto_<?php echo $cnt1; ?>">Texto:</label></td>
                  <td><textarea name="texto_<?php echo $cnt1; ?>" id="texto_<?php echo $cnt1; ?>" cols="100" rows="10"><?php echo KT_escapeAttribute($row_rsaviso_geral['texto']); ?></textarea>
                    <?php echo $tNGs->displayFieldHint("texto");?> <?php echo $tNGs->displayFieldError("aviso_geral", "texto", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="data_cadastro_<?php echo $cnt1; ?>">Data publi.:</label></td>
                  <td><input name="data_cadastro_<?php echo $cnt1; ?>" id="data_cadastro_<?php echo $cnt1; ?>" value="<?php echo KT_formatDate($row_rsaviso_geral['data_cadastro']); ?>" size="10" maxlength="22" wdg:mondayfirst="false" wdg:subtype="Calendar" wdg:mask="<?php echo $KT_screen_date_format; ?>" wdg:type="widget" wdg:singleclick="false" wdg:restricttomask="no" wdg:readonly="true" />
                    <?php echo $tNGs->displayFieldHint("data_cadastro");?> <?php echo $tNGs->displayFieldError("aviso_geral", "data_cadastro", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="ativo_<?php echo $cnt1; ?>">Ativo:</label></td>
                  <td><select name="ativo_<?php echo $cnt1; ?>" id="ativo_<?php echo $cnt1; ?>">
                    <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rsaviso_geral['ativo'])))) {echo "SELECTED";} ?>>sim</option>
                    <option value="0" <?php if (!(strcmp(0, KT_escapeAttribute($row_rsaviso_geral['ativo'])))) {echo "SELECTED";} ?>>n�o</option>
                  </select>
                    <?php echo $tNGs->displayFieldError("aviso_geral", "ativo", $cnt1); ?></td>
                </tr>
              </table>
              <input type="hidden" name="kt_pk_aviso_geral_<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rsaviso_geral['kt_pk_aviso_geral']); ?>" />
              <?php } while ($row_rsaviso_geral = mysql_fetch_assoc($rsaviso_geral)); ?>
            <div class="KT_bottombuttons">
              <div>
                <?php 
      // Show IF Conditional region1
      if (@$_GET['id_aviso'] == "") {
      ?>
                  <?php 
      // else Conditional region1
      } else { ?>
                  <input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" />
                  <?php }
      // endif Conditional region1
      ?>
<input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, '../includes/nxt/back.php')" />
              </div>
            </div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);
?>