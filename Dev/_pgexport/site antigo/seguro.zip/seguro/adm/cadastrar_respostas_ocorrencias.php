<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("data_resposta", true, "date", "", "", "", "");
$formValidation->addField("texto_resposta", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger



$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM admin WHERE login = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_ocorrencia = "SELECT * FROM livro_ocorrencia WHERE livro_ocorrencia.id_ocorr =".$_GET['cod_ocorr'];
$ocorrencia = mysql_query($query_ocorrencia, $gf_souto_conect) or die(mysql_error());
$row_ocorrencia = mysql_fetch_assoc($ocorrencia);
$totalRows_ocorrencia = mysql_num_rows($ocorrencia);

// Make an insert transaction instance
$ins_livro_resp_ocorr = new tNG_insert($conn_gf_souto_conect);


$tNGs->addTransaction($ins_livro_resp_ocorr);
// Register triggers
$ins_livro_resp_ocorr->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_livro_resp_ocorr->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_livro_resp_ocorr->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_respostas_ocorrencias.php?id_cond=".$_GET['id_cond']);
// Add columns
$ins_livro_resp_ocorr->setTable("livro_resp_ocorr");
$ins_livro_resp_ocorr->addColumn("id_ocorr", "STRING_TYPE", "VALUE", "{GET.cod_ocorr}");
$ins_livro_resp_ocorr->addColumn("data_resposta", "DATE_TYPE", "POST", "data_resposta");
$ins_livro_resp_ocorr->addColumn("texto_resposta", "STRING_TYPE", "POST", "texto_resposta");
$ins_livro_resp_ocorr->setPrimaryKey("id_livro", "NUMERIC_TYPE");

//  UPDATE  gfsouto_2011.livro_ocorrencia SET  respondido =  '1' WHERE  livro_ocorrencia.id_ocorr =2 LIMIT 1 ;

$query_k = "UPDATE  livro_ocorrencia SET  respondido =  '1' WHERE  livro_ocorrencia.id_ocorr =".$_GET['cod_ocorr']." LIMIT 1" ;
$hh = mysql_query($query_k, $gf_souto_conect) or die(mysql_error());
//$row_hh = mysql_fetch_assoc($hh);

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rslivro_resp_ocorr = $tNGs->getRecordset("livro_resp_ocorr");
$row_rslivro_resp_ocorr = mysql_fetch_assoc($rslivro_resp_ocorr);
$totalRows_rslivro_resp_ocorr = mysql_num_rows($rslivro_resp_ocorr);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script type="text/javascript" src="../includes/common/js/sigslot_core.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="../includes/resources/calendar.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Cadastrar resposta ocorr&ecirc;ncia</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr><?php 
		  
		  	
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$row_ocorrencia['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

?>
            <td colspan="2" align="left" bgcolor="#EDEDED"><span class="t02">Cond.: <b><?php echo $row_condominio['nome_cond']; ?></b> / Uni: <b><?php echo $row_ocorrencia['id_unidade']; ?></b> - Data: <?php echo $row_ocorrencia['data_ocorr']; ?></span></td>
        </tr>
          <tr>
            <td width="10%" align="left" bgcolor="#EDEDED"><b><span class="t02">Nome:</span></b></td>
            <td width="90%" align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_ocorrencia['nome']; ?></span></td>
        </tr>
          <tr>
            <td align="left" bgcolor="#EDEDED"><b><span class="t02">E-mail:</span></b></td>
            <td align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<a href="mailto:<?php echo $row_ocorrencia['email']; ?>"><?php echo $row_ocorrencia['email']; ?></a></span></td>
        </tr>
          <tr>
            <td align="left" bgcolor="#EDEDED" class="t02"><b><span class="t02">Fone:</span></b></td>
            <td align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_ocorrencia['fone']; ?></span></td>
        </tr>
          <tr>
            <td align="left" valign="top" bgcolor="#EDEDED" class="t02">Ocorr&ecirc;ncia:</td>
            <td align="left" valign="top" bgcolor="#FFFFCC" class="t02">&nbsp;<?php echo $row_ocorrencia['text_ocorr']; ?></td>
        </tr>
          <tr>
            <td colspan="2" align="right" bgcolor="#EDEDED" class="t02">&nbsp;</td>
        </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="left">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th">C�d ocorr�ncia:</td>
            <td><?php echo KT_escapeAttribute($row_rslivro_resp_ocorr['id_ocorr']); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="data_resposta">Data Resposta:</label></td>
            <td><input name="data_resposta" id="data_resposta" value="<?php echo KT_formatDate($row_rslivro_resp_ocorr['data_resposta']); ?>" size="32" wdg:mondayfirst="false" wdg:subtype="Calendar" wdg:mask="<?php echo $KT_screen_date_format; ?>" wdg:type="widget" wdg:singleclick="false" wdg:restricttomask="no" wdg:readonly="true" />
              <?php echo $tNGs->displayFieldHint("data_resposta");?> <?php echo $tNGs->displayFieldError("livro_resp_ocorr", "data_resposta"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="texto_resposta">Resposta:</label></td>
            <td><textarea name="texto_resposta" id="texto_resposta" cols="85" rows="5"><?php echo KT_escapeAttribute($row_rslivro_resp_ocorr['texto_resposta']); ?></textarea>
              <?php echo $tNGs->displayFieldHint("texto_resposta");?> <?php echo $tNGs->displayFieldError("livro_resp_ocorr", "texto_resposta"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar resposta" /></td>
          </tr>
        </table>
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($ocorrencia);
?>
