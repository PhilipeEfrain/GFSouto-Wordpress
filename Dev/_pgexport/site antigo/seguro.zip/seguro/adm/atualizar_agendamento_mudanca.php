<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('../includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_mudanca = new tNG_multipleInsert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_mudanca);
// Register triggers
$ins_mudanca->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_mudanca->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_mudanca->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$ins_mudanca->setTable("mudanca");
$ins_mudanca->addColumn("eventDate", "DATE_TYPE", "POST", "eventDate");
$ins_mudanca->addColumn("eventTitle", "STRING_TYPE", "POST", "eventTitle");
$ins_mudanca->addColumn("eventContent", "STRING_TYPE", "POST", "eventContent");
$ins_mudanca->addColumn("nome", "STRING_TYPE", "POST", "nome");
$ins_mudanca->addColumn("email", "STRING_TYPE", "POST", "email");
$ins_mudanca->addColumn("fone", "STRING_TYPE", "POST", "fone");
$ins_mudanca->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$ins_mudanca->setPrimaryKey("id", "NUMERIC_TYPE");

// Make an update transaction instance
$upd_mudanca = new tNG_multipleUpdate($conn_gf_souto_conect);
$tNGs->addTransaction($upd_mudanca);
// Register triggers
$upd_mudanca->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd_mudanca->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd_mudanca->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$upd_mudanca->setTable("mudanca");
$upd_mudanca->addColumn("eventDate", "DATE_TYPE", "POST", "eventDate");
$upd_mudanca->addColumn("eventTitle", "STRING_TYPE", "POST", "eventTitle");
$upd_mudanca->addColumn("eventContent", "STRING_TYPE", "POST", "eventContent");
$upd_mudanca->addColumn("nome", "STRING_TYPE", "POST", "nome");
$upd_mudanca->addColumn("email", "STRING_TYPE", "POST", "email");
$upd_mudanca->addColumn("fone", "STRING_TYPE", "POST", "fone");
$upd_mudanca->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$upd_mudanca->setPrimaryKey("id", "NUMERIC_TYPE", "GET", "id");

// Make an instance of the transaction object
$del_mudanca = new tNG_multipleDelete($conn_gf_souto_conect);
$tNGs->addTransaction($del_mudanca);
// Register triggers
$del_mudanca->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del_mudanca->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$del_mudanca->setTable("mudanca");
$del_mudanca->setPrimaryKey("id", "NUMERIC_TYPE", "GET", "id");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rsmudanca = $tNGs->getRecordset("mudanca");
$row_rsmudanca = mysql_fetch_assoc($rsmudanca);
$totalRows_rsmudanca = mysql_num_rows($rsmudanca);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="../includes/nxt/scripts/form.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/form.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: false,
  show_as_grid: true,
  merge_down_value: true
}
</script>
<script type="text/javascript" src="../includes/common/js/sigslot_core.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="../includes/resources/calendar.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Atualizar agendamento mudan&ccedil;a</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <div class="KT_tng">
        <h1>
          <?php 
// Show IF Conditional region1 
if (@$_GET['id'] == "") {
?>
            <?php echo NXT_getResource("Insert_FH"); ?>
            <?php 
// else Conditional region1
} else { ?>
            <?php echo NXT_getResource("Update_FH"); ?>
            <?php } 
// endif Conditional region1
?>
          Mudanca </h1>
        <div class="KT_tngform">
          <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
            <?php $cnt1 = 0; ?>
            <?php do { ?>
              <?php $cnt1++; ?>
              <?php 
// Show IF Conditional region1 
if (@$totalRows_rsmudanca > 1) {
?>
                <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                <?php } 
// endif Conditional region1
?>
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="eventDate_<?php echo $cnt1; ?>">Data:</label></td>
                  <td><input name="eventDate_<?php echo $cnt1; ?>" id="eventDate_<?php echo $cnt1; ?>" value="<?php echo KT_formatDate($row_rsmudanca['eventDate']); ?>" size="10" maxlength="22" wdg:mondayfirst="false" wdg:subtype="Calendar" wdg:mask="<?php echo $KT_screen_date_format; ?>" wdg:type="widget" wdg:singleclick="false" wdg:restricttomask="no" wdg:readonly="true" />
                    <?php echo $tNGs->displayFieldHint("eventDate");?> <?php echo $tNGs->displayFieldError("mudanca", "eventDate", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="eventTitle_<?php echo $cnt1; ?>">Unidade:</label></td>
                  <td><input name="eventTitle_<?php echo $cnt1; ?>" type="text" disabled="disabled" id="eventTitle_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsmudanca['eventTitle']); ?>" size="32" maxlength="100" readonly="readonly" />
                    <?php echo $tNGs->displayFieldHint("eventTitle");?> <?php echo $tNGs->displayFieldError("mudanca", "eventTitle", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="eventContent_<?php echo $cnt1; ?>">Observa��es:</label></td>
                  <td><input type="text" name="eventContent_<?php echo $cnt1; ?>" id="eventContent_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsmudanca['eventContent']); ?>" size="32" />
                    <?php echo $tNGs->displayFieldHint("eventContent");?> <?php echo $tNGs->displayFieldError("mudanca", "eventContent", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="nome_<?php echo $cnt1; ?>">Nome:</label></td>
                  <td><input type="text" name="nome_<?php echo $cnt1; ?>" id="nome_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsmudanca['nome']); ?>" size="32" maxlength="50" />
                    <?php echo $tNGs->displayFieldHint("nome");?> <?php echo $tNGs->displayFieldError("mudanca", "nome", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="email_<?php echo $cnt1; ?>">Email:</label></td>
                  <td><input type="text" name="email_<?php echo $cnt1; ?>" id="email_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsmudanca['email']); ?>" size="32" maxlength="100" />
                    <?php echo $tNGs->displayFieldHint("email");?> <?php echo $tNGs->displayFieldError("mudanca", "email", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="fone_<?php echo $cnt1; ?>">Fone:</label></td>
                  <td><input type="text" name="fone_<?php echo $cnt1; ?>" id="fone_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsmudanca['fone']); ?>" size="30" maxlength="30" />
                    <?php echo $tNGs->displayFieldHint("fone");?> <?php echo $tNGs->displayFieldError("mudanca", "fone", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="ativo_<?php echo $cnt1; ?>">Liberado?</label></td>
                  <td><select name="ativo_<?php echo $cnt1; ?>" id="ativo_<?php echo $cnt1; ?>">
                    <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rsmudanca['ativo'])))) {echo "SELECTED";} ?>>liberado</option>
                    <option value="0" <?php if (!(strcmp(0, KT_escapeAttribute($row_rsmudanca['ativo'])))) {echo "SELECTED";} ?>>n�o liberado</option>
                  </select>
                    <?php echo $tNGs->displayFieldError("mudanca", "ativo", $cnt1); ?></td>
                </tr>
              </table>
              <input type="hidden" name="kt_pk_mudanca_<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rsmudanca['kt_pk_mudanca']); ?>" />
              <?php } while ($row_rsmudanca = mysql_fetch_assoc($rsmudanca)); ?>
            <div class="KT_bottombuttons">
              <div>
                <?php 
      // Show IF Conditional region1
      if (@$_GET['id'] == "") {
      ?>
                  <?php 
      // else Conditional region1
      } else { ?>
                  <input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" />
                  <?php }
      // endif Conditional region1
      ?>
<input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, '../includes/nxt/back.php')" />
              </div>
            </div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);
?>