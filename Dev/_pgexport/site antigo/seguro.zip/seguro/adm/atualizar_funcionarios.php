<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('../includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("nome_func", true, "text", "", "", "", "");
$formValidation->addField("funcao_func", true, "text", "", "", "", "");
$formValidation->addField("expediente", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_funcionarios = new tNG_multipleInsert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_funcionarios);
// Register triggers
$ins_funcionarios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_funcionarios->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_funcionarios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$ins_funcionarios->setTable("funcionarios");
$ins_funcionarios->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond", "{GET.id_cond}");
$ins_funcionarios->addColumn("foto_func", "FILE_TYPE", "FILES", "foto_func");
$ins_funcionarios->addColumn("nome_func", "STRING_TYPE", "POST", "nome_func");
$ins_funcionarios->addColumn("funcao_func", "STRING_TYPE", "POST", "funcao_func");
$ins_funcionarios->addColumn("expediente", "STRING_TYPE", "POST", "expediente");
$ins_funcionarios->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$ins_funcionarios->setPrimaryKey("id_func", "NUMERIC_TYPE");

// Make an update transaction instance
$upd_funcionarios = new tNG_multipleUpdate($conn_gf_souto_conect);
$tNGs->addTransaction($upd_funcionarios);
// Register triggers
$upd_funcionarios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd_funcionarios->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd_funcionarios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$upd_funcionarios->setTable("funcionarios");
$upd_funcionarios->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond");
$upd_funcionarios->addColumn("foto_func", "FILE_TYPE", "FILES", "foto_func");
$upd_funcionarios->addColumn("nome_func", "STRING_TYPE", "POST", "nome_func");
$upd_funcionarios->addColumn("funcao_func", "STRING_TYPE", "POST", "funcao_func");
$upd_funcionarios->addColumn("expediente", "STRING_TYPE", "POST", "expediente");
$upd_funcionarios->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$upd_funcionarios->setPrimaryKey("id_func", "NUMERIC_TYPE", "GET", "id_func");

// Make an instance of the transaction object
$del_funcionarios = new tNG_multipleDelete($conn_gf_souto_conect);
$tNGs->addTransaction($del_funcionarios);
// Register triggers
$del_funcionarios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del_funcionarios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$del_funcionarios->setTable("funcionarios");
$del_funcionarios->setPrimaryKey("id_func", "NUMERIC_TYPE", "GET", "id_func");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rsfuncionarios = $tNGs->getRecordset("funcionarios");
$row_rsfuncionarios = mysql_fetch_assoc($rsfuncionarios);
$totalRows_rsfuncionarios = mysql_num_rows($rsfuncionarios);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="../includes/nxt/scripts/form.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/form.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: false,
  show_as_grid: true,
  merge_down_value: true
}
</script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01"><p>Atualizar funcionarios</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <div class="KT_tng">
        <?php /*?><h1>
          <?php 
// Show IF Conditional region1 
if (@$_GET['id_func'] == "") {
?>
            <?php echo NXT_getResource("Insert_FH"); ?>
            <?php 
// else Conditional region1
} else { ?>
            <?php echo NXT_getResource("Update_FH"); ?>
            <?php } 
// endif Conditional region1
?>
          Funcionarios </h1><?php */?>
        <div class="KT_tngform">
          <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" enctype="multipart/form-data">
            <?php $cnt1 = 0; ?>
            <?php do { ?>
              <?php $cnt1++; ?>
              <?php 
// Show IF Conditional region1 
if (@$totalRows_rsfuncionarios > 1) {
?>
                <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                <?php } 
// endif Conditional region1
?>
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="foto_func_<?php echo $cnt1; ?>">Foto:</label></td>
                  <td><input type="file" name="foto_func_<?php echo $cnt1; ?>" id="foto_func_<?php echo $cnt1; ?>" size="32" />
                    <?php echo $tNGs->displayFieldError("funcionarios", "foto_func", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="nome_func_<?php echo $cnt1; ?>">Nome:</label></td>
                  <td><input type="text" name="nome_func_<?php echo $cnt1; ?>" id="nome_func_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['nome_func']); ?>" size="32" maxlength="100" />
                    <?php echo $tNGs->displayFieldHint("nome_func");?> <?php echo $tNGs->displayFieldError("funcionarios", "nome_func", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="funcao_func_<?php echo $cnt1; ?>">Fun��o:</label></td>
                  <td><input type="text" name="funcao_func_<?php echo $cnt1; ?>" id="funcao_func_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['funcao_func']); ?>" size="30" maxlength="30" />
                    <?php echo $tNGs->displayFieldHint("funcao_func");?> <?php echo $tNGs->displayFieldError("funcionarios", "funcao_func", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="expediente_<?php echo $cnt1; ?>">Expediente:</label></td>
                  <td><input type="text" name="expediente_<?php echo $cnt1; ?>" id="expediente_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['expediente']); ?>" size="32" maxlength="50" />
                    <?php echo $tNGs->displayFieldHint("expediente");?> <?php echo $tNGs->displayFieldError("funcionarios", "expediente", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="ativo_<?php echo $cnt1; ?>">Ativo:</label></td>
                  <td><select name="ativo_<?php echo $cnt1; ?>" id="ativo_<?php echo $cnt1; ?>">
                    <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rsfuncionarios['ativo'])))) {echo "SELECTED";} ?>>sim</option>
                    <option value="0" <?php if (!(strcmp(0, KT_escapeAttribute($row_rsfuncionarios['ativo'])))) {echo "SELECTED";} ?>>n�o</option>
                  </select>
                    <?php echo $tNGs->displayFieldError("funcionarios", "ativo", $cnt1); ?></td>
                </tr>
              </table>
              <input type="hidden" name="kt_pk_funcionarios_<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['kt_pk_funcionarios']); ?>" />
              <input type="hidden" name="id_cond_<?php echo $cnt1; ?>" id="id_cond_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['id_cond']); ?>" />
              <?php } while ($row_rsfuncionarios = mysql_fetch_assoc($rsfuncionarios)); ?>
            <div class="KT_bottombuttons">
              <div>
                <?php 
      // Show IF Conditional region1
      if (@$_GET['id_func'] == "") {
      ?>
                  <?php 
      // else Conditional region1
      } else { ?>
                  <input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" />
                  <?php }
      // endif Conditional region1
      ?>
                <input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, '../includes/nxt/back.php')" />
              </div>
            </div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);
?>