
<script src="../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryMenuBarHorizontal_adm.css" rel="stylesheet" type="text/css">
<ul id="MenuBar1" class="MenuBarHorizontal">
  <li><a href="admin.php">In&iacute;cio</a></li>
  <li><a href="#" class="MenuBarItemSubmenu">Condom&iacute;nios</a>
    <ul>
      <?php if ($row_nomes['nivel'] >= 2 ) { ?>
      <li><a href="cadastrar_condominios.php">Cadastrar</a></li>
      <?php }?>
      <li><a href="listar_condominios.php">Atualizar</a></li>
    </ul>
  </li>
  <li><a href="#" class="MenuBarItemSubmenu">&Aacute;reas comuns</a>
    <ul>
      <li><a href="listar_area_nome.php">Atualizar</a></li>
    </ul>
  </li>
  <li><a href="#" class="MenuBarItemSubmenu">Aviso Geral</a>
    <ul>
<li><a href="listar_aviso.php">Atualizar</a></li>
    </ul>
  </li>
  <li><a href="#" class="MenuBarItemSubmenu">Classificados</a>
    <ul>
      <li><a href="#" class="MenuBarItemSubmenu">Categorias</a>
        <ul>
          <li><a href="cadastrar_categorias.php">Cadastrar</a></li>
          <li><a href="listar_categorias.php">Atualizar</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Anuncios</a>
        <ul>
          <li><a href="cadastrar_anuncios.php">Cadastrar</a></li>
          <li><a href="listar_anuncios.php">Atualizar</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li><a href="#" class="MenuBarItemSubmenu">P&aacute;ginas</a>
    <ul>
      <li><a href="#" class="MenuBarItemSubmenu">GF Souto</a>
        <ul>
          <li><a href="listar_pg_gfsouto.php">Atualizar</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Servi&ccedil;os</a>
        <ul>
          <li><a href="listar_pg_servicos.php">Atualizar</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Construtoras</a>
        <ul>
          <li><a href="listar_pg_construtoras.php">Atualizar</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Meio Ambiente</a>
        <ul>
          <li><a href="listar_pg_meio_ambiente.php">Atualizar</a></li>
        </ul>
      </li>
      <li><a href="#" class="MenuBarItemSubmenu">Implanta&ccedil;&atilde;o</a>
        <ul>
          <li><a href="listar_implantacao.php">Atualizar</a></li>
        </ul>
      </li>
    </ul>
  </li>
<?php if ($row_nomes['nivel'] >= 4 ) { ?>
  <li><a href="#" class="MenuBarItemSubmenu">Administra&ccedil;&atilde;o</a>
    <ul>
      <li><a href="#" class="MenuBarItemSubmenu">Usu&aacute;rios do sistema</a>
        <ul>
          <li><a href="cadastrar_usuarios.php">Cadastrar</a></li>
          <li><a href="listar_usuarios.php">Atualizar</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <?php }?>
  <li><a href="<?php echo $logoutAction ?>">Sair</a></li>
</ul>
<script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"../SpryAssets/SpryMenuBarDownHover.gif", imgRight:"../SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
