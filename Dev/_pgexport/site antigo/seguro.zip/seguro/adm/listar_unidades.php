<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the required classes
require_once('../includes/tfi/TFI.php');
require_once('../includes/tso/TSO.php');
require_once('../includes/nav/NAV.php');

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Filter
$tfi_listunidade_clientes3 = new TFI_TableFilter($conn_gf_souto_conect, "tfi_listunidade_clientes3");
$tfi_listunidade_clientes3->addColumn("condominios.id_cond", "STRING_TYPE", "id_cond", "%");
$tfi_listunidade_clientes3->addColumn("cadastro_clientes.id_cliente", "STRING_TYPE", "id_cliente", "%");
$tfi_listunidade_clientes3->addColumn("unidade_clientes.unidade", "STRING_TYPE", "unidade", "%");
$tfi_listunidade_clientes3->addColumn("unidade_clientes.senha", "STRING_TYPE", "senha", "%");
$tfi_listunidade_clientes3->Execute();

// Sorter
$tso_listunidade_clientes3 = new TSO_TableSorter("rsunidade_clientes1", "tso_listunidade_clientes3");
$tso_listunidade_clientes3->addColumn("condominios.nome_cond");
$tso_listunidade_clientes3->addColumn("cadastro_clientes.nome");
$tso_listunidade_clientes3->addColumn("unidade_clientes.unidade");
$tso_listunidade_clientes3->addColumn("unidade_clientes.senha");
$tso_listunidade_clientes3->setDefault("unidade_clientes.id_cond");
$tso_listunidade_clientes3->Execute();

// Navigation
$nav_listunidade_clientes3 = new NAV_Regular("nav_listunidade_clientes3", "rsunidade_clientes1", "../", $_SERVER['PHP_SELF'], 50);

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset1 = "SELECT nome_cond, id_cond FROM condominios ORDER BY nome_cond";
$Recordset1 = mysql_query($query_Recordset1, $gf_souto_conect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset2 = "SELECT nome, id_cliente FROM cadastro_clientes ORDER BY nome";
$Recordset2 = mysql_query($query_Recordset2, $gf_souto_conect) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);

//NeXTenesio3 Special List Recordset
$maxRows_rsunidade_clientes1 = $_SESSION['max_rows_nav_listunidade_clientes3'];
$pageNum_rsunidade_clientes1 = 0;
if (isset($_GET['pageNum_rsunidade_clientes1'])) {
  $pageNum_rsunidade_clientes1 = $_GET['pageNum_rsunidade_clientes1'];
}
$startRow_rsunidade_clientes1 = $pageNum_rsunidade_clientes1 * $maxRows_rsunidade_clientes1;

// Defining List Recordset variable
$NXTFilter_rsunidade_clientes1 = "1=1";
if (isset($_SESSION['filter_tfi_listunidade_clientes3'])) {
  $NXTFilter_rsunidade_clientes1 = $_SESSION['filter_tfi_listunidade_clientes3'];
}
// Defining List Recordset variable
$NXTSort_rsunidade_clientes1 = "unidade_clientes.id_cond";
if (isset($_SESSION['sorter_tso_listunidade_clientes3'])) {
  $NXTSort_rsunidade_clientes1 = $_SESSION['sorter_tso_listunidade_clientes3'];
}
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);

$query_rsunidade_clientes1 = "SELECT condominios.nome_cond AS id_cond, cadastro_clientes.nome AS id_cliente, unidade_clientes.unidade, unidade_clientes.senha, unidade_clientes.id_acesso FROM (unidade_clientes LEFT JOIN condominios ON unidade_clientes.id_cond = condominios.id_cond) LEFT JOIN cadastro_clientes ON unidade_clientes.id_cliente = cadastro_clientes.id_cliente WHERE {$NXTFilter_rsunidade_clientes1} ORDER BY {$NXTSort_rsunidade_clientes1}";
$query_limit_rsunidade_clientes1 = sprintf("%s LIMIT %d, %d", $query_rsunidade_clientes1, $startRow_rsunidade_clientes1, $maxRows_rsunidade_clientes1);
$rsunidade_clientes1 = mysql_query($query_limit_rsunidade_clientes1, $gf_souto_conect) or die(mysql_error());
$row_rsunidade_clientes1 = mysql_fetch_assoc($rsunidade_clientes1);

if (isset($_GET['totalRows_rsunidade_clientes1'])) {
  $totalRows_rsunidade_clientes1 = $_GET['totalRows_rsunidade_clientes1'];
} else {
  $all_rsunidade_clientes1 = mysql_query($query_rsunidade_clientes1);
  $totalRows_rsunidade_clientes1 = mysql_num_rows($all_rsunidade_clientes1);
}
$totalPages_rsunidade_clientes1 = ceil($totalRows_rsunidade_clientes1/$maxRows_rsunidade_clientes1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listunidade_clientes3->checkBoundries();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: false,
  duplicate_navigation: false,
  row_effects: true,
  show_as_buttons: true,
  record_counter: false
}
</script>
<style type="text/css">
  /* Dynamic List row settings */
  .KT_col_id_cond {width:210px; overflow:hidden;}
  .KT_col_id_cliente {width:56px; overflow:hidden;}
  .KT_col_unidade {width:140px; overflow:hidden;}
  .KT_col_senha {width:140px; overflow:hidden;}
</style>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Unidades Cadastradas</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <div class="KT_tng" id="listunidade_clientes3">
        <h1> Listando
          <?php
  $nav_listunidade_clientes3->Prepare();
  require("../includes/nav/NAV_Text_Statistics.inc.php");
?>
        unidades cadastradas</h1>
        <div class="KT_tnglist">
          <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" id="form1">
            <div class="KT_options"> <a href="<?php echo $nav_listunidade_clientes3->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
              <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listunidade_clientes3'] == 1) {
?>
                <?php echo $_SESSION['default_max_rows_nav_listunidade_clientes3']; ?>
                <?php 
  // else Conditional region1
  } else { ?>
                <?php echo NXT_getResource("all"); ?>
                <?php } 
  // endif Conditional region1
?>
<?php echo NXT_getResource("records"); ?></a> &nbsp;
              &nbsp;
              <?php 
  // Show IF Conditional region2
  if (@$_SESSION['has_filter_tfi_listunidade_clientes3'] == 1) {
?>
                <a href="<?php echo $tfi_listunidade_clientes3->getResetFilterLink(); ?>"><?php echo NXT_getResource("Reset filter"); ?></a>
                <?php 
  // else Conditional region2
  } else { ?>
                <a href="<?php echo $tfi_listunidade_clientes3->getShowFilterLink(); ?>"><?php echo NXT_getResource("Show filter"); ?></a>
                <?php } 
  // endif Conditional region2
?>
            </div>
            <table cellpadding="2" cellspacing="0" class="KT_tngtable">
              <thead>
                <tr class="KT_row_order">
                  <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                  </th>
                  <th id="id_cond" class="KT_sorter KT_col_id_cond <?php echo $tso_listunidade_clientes3->getSortIcon('condominios.nome_cond'); ?>"> <a href="<?php echo $tso_listunidade_clientes3->getSortLink('condominios.nome_cond'); ?>">Condom�nio</a></th>
                  <th id="id_cliente" class="KT_sorter KT_col_id_cliente <?php echo $tso_listunidade_clientes3->getSortIcon('cadastro_clientes.nome'); ?>"> <a href="<?php echo $tso_listunidade_clientes3->getSortLink('cadastro_clientes.nome'); ?>">Cliente</a></th>
                  <th id="unidade" class="KT_sorter KT_col_unidade <?php echo $tso_listunidade_clientes3->getSortIcon('unidade_clientes.unidade'); ?>"> <a href="<?php echo $tso_listunidade_clientes3->getSortLink('unidade_clientes.unidade'); ?>">Unidade</a></th>
                  <th id="senha" class="KT_sorter KT_col_senha <?php echo $tso_listunidade_clientes3->getSortIcon('unidade_clientes.senha'); ?>"> <a href="<?php echo $tso_listunidade_clientes3->getSortLink('unidade_clientes.senha'); ?>">Senha</a></th>
                  <th>&nbsp;</th>
                </tr>
                <?php 
  // Show IF Conditional region3
  if (@$_SESSION['has_filter_tfi_listunidade_clientes3'] == 1) {
?>
                  <tr class="KT_row_filter">
                    <td>&nbsp;</td>
                    <td><select name="tfi_listunidade_clientes3_id_cond" id="tfi_listunidade_clientes3_id_cond">
                      <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listunidade_clientes3_id_cond']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                      <?php
do {  
?>
                      <option value="<?php echo $row_Recordset1['id_cond']?>"<?php if (!(strcmp($row_Recordset1['id_cond'], @$_SESSION['tfi_listunidade_clientes3_id_cond']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['nome_cond']?></option>
                      <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                    </select></td>
                    <td><select name="tfi_listunidade_clientes3_id_cliente" id="tfi_listunidade_clientes3_id_cliente">
                      <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listunidade_clientes3_id_cliente']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                      <?php
do {  
?>
                      <option value="<?php echo $row_Recordset2['id_cliente']?>"<?php if (!(strcmp($row_Recordset2['id_cliente'], @$_SESSION['tfi_listunidade_clientes3_id_cliente']))) {echo "SELECTED";} ?>><?php echo $row_Recordset2['nome']?></option>
                      <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
  $rows = mysql_num_rows($Recordset2);
  if($rows > 0) {
      mysql_data_seek($Recordset2, 0);
	  $row_Recordset2 = mysql_fetch_assoc($Recordset2);
  }
?>
                    </select></td>
                    <td><input type="text" name="tfi_listunidade_clientes3_unidade" id="tfi_listunidade_clientes3_unidade" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listunidade_clientes3_unidade']); ?>" size="20" maxlength="30" /></td>
                    <td><input type="text" name="tfi_listunidade_clientes3_senha" id="tfi_listunidade_clientes3_senha" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listunidade_clientes3_senha']); ?>" size="20" maxlength="20" /></td>
                    <td><input type="submit" name="tfi_listunidade_clientes3" value="<?php echo NXT_getResource("Filter"); ?>" /></td>
                  </tr>
                  <?php } 
  // endif Conditional region3
?>
              </thead>
              <tbody>
                <?php if ($totalRows_rsunidade_clientes1 == 0) { // Show if recordset empty ?>
                  <tr>
                    <td colspan="6"><?php echo NXT_getResource("The table is empty or the filter you've selected is too restrictive."); ?></td>
                  </tr>
                  <?php } // Show if recordset empty ?>
                <?php if ($totalRows_rsunidade_clientes1 > 0) { // Show if recordset not empty ?>
                  <?php do { ?>
                    <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                      <td><input type="checkbox" name="kt_pk_unidade_clientes" class="id_checkbox" value="<?php echo $row_rsunidade_clientes1['id_acesso']; ?>" />
                        <input type="hidden" name="id_acesso" class="id_field" value="<?php echo $row_rsunidade_clientes1['id_acesso']; ?>" /></td>
                      <td><div class="KT_col_id_cond"><?php echo KT_FormatForList($row_rsunidade_clientes1['id_cond'], 30); ?></div></td>
                      <td><div class="KT_col_id_cliente"><?php echo KT_FormatForList($row_rsunidade_clientes1['id_cliente'], 8); ?></div></td>
                      <td><div class="KT_col_unidade"><?php echo KT_FormatForList($row_rsunidade_clientes1['unidade'], 20); ?></div></td>
                      <td><div class="KT_col_senha"><?php echo KT_FormatForList($row_rsunidade_clientes1['senha'], 20); ?></div></td>
                      <td><a class="KT_edit_link" href="listar_unidades.php?id_acesso=<?php echo $row_rsunidade_clientes1['id_acesso']; ?>&amp;KT_back=1"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("edit_one"); ?><?php }?></a> <a class="KT_delete_link" href="#delete"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("delete_one"); ?><?php }?></a></td>
                    </tr>
                    <?php } while ($row_rsunidade_clientes1 = mysql_fetch_assoc($rsunidade_clientes1)); ?>
                  <?php } // Show if recordset not empty ?>
              </tbody>
            </table>
            <div class="KT_bottomnav">
              <div>
                <?php
            $nav_listunidade_clientes3->Prepare();
            require("../includes/nav/NAV_Text_Navigation.inc.php");
          ?>
              </div>
            </div>
            <div class="KT_bottombuttons">
              <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php echo NXT_getResource("edit_all"); ?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php echo NXT_getResource("delete_all"); ?></a></div>
              <span>&nbsp;</span></div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($Recordset1);

mysql_free_result($Recordset2);

mysql_free_result($rsunidade_clientes1);
?>
