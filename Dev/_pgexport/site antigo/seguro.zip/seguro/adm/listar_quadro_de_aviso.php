<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');

// Load the required classes
require_once('../includes/tfi/TFI.php');
require_once('../includes/tso/TSO.php');
require_once('../includes/nav/NAV.php');

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");
?>
<?php
// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("texto_mural", true, "text", "", "", "", "");
$formValidation->addField("data_publi", true, "date", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Filter
$tfi_listmural3 = new TFI_TableFilter($conn_gf_souto_conect, "tfi_listmural3");
$tfi_listmural3->addColumn("condominios.nome_cond", "STRING_TYPE", "id_cond", "%");
$tfi_listmural3->addColumn("mural.texto_mural", "STRING_TYPE", "texto_mural", "%");
$tfi_listmural3->addColumn("mural.data_publi", "DATE_TYPE", "data_publi", "=");
$tfi_listmural3->addColumn("mural.ativo", "STRING_TYPE", "ativo", "%");
$tfi_listmural3->Execute();

// Sorter
$tso_listmural3 = new TSO_TableSorter("rsmural1", "tso_listmural3");
$tso_listmural3->addColumn("condominios.id_cond");
$tso_listmural3->addColumn("mural.texto_mural");
$tso_listmural3->addColumn("mural.data_publi");
$tso_listmural3->addColumn("mural.ativo");
$tso_listmural3->setDefault("mural.id_cond");
$tso_listmural3->Execute();

// Navigation
$nav_listmural3 = new NAV_Regular("nav_listmural3", "rsmural1", "../", $_SERVER['PHP_SELF'], 10);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset1 = "SELECT id_cond, nome_cond FROM condominios ORDER BY id_cond";
$Recordset1 = mysql_query($query_Recordset1, $gf_souto_conect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_mural = new tNG_insert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_mural);
// Register triggers
$ins_mural->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_mural->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_mural->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_quadro_de_aviso.php?id_cond=".$_GET['id_cond']);
// Add columns
$ins_mural->setTable("mural");
$ins_mural->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond", "{GET.id_cond}");
$ins_mural->addColumn("texto_mural", "STRING_TYPE", "POST", "texto_mural");
$ins_mural->addColumn("data_publi", "DATE_TYPE", "POST", "data_publi");
$ins_mural->addColumn("ativo", "STRING_TYPE", "POST", "ativo", "1");
$ins_mural->setPrimaryKey("id_mural", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

//NeXTenesio3 Special List Recordset
$maxRows_rsmural1 = $_SESSION['max_rows_nav_listmural3'];
$pageNum_rsmural1 = 0;
if (isset($_GET['pageNum_rsmural1'])) {
  $pageNum_rsmural1 = $_GET['pageNum_rsmural1'];
}
$startRow_rsmural1 = $pageNum_rsmural1 * $maxRows_rsmural1;

// Defining List Recordset variable
$NXTFilter_rsmural1 = "1=1";
if (isset($_SESSION['filter_tfi_listmural3'])) {
  $NXTFilter_rsmural1 = $_SESSION['filter_tfi_listmural3'];
}
// Defining List Recordset variable
$NXTSort_rsmural1 = "mural.id_cond";
if (isset($_SESSION['sorter_tso_listmural3'])) {
  $NXTSort_rsmural1 = $_SESSION['sorter_tso_listmural3'];
}
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);

$query_rsmural1 = "SELECT condominios.id_cond AS id_cond, mural.texto_mural, mural.data_publi, mural.ativo, mural.id_mural FROM mural LEFT JOIN condominios ON mural.id_cond = condominios.nome_cond WHERE {$NXTFilter_rsmural1} AND mural.id_cond = ".$_GET['id_cond']." ORDER BY {$NXTSort_rsmural1}";
$query_limit_rsmural1 = sprintf("%s LIMIT %d, %d", $query_rsmural1, $startRow_rsmural1, $maxRows_rsmural1);
$rsmural1 = mysql_query($query_limit_rsmural1, $gf_souto_conect) or die(mysql_error());
$row_rsmural1 = mysql_fetch_assoc($rsmural1);

if (isset($_GET['totalRows_rsmural1'])) {
  $totalRows_rsmural1 = $_GET['totalRows_rsmural1'];
} else {
  $all_rsmural1 = mysql_query($query_rsmural1);
  $totalRows_rsmural1 = mysql_num_rows($all_rsmural1);
}
$totalPages_rsmural1 = ceil($totalRows_rsmural1/$maxRows_rsmural1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listmural3->checkBoundries();

// Get the transaction recordset
$rsmural = $tNGs->getRecordset("mural");
$row_rsmural = mysql_fetch_assoc($rsmural);
$totalRows_rsmural = mysql_num_rows($rsmural);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: false,
  duplicate_navigation: false,
  row_effects: true,
  show_as_buttons: true,
  record_counter: false
}
</script>
<style type="text/css">
  /* Dynamic List row settings */
  .KT_col_id_cond {width:140px; overflow:hidden;}
  .KT_col_texto_mural {width:280px; overflow:hidden;}
  .KT_col_data_publi {width:140px; overflow:hidden;}
  .KT_col_ativo {width:140px; overflow:hidden;}
</style>



<!--IN�CIO DO TEXT �REA DIM�MICO-->
<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "simple",
		//theme : "advanced",
		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,sub,sup,|,bullist,numlist,|,outdent,indent,blockquote,|,cut,copy,paste,pastetext,|,undo,redo,|,link,unlink,anchor",
		/*theme_advanced_buttons2 : "tablecontrols",*/
		
		/*//* Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak",
		*/
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// ---------------------------------------
		content_css : "exemples/css/content.css",

		// --------------------------
		//template_external_list_url : "exemples/lists/template_list.js",
		//external_link_list_url : "exemples/lists/link_list.js",
		//external_image_list_url : "exemples/lists/image_list.js",
		//media_external_list_url : "exemples/lists/media_list.js",

		// --------------------------
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>
<!--FIM DO TEXT �REA DIM�MICO-->

<?php echo $tNGs->displayValidationRules();?>
<script type="text/javascript" src="../includes/common/js/sigslot_core.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="../includes/resources/calendar.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Quadro de aviso 
    <?php 
	
	
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$_GET['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

echo '<b>'.$row_condominio['nome_cond'].'</b>';

 ?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form2" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th"><label for="texto_mural">Aviso:</label></td>
            <td><textarea name="texto_mural" id="texto_mural" cols="80" rows="15"><?php echo KT_escapeAttribute($row_rsmural['texto_mural']); ?></textarea>
            <?php echo $tNGs->displayFieldHint("texto_mural");?> <?php echo $tNGs->displayFieldError("mural", "texto_mural"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="data_publi">Data:</label></td>
            <td><input name="data_publi" id="data_publi" value="<?php echo KT_formatDate($row_rsmural['data_publi']); ?>" size="32" wdg:mondayfirst="false" wdg:subtype="Calendar" wdg:mask="<?php echo $KT_screen_date_format; ?>" wdg:type="widget" wdg:singleclick="false" wdg:restricttomask="no" wdg:readonly="true" />
              <?php echo $tNGs->displayFieldHint("data_publi");?> <?php echo $tNGs->displayFieldError("mural", "data_publi"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar aviso" /></td>
          </tr>
        </table>
        <input type="hidden" name="id_cond" id="id_cond" value="<?php echo KT_escapeAttribute($row_rsmural['id_cond']); ?>" />
        <input type="hidden" name="ativo" id="ativo" value="<?php echo KT_escapeAttribute($row_rsmural['ativo']); ?>" />
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <div class="KT_tng" id="listmural3">
        <?php /*?><h1> Mural
          <?php
  $nav_listmural3->Prepare();
  require("../includes/nav/NAV_Text_Statistics.inc.php");
?>
        </h1><?php */?>
        <div class="KT_tnglist">
          <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" id="form1">
            <div class="KT_options"> <a href="<?php echo $nav_listmural3->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
              <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listmural3'] == 1) {
?>
                <?php echo $_SESSION['default_max_rows_nav_listmural3']; ?>
                <?php 
  // else Conditional region1
  } else { ?>
                <?php echo NXT_getResource("all"); ?>
                <?php } 
  // endif Conditional region1
?>
<?php echo NXT_getResource("records"); ?></a> &nbsp;
              &nbsp; </div>
            <table cellpadding="2" cellspacing="0" class="KT_tngtable">
              <thead>
                <tr class="KT_row_order">
                  <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                  </th>
                  <th id="texto_mural" class="KT_sorter KT_col_texto_mural <?php echo $tso_listmural3->getSortIcon('mural.texto_mural'); ?>"> <a href="<?php echo $tso_listmural3->getSortLink('mural.texto_mural'); ?>">Aviso</a></th>
                  <th id="data_publi" class="KT_sorter KT_col_data_publi <?php echo $tso_listmural3->getSortIcon('mural.data_publi'); ?>"> <a href="<?php echo $tso_listmural3->getSortLink('mural.data_publi'); ?>">Data</a></th>
                  <th id="ativo" class="KT_sorter KT_col_ativo <?php echo $tso_listmural3->getSortIcon('mural.ativo'); ?>"> <a href="<?php echo $tso_listmural3->getSortLink('mural.ativo'); ?>">Ativo</a></th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($totalRows_rsmural1 == 0) { // Show if recordset empty ?>
                  <tr>
                    <td colspan="5"><?php echo NXT_getResource("Nenhum resultado encontrado."); ?></td>
                  </tr>
                  <?php } // Show if recordset empty ?>
                <?php if ($totalRows_rsmural1 > 0) { // Show if recordset not empty ?>
                  <?php do { ?>
                    <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                      <td><input type="checkbox" name="kt_pk_mural" class="id_checkbox" value="<?php echo $row_rsmural1['id_mural']; ?>" />
                        <input type="hidden" name="id_mural" class="id_field" value="<?php echo $row_rsmural1['id_mural']; ?>" /></td>
                      <td><div class="KT_col_texto_mural"><?php echo KT_FormatForList($row_rsmural1['texto_mural'], 40); ?></div></td>
                      <td><div class="KT_col_data_publi"><?php echo KT_formatDate($row_rsmural1['data_publi']); ?></div></td>
                      <td><div class="KT_col_ativo"><?php echo KT_FormatForList($row_rsmural1['ativo'], 20); ?></div></td>
                      <td><a class="KT_edit_link" href="atualizar_quadro_de_aviso.php?id_mural=<?php echo $row_rsmural1['id_mural']; ?>&amp;KT_back=1"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("edit_one"); ?><?php }?></a> <a class="KT_delete_link" href="#delete"><?php if ($row_nomes['nivel'] >= 4) { ?><?php echo NXT_getResource("delete_one"); ?><?php }?></a></td>
                    </tr>
                    <?php } while ($row_rsmural1 = mysql_fetch_assoc($rsmural1)); ?>
                  <?php } // Show if recordset not empty ?>
              </tbody>
            </table>
            <div class="KT_bottomnav">
              <div>
                <?php
            $nav_listmural3->Prepare();
            require("../includes/nav/NAV_Text_Navigation.inc.php");
          ?>
              </div>
            </div>
            <div class="KT_bottombuttons">
              <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("edit_all"); ?><?php }?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 4 ) { ?><?php echo NXT_getResource("delete_all"); ?><?php }?></a></div>
              <span>&nbsp;</span></div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($nomes);

mysql_free_result($rsmural1);
?>
