<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("categoria_gf_clas", true, "text", "", "", "", "");
$formValidation->addField("nome_estabelecimento", true, "text", "", "", "", "");
$formValidation->addField("descricao", true, "text", "", "", "", "");
$formValidation->addField("telefone1", true, "text", "", "", "", "");
$formValidation->addField("email1", true, "text", "", "", "", "");
$formValidation->addField("endereco", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

//start Trigger_ImageUpload trigger
//remove this line if you want to edit the code by hand 
function Trigger_ImageUpload(&$tNG) {
  $uploadObj = new tNG_ImageUpload($tNG);
  $uploadObj->setFormFieldName("logomarca");
  $uploadObj->setDbFieldName("logomarca");
  $uploadObj->setFolder("../classificados_gf_souto/{id_gf_clas}/");
  $uploadObj->setResize("true", 150, 0);
  $uploadObj->setMaxSize(2000);
  $uploadObj->setAllowedExtensions("jpg, jpeg, JPG, JPEG");
  $uploadObj->setRename("auto");
  return $uploadObj->Execute();
}
//end Trigger_ImageUpload trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset1 = "SELECT nome_gf_clas, id_gf_cat FROM gf_categorias ORDER BY nome_gf_clas";
$Recordset1 = mysql_query($query_Recordset1, $gf_souto_conect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

// Make an insert transaction instance
$ins_gf_classificado = new tNG_insert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_gf_classificado);
// Register triggers
$ins_gf_classificado->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_gf_classificado->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_gf_classificado->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_anuncios.php");
$ins_gf_classificado->registerTrigger("AFTER", "Trigger_ImageUpload", 97);
// Add columns
$ins_gf_classificado->setTable("gf_classificado");
$ins_gf_classificado->addColumn("logomarca", "FILE_TYPE", "FILES", "logomarca");
$ins_gf_classificado->addColumn("categoria_gf_clas", "STRING_TYPE", "POST", "categoria_gf_clas");
$ins_gf_classificado->addColumn("nome_estabelecimento", "STRING_TYPE", "POST", "nome_estabelecimento");
$ins_gf_classificado->addColumn("descricao", "STRING_TYPE", "POST", "descricao");
$ins_gf_classificado->addColumn("telefone1", "STRING_TYPE", "POST", "telefone1");
$ins_gf_classificado->addColumn("telefone2", "STRING_TYPE", "POST", "telefone2");
$ins_gf_classificado->addColumn("email1", "STRING_TYPE", "POST", "email1");
$ins_gf_classificado->addColumn("email_2", "STRING_TYPE", "POST", "email_2");
$ins_gf_classificado->addColumn("website", "STRING_TYPE", "POST", "website");
$ins_gf_classificado->addColumn("endereco", "STRING_TYPE", "POST", "endereco");
$ins_gf_classificado->addColumn("google_Maps", "STRING_TYPE", "POST", "google_Maps");
$ins_gf_classificado->setPrimaryKey("id_gf_clas", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rsgf_classificado = $tNGs->getRecordset("gf_classificado");
$row_rsgf_classificado = mysql_fetch_assoc($rsgf_classificado);
$totalRows_rsgf_classificado = mysql_num_rows($rsgf_classificado);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/MaskedInput.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Cadastrar an&uacute;ncios</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" enctype="multipart/form-data">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th"><label for="logomarca">Logomarca:</label></td>
            <td><input type="file" name="logomarca" id="logomarca" size="32" />
              <?php echo $tNGs->displayFieldError("gf_classificado", "logomarca"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="categoria_gf_clas">Categoria:</label></td>
            <td><select name="categoria_gf_clas" id="categoria_gf_clas">
              <?php 
do {  
?>
              <option value="<?php echo $row_Recordset1['id_gf_cat']?>"<?php if (!(strcmp($row_Recordset1['id_gf_cat'], $row_rsgf_classificado['categoria_gf_clas']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['nome_gf_clas']?></option>
              <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
            </select>
              <?php echo $tNGs->displayFieldError("gf_classificado", "categoria_gf_clas"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="nome_estabelecimento">Anunciante:</label></td>
            <td><input type="text" name="nome_estabelecimento" id="nome_estabelecimento" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['nome_estabelecimento']); ?>" size="60" />
            <?php echo $tNGs->displayFieldHint("nome_estabelecimento");?> <?php echo $tNGs->displayFieldError("gf_classificado", "nome_estabelecimento"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="telefone1">Fone 1:</label></td>
            <td><input name="telefone1" id="telefone1" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['telefone1']); ?>" size="40" wdg:subtype="MaskedInput" wdg:mask="(99) 9999 - 9999" wdg:restricttomask="no" wdg:type="widget" />
            <?php echo $tNGs->displayFieldHint("telefone1");?> <?php echo $tNGs->displayFieldError("gf_classificado", "telefone1"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="telefone2">Fone 2:</label></td>
            <td><input name="telefone2" id="telefone2" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['telefone2']); ?>" size="40" wdg:subtype="MaskedInput" wdg:mask="(99) 9999 - 9999" wdg:restricttomask="no" wdg:type="widget" />
            <?php echo $tNGs->displayFieldHint("telefone2");?> <?php echo $tNGs->displayFieldError("gf_classificado", "telefone2"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="email1">Email 1:</label></td>
            <td><input type="text" name="email1" id="email1" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['email1']); ?>" size="60" />
            <?php echo $tNGs->displayFieldHint("email1");?> <?php echo $tNGs->displayFieldError("gf_classificado", "email1"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="email_2">Email 2:</label></td>
            <td><input type="text" name="email_2" id="email_2" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['email_2']); ?>" size="60" />
            <?php echo $tNGs->displayFieldHint("email_2");?> <?php echo $tNGs->displayFieldError("gf_classificado", "email_2"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="website">Website:</label></td>
            <td><input type="text" name="website" id="website" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['website']); ?>" size="60" />
              <?php echo $tNGs->displayFieldHint("website");?> <?php echo $tNGs->displayFieldError("gf_classificado", "website"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="endereco">Endere�o:</label></td>
            <td><input type="text" name="endereco" id="endereco" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['endereco']); ?>" size="60" />
              <?php echo $tNGs->displayFieldHint("endereco");?> <?php echo $tNGs->displayFieldError("gf_classificado", "endereco"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="descricao">Descri��o:</label></td>
            <td><textarea name="descricao" id="descricao" cols="80" rows="5"><?php echo KT_escapeAttribute($row_rsgf_classificado['descricao']); ?></textarea>
            <?php echo $tNGs->displayFieldHint("descricao");?> <?php echo $tNGs->displayFieldError("gf_classificado", "descricao"); ?></td>
          </tr>
          
          <tr>
            <td class="KT_th"><label for="google_Maps">Link google Maps:</label></td>
            <td><input type="text" name="google_Maps" id="google_Maps" value="<?php echo KT_escapeAttribute($row_rsgf_classificado['google_Maps']); ?>" size="100" />
              <?php echo $tNGs->displayFieldHint("google_Maps");?> <?php echo $tNGs->displayFieldError("gf_classificado", "google_Maps"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar" /></td>
          </tr>
        </table>
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($Recordset1);
?>
