<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the required classes
require_once('../includes/tfi/TFI.php');
require_once('../includes/tso/TSO.php');
require_once('../includes/nav/NAV.php');

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Filter
$tfi_listmural1 = new TFI_TableFilter($conn_gf_souto_conect, "tfi_listmural1");
$tfi_listmural1->addColumn("condominios.id_cond", "STRING_TYPE", "id_cond", "%");
$tfi_listmural1->addColumn("mural.texto_mural", "STRING_TYPE", "texto_mural", "%");
$tfi_listmural1->addColumn("mural.data_publi", "DATE_TYPE", "data_publi", "=");
$tfi_listmural1->addColumn("mural.ativo", "STRING_TYPE", "ativo", "%");
$tfi_listmural1->Execute();

// Sorter
$tso_listmural1 = new TSO_TableSorter("rsmural1", "tso_listmural1");
$tso_listmural1->addColumn("condominios.nome_cond");
$tso_listmural1->addColumn("mural.texto_mural");
$tso_listmural1->addColumn("mural.data_publi");
$tso_listmural1->addColumn("mural.ativo");
$tso_listmural1->setDefault("mural.id_cond");
$tso_listmural1->Execute();

// Navigation
$nav_listmural1 = new NAV_Regular("nav_listmural1", "rsmural1", "../", $_SERVER['PHP_SELF'], 10);

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_Recordset1 = "SELECT nome_cond, id_cond FROM condominios ORDER BY nome_cond";
$Recordset1 = mysql_query($query_Recordset1, $gf_souto_conect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

//NeXTenesio3 Special List Recordset
$maxRows_rsmural1 = $_SESSION['max_rows_nav_listmural1'];
$pageNum_rsmural1 = 0;
if (isset($_GET['pageNum_rsmural1'])) {
  $pageNum_rsmural1 = $_GET['pageNum_rsmural1'];
}
$startRow_rsmural1 = $pageNum_rsmural1 * $maxRows_rsmural1;

// Defining List Recordset variable
$NXTFilter_rsmural1 = "1=1";
if (isset($_SESSION['filter_tfi_listmural1'])) {
  $NXTFilter_rsmural1 = $_SESSION['filter_tfi_listmural1'];
}
// Defining List Recordset variable
$NXTSort_rsmural1 = "mural.id_cond";
if (isset($_SESSION['sorter_tso_listmural1'])) {
  $NXTSort_rsmural1 = $_SESSION['sorter_tso_listmural1'];
}
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);

$query_rsmural1 = "SELECT condominios.nome_cond AS id_cond, mural.texto_mural, mural.data_publi, mural.ativo, mural.id_mural FROM mural LEFT JOIN condominios ON mural.id_cond = condominios.id_cond WHERE {$NXTFilter_rsmural1} ORDER BY {$NXTSort_rsmural1}";
$query_limit_rsmural1 = sprintf("%s LIMIT %d, %d", $query_rsmural1, $startRow_rsmural1, $maxRows_rsmural1);
$rsmural1 = mysql_query($query_limit_rsmural1, $gf_souto_conect) or die(mysql_error());
$row_rsmural1 = mysql_fetch_assoc($rsmural1);

if (isset($_GET['totalRows_rsmural1'])) {
  $totalRows_rsmural1 = $_GET['totalRows_rsmural1'];
} else {
  $all_rsmural1 = mysql_query($query_rsmural1);
  $totalRows_rsmural1 = mysql_num_rows($all_rsmural1);
}
$totalPages_rsmural1 = ceil($totalRows_rsmural1/$maxRows_rsmural1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listmural1->checkBoundries();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: false,
  duplicate_navigation: false,
  row_effects: true,
  show_as_buttons: true,
  record_counter: false
}
</script>
<style type="text/css">
  /* Dynamic List row settings */
  .KT_col_id_cond {width:210px; overflow:hidden;}
  .KT_col_texto_mural {width:245px; overflow:hidden;}
  .KT_col_data_publi {width:140px; overflow:hidden;}
  .KT_col_ativo {width:14px; overflow:hidden;}
</style>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Quadro aviso condom&iacute;nios</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <div class="KT_tng" id="listmural1">
        <h1> Listando
          <?php
  $nav_listmural1->Prepare();
  require("../includes/nav/NAV_Text_Statistics.inc.php");
?>
        avisos cadastrados</h1>
        <div class="KT_tnglist">
          <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" id="form1">
            <div class="KT_options"> <a href="<?php echo $nav_listmural1->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
              <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listmural1'] == 1) {
?>
                <?php echo $_SESSION['default_max_rows_nav_listmural1']; ?>
                <?php 
  // else Conditional region1
  } else { ?>
                <?php echo NXT_getResource("all"); ?>
                <?php } 
  // endif Conditional region1
?>
<?php echo NXT_getResource("records"); ?></a> &nbsp;
              &nbsp;
              <?php 
  // Show IF Conditional region2
  if (@$_SESSION['has_filter_tfi_listmural1'] == 1) {
?>
                <a href="<?php echo $tfi_listmural1->getResetFilterLink(); ?>"><?php echo NXT_getResource("Reset filter"); ?></a>
                <?php 
  // else Conditional region2
  } else { ?>
                <a href="<?php echo $tfi_listmural1->getShowFilterLink(); ?>"><?php echo NXT_getResource("Show filter"); ?></a>
                <?php } 
  // endif Conditional region2
?>
            </div>
            <table cellpadding="2" cellspacing="0" class="KT_tngtable">
              <thead>
                <tr class="KT_row_order">
                  <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                  </th>
                  <th id="id_cond" class="KT_sorter KT_col_id_cond <?php echo $tso_listmural1->getSortIcon('condominios.nome_cond'); ?>"> <a href="<?php echo $tso_listmural1->getSortLink('condominios.nome_cond'); ?>">Condom�nio</a></th>
                  <th id="texto_mural" class="KT_sorter KT_col_texto_mural <?php echo $tso_listmural1->getSortIcon('mural.texto_mural'); ?>"> <a href="<?php echo $tso_listmural1->getSortLink('mural.texto_mural'); ?>">Texto</a></th>
                  <th id="data_publi" class="KT_sorter KT_col_data_publi <?php echo $tso_listmural1->getSortIcon('mural.data_publi'); ?>"> <a href="<?php echo $tso_listmural1->getSortLink('mural.data_publi'); ?>">Data</a></th>
                  <th id="ativo" class="KT_sorter KT_col_ativo <?php echo $tso_listmural1->getSortIcon('mural.ativo'); ?>"> <a href="<?php echo $tso_listmural1->getSortLink('mural.ativo'); ?>">Ativo</a></th>
                  <th>&nbsp;</th>
                </tr>
                <?php 
  // Show IF Conditional region3
  if (@$_SESSION['has_filter_tfi_listmural1'] == 1) {
?>
                  <tr class="KT_row_filter">
                    <td>&nbsp;</td>
                    <td><select name="tfi_listmural1_id_cond" id="tfi_listmural1_id_cond">
                      <option value="" <?php if (!(strcmp("", @$_SESSION['tfi_listmural1_id_cond']))) {echo "SELECTED";} ?>><?php echo NXT_getResource("None"); ?></option>
                      <?php
do {  
?>
                      <option value="<?php echo $row_Recordset1['id_cond']?>"<?php if (!(strcmp($row_Recordset1['id_cond'], @$_SESSION['tfi_listmural1_id_cond']))) {echo "SELECTED";} ?>><?php echo $row_Recordset1['nome_cond']?></option>
                      <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                    </select></td>
                    <td><input type="text" name="tfi_listmural1_texto_mural" id="tfi_listmural1_texto_mural" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listmural1_texto_mural']); ?>" size="35" maxlength="100" /></td>
                    <td><input type="text" name="tfi_listmural1_data_publi" id="tfi_listmural1_data_publi" value="<?php echo @$_SESSION['tfi_listmural1_data_publi']; ?>" size="10" maxlength="22" /></td>
                    <td><input type="text" name="tfi_listmural1_ativo" id="tfi_listmural1_ativo" value="<?php echo KT_escapeAttribute(@$_SESSION['tfi_listmural1_ativo']); ?>" size="2" maxlength="2" /></td>
                    <td><input type="submit" name="tfi_listmural1" value="<?php echo NXT_getResource("Filter"); ?>" /></td>
                  </tr>
                  <?php } 
  // endif Conditional region3
?>
              </thead>
              <tbody>
                <?php if ($totalRows_rsmural1 == 0) { // Show if recordset empty ?>
                  <tr>
                    <td colspan="6"><?php echo NXT_getResource("The table is empty or the filter you've selected is too restrictive."); ?></td>
                  </tr>
                  <?php } // Show if recordset empty ?>
                <?php if ($totalRows_rsmural1 > 0) { // Show if recordset not empty ?>
                  <?php do { ?>
                    <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                      <td><input type="checkbox" name="kt_pk_mural" class="id_checkbox" value="<?php echo $row_rsmural1['id_mural']; ?>" />
                        <input type="hidden" name="id_mural" class="id_field" value="<?php echo $row_rsmural1['id_mural']; ?>" /></td>
                      <td><div class="KT_col_id_cond"><?php echo KT_FormatForList($row_rsmural1['id_cond'], 30); ?></div></td>
                      <td><div class="KT_col_texto_mural"><?php echo KT_FormatForList($row_rsmural1['texto_mural'], 35); ?></div></td>
                      <td><div class="KT_col_data_publi"><?php echo KT_formatDate($row_rsmural1['data_publi']); ?></div></td>
                      <td  bgcolor="<?php if ($row_rsmural1['ativo'] == 1) { echo '#009900';} else {echo '#ff0000';}?>"><?php if ($row_rsmural1['ativo'] == 1) { echo 'sim';} else {echo 'n�o';}?></td>
                      <td><a class="KT_edit_link" href="atualizar_quadro_aviso_condominios.php?id_mural=<?php echo $row_rsmural1['id_mural']; ?>&amp;KT_back=1"><?php if ($row_nomes['nivel'] >= 2) { ?><?php echo NXT_getResource("edit_one"); ?><?php }?></a> <a class="KT_delete_link" href="#delete"><?php if ($row_nomes['nivel'] >= 3) { ?><?php echo NXT_getResource("delete_one"); ?><?php }?></a></td>
                    </tr>
                    <?php } while ($row_rsmural1 = mysql_fetch_assoc($rsmural1)); ?>
                  <?php } // Show if recordset not empty ?>
              </tbody>
            </table>
            <div class="KT_bottomnav">
              <div>
                <?php
            $nav_listmural1->Prepare();
            require("../includes/nav/NAV_Text_Navigation.inc.php");
          ?>
              </div>
            </div>
            <div class="KT_bottombuttons">
              <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 2) { ?><?php echo NXT_getResource("edit_all"); ?><?php }?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 3) { ?><?php echo NXT_getResource("delete_all"); ?><?php }?></a></div>
              <span>&nbsp;</span></div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($Recordset1);

mysql_free_result($rsmural1);
?>
