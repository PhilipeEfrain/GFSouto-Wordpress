<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('../includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("texto_mural", true, "text", "", "", "", "");
$formValidation->addField("data_publi", true, "date", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.id_cond, condominios.nome_cond FROM condominios ORDER BY condominios.nome_cond";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

// Make an insert transaction instance
$ins_mural = new tNG_insert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_mural);
// Register triggers
$ins_mural->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_mural->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_mural->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_quadro_aviso_condominios.php");
// Add columns
$ins_mural->setTable("mural");
$ins_mural->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond", "{Recordset1.id_cond}");
$ins_mural->addColumn("texto_mural", "STRING_TYPE", "POST", "texto_mural");
$ins_mural->addColumn("data_publi", "DATE_TYPE", "POST", "data_publi");
$ins_mural->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$ins_mural->setPrimaryKey("id_mural", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rsmural = $tNGs->getRecordset("mural");
$row_rsmural = mysql_fetch_assoc($rsmural);
$totalRows_rsmural = mysql_num_rows($rsmural);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<!--IN�CIO DO TEXT �REA DIM�MICO-->
<script type="text/javascript" src="jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
	tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "simple",
		//theme : "advanced",
		plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template",

		// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,sub,sup,|,bullist,numlist,|,outdent,indent,blockquote,|,cut,copy,paste,pastetext,|,undo,redo,|,link,unlink,anchor",
		/*theme_advanced_buttons2 : "tablecontrols",*/
		
		/*//* Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak",
		*/
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

		// ---------------------------------------
		content_css : "exemples/css/content.css",

		// --------------------------
		//template_external_list_url : "exemples/lists/template_list.js",
		//external_link_list_url : "exemples/lists/link_list.js",
		//external_image_list_url : "exemples/lists/image_list.js",
		//media_external_list_url : "exemples/lists/media_list.js",

		// --------------------------
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
</script>
<!--FIM DO TEXT �REA DIM�MICO-->
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script type="text/javascript" src="../includes/common/js/sigslot_core.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="../includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="../includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="../includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="../includes/resources/calendar.js"></script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Cadastrar quadro aviso</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th"><label for="id_cond">Condom�nio:</label></td>
            <td><select name="id_cond" id="id_cond">
              <?php 
do {  
?>
              <option value="<?php echo $row_condominio['id_cond']?>"<?php if (!(strcmp($row_condominio['id_cond'], $row_rsmural['id_cond']))) {echo "SELECTED";} ?>><?php echo $row_condominio['nome_cond']?></option>
              <?php
} while ($row_condominio = mysql_fetch_assoc($condominio));
  $rows = mysql_num_rows($condominio);
  if($rows > 0) {
      mysql_data_seek($condominio, 0);
	  $row_condominio = mysql_fetch_assoc($condominio);
  }
?>
            </select>
              <?php echo $tNGs->displayFieldError("mural", "id_cond"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="texto_mural">Texto aviso:</label></td>
            <td><textarea name="texto_mural" id="texto_mural" cols="70" rows="15"><?php echo KT_escapeAttribute($row_rsmural['texto_mural']); ?></textarea>
            <?php echo $tNGs->displayFieldHint("texto_mural");?> <?php echo $tNGs->displayFieldError("mural", "texto_mural"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="data_publi">Data:</label></td>
            <td><input name="data_publi" id="data_publi" value="<?php echo KT_formatDate($row_rsmural['data_publi']); ?>" size="32" wdg:mondayfirst="false" wdg:subtype="Calendar" wdg:mask="<?php echo $KT_screen_date_format; ?>" wdg:type="widget" wdg:singleclick="false" wdg:restricttomask="no" wdg:readonly="true" />
            <?php echo $tNGs->displayFieldHint("data_publi");?> <?php echo $tNGs->displayFieldError("mural", "data_publi"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="ativo">Ativo:</label></td>
            <td><select name="ativo" id="ativo">
              <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rsmural['ativo'])))) {echo "SELECTED";} ?>>sim</option>
              <option value="0" <?php if (!(strcmp(0, KT_escapeAttribute($row_rsmural['ativo'])))) {echo "SELECTED";} ?>>n�o</option>
            </select>
              <?php echo $tNGs->displayFieldError("mural", "ativo"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar" /></td>
          </tr>
        </table>
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($condominio);
?>
