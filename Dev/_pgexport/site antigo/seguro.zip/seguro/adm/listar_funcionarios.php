<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the required classes
require_once('../includes/tfi/TFI.php');
require_once('../includes/tso/TSO.php');
require_once('../includes/nav/NAV.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("nome_func", true, "text", "", "", "", "");
$formValidation->addField("funcao_func", true, "text", "", "", "", "");
$formValidation->addField("expediente", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// Filter
$tfi_listfuncionarios1 = new TFI_TableFilter($conn_gf_souto_conect, "tfi_listfuncionarios1");
$tfi_listfuncionarios1->addColumn("funcionarios.foto_func", "STRING_TYPE", "foto_func", "%");
$tfi_listfuncionarios1->addColumn("funcionarios.nome_func", "STRING_TYPE", "nome_func", "%");
$tfi_listfuncionarios1->addColumn("funcionarios.funcao_func", "STRING_TYPE", "funcao_func", "%");
$tfi_listfuncionarios1->addColumn("funcionarios.expediente", "STRING_TYPE", "expediente", "%");
$tfi_listfuncionarios1->addColumn("funcionarios.ativo", "STRING_TYPE", "ativo", "%");
$tfi_listfuncionarios1->Execute();

// Sorter
$tso_listfuncionarios1 = new TSO_TableSorter("rsfuncionarios1", "tso_listfuncionarios1");
$tso_listfuncionarios1->addColumn("funcionarios.foto_func");
$tso_listfuncionarios1->addColumn("funcionarios.nome_func");
$tso_listfuncionarios1->addColumn("funcionarios.funcao_func");
$tso_listfuncionarios1->addColumn("funcionarios.expediente");
$tso_listfuncionarios1->addColumn("funcionarios.ativo");
$tso_listfuncionarios1->setDefault("funcionarios.foto_func");
$tso_listfuncionarios1->Execute();

// Navigation
$nav_listfuncionarios1 = new NAV_Regular("nav_listfuncionarios1", "rsfuncionarios1", "../", $_SERVER['PHP_SELF'], 20);

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_funcionarios = new tNG_insert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_funcionarios);
// Register triggers
$ins_funcionarios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_funcionarios->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_funcionarios->registerTrigger("END", "Trigger_Default_Redirect", 99, "listar_funcionarios.php?id_cond=".$_GET['id_cond']);
// Add columns
$ins_funcionarios->setTable("funcionarios");
$ins_funcionarios->addColumn("id_cond", "STRING_TYPE", "POST", "id_cond", "{GET.id_cond}");
$ins_funcionarios->addColumn("nome_func", "STRING_TYPE", "POST", "nome_func");
$ins_funcionarios->addColumn("funcao_func", "STRING_TYPE", "POST", "funcao_func");
$ins_funcionarios->addColumn("expediente", "STRING_TYPE", "POST", "expediente");
$ins_funcionarios->addColumn("ativo", "STRING_TYPE", "POST", "ativo");
$ins_funcionarios->setPrimaryKey("id_func", "NUMERIC_TYPE");

// Execute all the registered transactions
$tNGs->executeTransactions();

//NeXTenesio3 Special List Recordset
$maxRows_rsfuncionarios1 = $_SESSION['max_rows_nav_listfuncionarios1'];
$pageNum_rsfuncionarios1 = 0;
if (isset($_GET['pageNum_rsfuncionarios1'])) {
  $pageNum_rsfuncionarios1 = $_GET['pageNum_rsfuncionarios1'];
}
$startRow_rsfuncionarios1 = $pageNum_rsfuncionarios1 * $maxRows_rsfuncionarios1;

// Defining List Recordset variable
$NXTFilter_rsfuncionarios1 = "1=1";
if (isset($_SESSION['filter_tfi_listfuncionarios1'])) {
  $NXTFilter_rsfuncionarios1 = $_SESSION['filter_tfi_listfuncionarios1'];
}
// Defining List Recordset variable
$NXTSort_rsfuncionarios1 = "funcionarios.foto_func";
if (isset($_SESSION['sorter_tso_listfuncionarios1'])) {
  $NXTSort_rsfuncionarios1 = $_SESSION['sorter_tso_listfuncionarios1'];
}
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);

$query_rsfuncionarios1 = "SELECT funcionarios.foto_func, funcionarios.nome_func, funcionarios.funcao_func, funcionarios.expediente, funcionarios.ativo, funcionarios.id_func FROM funcionarios WHERE {$NXTFilter_rsfuncionarios1} AND funcionarios.id_cond = ".$_GET['id_cond']." ORDER BY {$NXTSort_rsfuncionarios1}";
$query_limit_rsfuncionarios1 = sprintf("%s LIMIT %d, %d", $query_rsfuncionarios1, $startRow_rsfuncionarios1, $maxRows_rsfuncionarios1);
$rsfuncionarios1 = mysql_query($query_limit_rsfuncionarios1, $gf_souto_conect) or die(mysql_error());
$row_rsfuncionarios1 = mysql_fetch_assoc($rsfuncionarios1);

if (isset($_GET['totalRows_rsfuncionarios1'])) {
  $totalRows_rsfuncionarios1 = $_GET['totalRows_rsfuncionarios1'];
} else {
  $all_rsfuncionarios1 = mysql_query($query_rsfuncionarios1);
  $totalRows_rsfuncionarios1 = mysql_num_rows($all_rsfuncionarios1);
}
$totalPages_rsfuncionarios1 = ceil($totalRows_rsfuncionarios1/$maxRows_rsfuncionarios1)-1;
//End NeXTenesio3 Special List Recordset

$nav_listfuncionarios1->checkBoundries();

// Get the transaction recordset
$rsfuncionarios = $tNGs->getRecordset("funcionarios");
$row_rsfuncionarios = mysql_fetch_assoc($rsfuncionarios);
$totalRows_rsfuncionarios = mysql_num_rows($rsfuncionarios);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/list.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_LIST_SETTINGS = {
  duplicate_buttons: false,
  duplicate_navigation: false,
  row_effects: true,
  show_as_buttons: true,
  record_counter: false
}
</script>
<style type="text/css">
  /* Dynamic List row settings */
  .KT_col_foto_func {width:140px; overflow:hidden;}
  .KT_col_nome_func {width:175px; overflow:hidden;}
  .KT_col_funcao_func {width:140px; overflow:hidden;}
  .KT_col_expediente {width:140px; overflow:hidden;}
  .KT_col_ativo {width:14px; overflow:hidden;}
</style>
<?php echo $tNGs->displayValidationRules();?>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Funcionarios 
    <?php 
	
	
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$_GET['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

echo '<b>'.$row_condominio['nome_cond'].'</b>';

 ?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <form method="post" id="form2" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
        <table cellpadding="2" cellspacing="0" class="KT_tngtable">
          <tr>
            <td class="KT_th"><label for="nome_func">Nome:</label></td>
            <td><input type="text" name="nome_func" id="nome_func" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['nome_func']); ?>" size="32" />
              <?php echo $tNGs->displayFieldHint("nome_func");?> <?php echo $tNGs->displayFieldError("funcionarios", "nome_func"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="funcao_func">Fun��o:</label></td>
            <td><input type="text" name="funcao_func" id="funcao_func" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['funcao_func']); ?>" size="32" />
              <?php echo $tNGs->displayFieldHint("funcao_func");?> <?php echo $tNGs->displayFieldError("funcionarios", "funcao_func"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="expediente">Expediente:</label></td>
            <td><input type="text" name="expediente" id="expediente" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['expediente']); ?>" size="32" />
              <?php echo $tNGs->displayFieldHint("expediente");?> <?php echo $tNGs->displayFieldError("funcionarios", "expediente"); ?></td>
          </tr>
          <tr>
            <td class="KT_th"><label for="ativo">Ativo:</label></td>
            <td><select name="ativo" id="ativo">
              <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rsfuncionarios['ativo'])))) {echo "SELECTED";} ?>>sim</option>
              <option value="0" <?php if (!(strcmp(0, KT_escapeAttribute($row_rsfuncionarios['ativo'])))) {echo "SELECTED";} ?>>n�o</option>
            </select>
              <?php echo $tNGs->displayFieldError("funcionarios", "ativo"); ?></td>
          </tr>
          <tr class="KT_buttons">
            <td colspan="2"><input type="submit" name="KT_Insert1" id="KT_Insert1" value="Cadastrar" /></td>
          </tr>
        </table>
        <input type="hidden" name="id_cond" id="id_cond" value="<?php echo KT_escapeAttribute($row_rsfuncionarios['id_cond']); ?>" />
      </form>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <div class="KT_tng" id="listfuncionarios1">
        <?php /*?><h1> Funcionarios
          <?php
  $nav_listfuncionarios1->Prepare();
  require("../includes/nav/NAV_Text_Statistics.inc.php");
?>
        </h1><?php */?>
        <div class="KT_tnglist">
          <form action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>" method="post" id="form1">
            <div class="KT_options"> <a href="<?php echo $nav_listfuncionarios1->getShowAllLink(); ?>"><?php echo NXT_getResource("Show"); ?>
              <?php 
  // Show IF Conditional region1
  if (@$_GET['show_all_nav_listfuncionarios1'] == 1) {
?>
                <?php echo $_SESSION['default_max_rows_nav_listfuncionarios1']; ?>
                <?php 
  // else Conditional region1
  } else { ?>
                <?php echo NXT_getResource("all"); ?>
                <?php } 
  // endif Conditional region1
?>
<?php echo NXT_getResource("records"); ?></a> &nbsp;
              &nbsp; </div>
            <table cellpadding="2" cellspacing="0" class="KT_tngtable">
              <thead>
                <tr class="KT_row_order">
                  <th> <input type="checkbox" name="KT_selAll" id="KT_selAll"/>
                  </th>
                  <th id="foto_func" class="KT_sorter KT_col_foto_func <?php echo $tso_listfuncionarios1->getSortIcon('funcionarios.foto_func'); ?>"> <a href="<?php echo $tso_listfuncionarios1->getSortLink('funcionarios.foto_func'); ?>">Foto</a></th>
                  <th id="nome_func" class="KT_sorter KT_col_nome_func <?php echo $tso_listfuncionarios1->getSortIcon('funcionarios.nome_func'); ?>"> <a href="<?php echo $tso_listfuncionarios1->getSortLink('funcionarios.nome_func'); ?>">Nome</a></th>
                  <th id="funcao_func" class="KT_sorter KT_col_funcao_func <?php echo $tso_listfuncionarios1->getSortIcon('funcionarios.funcao_func'); ?>"> <a href="<?php echo $tso_listfuncionarios1->getSortLink('funcionarios.funcao_func'); ?>">Fun��o</a></th>
                  <th id="expediente" class="KT_sorter KT_col_expediente <?php echo $tso_listfuncionarios1->getSortIcon('funcionarios.expediente'); ?>"> <a href="<?php echo $tso_listfuncionarios1->getSortLink('funcionarios.expediente'); ?>">Expediente</a></th>
                  <th id="ativo" class="KT_sorter KT_col_ativo <?php echo $tso_listfuncionarios1->getSortIcon('funcionarios.ativo'); ?>"> <a href="<?php echo $tso_listfuncionarios1->getSortLink('funcionarios.ativo'); ?>">Ativo</a></th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($totalRows_rsfuncionarios1 == 0) { // Show if recordset empty ?>
                  <tr>
                    <td colspan="7"><?php echo NXT_getResource("Nenhum resultado encontrado."); ?></td>
                  </tr>
                  <?php } // Show if recordset empty ?>
                <?php if ($totalRows_rsfuncionarios1 > 0) { // Show if recordset not empty ?>
                  <?php do { ?>
                    <tr class="<?php echo @$cnt1++%2==0 ? "" : "KT_even"; ?>">
                      <td><input type="checkbox" name="kt_pk_funcionarios" class="id_checkbox" value="<?php echo $row_rsfuncionarios1['id_func']; ?>" />
                        <input type="hidden" name="id_func" class="id_field" value="<?php echo $row_rsfuncionarios1['id_func']; ?>" /></td>
                      <td><div class="KT_col_foto_func"><?php echo KT_FormatForList($row_rsfuncionarios1['foto_func'], 20); ?></div></td>
                      <td><div class="KT_col_nome_func"><?php echo KT_FormatForList($row_rsfuncionarios1['nome_func'], 25); ?></div></td>
                      <td><div class="KT_col_funcao_func"><?php echo KT_FormatForList($row_rsfuncionarios1['funcao_func'], 20); ?></div></td>
                      <td><div class="KT_col_expediente"><?php echo KT_FormatForList($row_rsfuncionarios1['expediente'], 20); ?></div></td>
                      <td bgcolor="<?php if ($row_rsfuncionarios1['ativo'] == 1) { echo '#009900';} else {echo '#ff0000';}?>"><div class="KT_col_ativo"><?php if ($row_rsfuncionarios1['ativo'] == 1) { echo 'sim';} else {echo 'n�o';}?></div></td>
                      <td><a class="KT_edit_link" href="atualizar_funcionarios.php?id_func=<?php echo $row_rsfuncionarios1['id_func']; ?>&amp;KT_back=1"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("edit_one"); ?><?php }?></a> <a class="KT_delete_link" href="#delete"><?php if ($row_nomes['nivel'] >= 3 ) { ?><?php echo NXT_getResource("delete_one"); ?><?php }?></a></td>
                    </tr>
                    <?php } while ($row_rsfuncionarios1 = mysql_fetch_assoc($rsfuncionarios1)); ?>
                  <?php } // Show if recordset not empty ?>
              </tbody>
            </table>
            <div class="KT_bottomnav">
              <div>
                <?php
            $nav_listfuncionarios1->Prepare();
            require("../includes/nav/NAV_Text_Navigation.inc.php");
          ?>
              </div>
            </div>
            <div class="KT_bottombuttons">
              <div class="KT_operations"> <a class="KT_edit_op_link" href="#" onclick="nxt_list_edit_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 2 ) { ?><?php echo NXT_getResource("edit_all"); ?><?php }?></a> <a class="KT_delete_op_link" href="#" onclick="nxt_list_delete_link_form(this); return false;"><?php if ($row_nomes['nivel'] >= 3 ) { ?><?php echo NXT_getResource("delete_all"); ?><?php }?></a></div>
              <span>&nbsp;</span></div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($rsfuncionarios1);
?>
