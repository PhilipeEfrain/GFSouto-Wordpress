<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('../includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("nome", true, "text", "", "", "", "");
$formValidation->addField("login", true, "text", "", "", "", "");
$formValidation->addField("senha", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins__admin_ = new tNG_multipleInsert($conn_gf_souto_conect);
$tNGs->addTransaction($ins__admin_);
// Register triggers
$ins__admin_->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins__admin_->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins__admin_->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$ins__admin_->setTable("`admin`");
$ins__admin_->addColumn("nome", "STRING_TYPE", "POST", "nome");
$ins__admin_->addColumn("login", "STRING_TYPE", "POST", "login");
$ins__admin_->addColumn("senha", "STRING_TYPE", "POST", "senha");
$ins__admin_->addColumn("nivel", "STRING_TYPE", "POST", "nivel", "{nomes.nivel}");
$ins__admin_->setPrimaryKey("id_adm", "NUMERIC_TYPE");

// Make an update transaction instance
$upd__admin_ = new tNG_multipleUpdate($conn_gf_souto_conect);
$tNGs->addTransaction($upd__admin_);
// Register triggers
$upd__admin_->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd__admin_->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd__admin_->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$upd__admin_->setTable("`admin`");
$upd__admin_->addColumn("nome", "STRING_TYPE", "POST", "nome");
$upd__admin_->addColumn("login", "STRING_TYPE", "POST", "login");
$upd__admin_->addColumn("senha", "STRING_TYPE", "POST", "senha");
$upd__admin_->addColumn("nivel", "STRING_TYPE", "POST", "nivel");
$upd__admin_->setPrimaryKey("id_adm", "NUMERIC_TYPE", "GET", "id_adm");

// Make an instance of the transaction object
$del__admin_ = new tNG_multipleDelete($conn_gf_souto_conect);
$tNGs->addTransaction($del__admin_);
// Register triggers
$del__admin_->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del__admin_->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$del__admin_->setTable("`admin`");
$del__admin_->setPrimaryKey("id_adm", "NUMERIC_TYPE", "GET", "id_adm");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rs_admin_ = $tNGs->getRecordset("`admin`");
$row_rs_admin_ = mysql_fetch_assoc($rs_admin_);
$totalRows_rs_admin_ = mysql_num_rows($rs_admin_);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="../includes/nxt/scripts/form.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/form.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: false,
  show_as_grid: true,
  merge_down_value: true
}
</script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Atualizar Usu&aacute;rios do Sistema</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01"><table width="700" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><span class="t02">nivel 1 - l&ecirc; dados.<br />
nivel 2 - l&ecirc; dados, cadastra, atualiza.<br />
nivel 3 - l&ecirc; dados, cadastra, atualiza, deleta.<br />
nivel 4 - (administrador do sistema) l&ecirc; dados, cadastra, atualiza, deleta e atualiza dados administrativos.</span></td>
  </tr>
</table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <div class="KT_tng">
       <?php /*?> <h1>
          <?php 
// Show IF Conditional region1 
if (@$_GET['id_adm'] == "") {
?>
            <?php echo NXT_getResource("Insert_FH"); ?>
            <?php 
// else Conditional region1
} else { ?>
            <?php echo NXT_getResource("Update_FH"); ?>
            <?php } 
// endif Conditional region1
?>
          `admin` <</h1>?php */?>
        <div class="KT_tngform">
          <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
            <?php $cnt1 = 0; ?>
            <?php do { ?>
              <?php $cnt1++; ?>
              <?php 
// Show IF Conditional region1 
if (@$totalRows_rs_admin_ > 1) {
?>
                <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                <?php } 
// endif Conditional region1
?>
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="nome_<?php echo $cnt1; ?>">Nome:</label></td>
                  <td><?php if ($row_nomes['login'] == "denilson" ) {?><input type="text" name="nome_<?php echo $cnt1; ?>" id="nome_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rs_admin_['nome']); ?>" size="32" maxlength="50" /><?php } else {}?>
                    <?php echo $tNGs->displayFieldHint("nome");?> <?php echo $tNGs->displayFieldError("`admin`", "nome", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="login_<?php echo $cnt1; ?>">Login:</label></td>
                  <td><?php if ($row_nomes['login'] == "denilson" ) {?><input type="text" name="login_<?php echo $cnt1; ?>" id="login_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rs_admin_['login']); ?>" size="20" maxlength="20" /><?php } else {}?>
                    <?php echo $tNGs->displayFieldHint("login");?> <?php echo $tNGs->displayFieldError("`admin`", "login", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="senha_<?php echo $cnt1; ?>">Senha:</label></td>
                  <td><?php if ($row_nomes['login'] == "denilson" ) {?><input type="text" name="senha_<?php echo $cnt1; ?>" id="senha_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rs_admin_['senha']); ?>" size="20" maxlength="20" /><?php } else {}?>
                    <?php echo $tNGs->displayFieldHint("senha");?> <?php echo $tNGs->displayFieldError("`admin`", "senha", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="nivel_<?php echo $cnt1; ?>">Nivel:</label></td>
                  <td><?php if ($row_nomes['login'] == "denilson" ) {?><select name="nivel_<?php echo $cnt1; ?>" id="nivel_<?php echo $cnt1; ?>">
                    <option value="1" <?php if (!(strcmp(1, KT_escapeAttribute($row_rs_admin_['nivel'])))) {echo "selected=\"selected\"";} ?>>N�vel 1 - L� Dados</option>
                    <option value="2" <?php if (!(strcmp(2, KT_escapeAttribute($row_rs_admin_['nivel'])))) {echo "selected=\"selected\"";} ?>>N�vel 2 - Cadastra e Atualiza</option>
                    <option value="3" <?php if (!(strcmp(3, KT_escapeAttribute($row_rs_admin_['nivel'])))) {echo "selected=\"selected\"";} ?>>N�vel 3 - Cadastra, Atualiza e Deleta</option>
                    <option value="4" <?php if (!(strcmp(4, KT_escapeAttribute($row_rs_admin_['nivel'])))) {echo "selected=\"selected\"";} ?>>N�vel 4 - Super Administrador</option>
                  </select><?php } else {}?>
                    <?php echo $tNGs->displayFieldError("`admin`", "nivel", $cnt1); ?></td>
                </tr>
              </table>
              <input type="hidden" name="kt_pk__admin__<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rs_admin_['kt_pk__admin_']); ?>" />
              <?php } while ($row_rs_admin_ = mysql_fetch_assoc($rs_admin_)); ?>
            <div class="KT_bottombuttons">
              <div>
                <?php 
      // Show IF Conditional region1
      if (@$_GET['id_adm'] == "") {
      ?>
                  <?php 
      // else Conditional region1
      } else { ?>
                  <?php if ($row_nomes['login'] == "denilson" ) {?><input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" /><?php } else {}?>
                  <?php }
      // endif Conditional region1
      ?>
                <input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, '../includes/nxt/back.php')" />
              </div>
            </div>
          </form>
        </div>
        <br class="clearfixplain" />
      </div>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);
?>