<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

//-------------------------------------------------------------------------

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_empresa = "SELECT * FROM nome_empresa";
$empresa = mysql_query($query_empresa, $gf_souto_conect) or die(mysql_error());
$row_empresa = mysql_fetch_assoc($empresa);
$totalRows_empresa = mysql_num_rows($empresa);

//------------------------------------------------------
$maxRows_logs = 30;
$pageNum_logs = 0;
if (isset($_GET['pageNum_logs'])) {
  $pageNum_logs = $_GET['pageNum_logs'];
}
$startRow_logs = $pageNum_logs * $maxRows_logs;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_logs = "SELECT * FROM logs_acesso ORDER BY logs_acesso.data_hora DESC";
$query_limit_logs = sprintf("%s LIMIT %d, %d", $query_logs, $startRow_logs, $maxRows_logs);
$logs = mysql_query($query_limit_logs, $gf_souto_conect) or die(mysql_error());
$row_logs = mysql_fetch_assoc($logs);

if (isset($_GET['totalRows_logs'])) {
  $totalRows_logs = $_GET['totalRows_logs'];
} else {
  $all_logs = mysql_query($query_logs);
  $totalRows_logs = mysql_num_rows($all_logs);
}
$totalPages_logs = ceil($totalRows_logs/$maxRows_logs)-1;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_ocorrencia = "SELECT * FROM livro_ocorrencia WHERE livro_ocorrencia.respondido = 0 ORDER BY livro_ocorrencia.data_ocorr";
$ocorrencia = mysql_query($query_ocorrencia, $gf_souto_conect) or die(mysql_error());
$row_ocorrencia = mysql_fetch_assoc($ocorrencia);
$totalRows_ocorrencia = mysql_num_rows($ocorrencia);

$maxRows_agenda_area = 30;
$pageNum_agenda_area = 0;
if (isset($_GET['pageNum_agenda_area'])) {
  $pageNum_agenda_area = $_GET['pageNum_agenda_area'];
}
$startRow_agenda_area = $pageNum_agenda_area * $maxRows_agenda_area;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_agenda_area = "SELECT * FROM areas_agenda ORDER BY areas_agenda.eventDate DESC";
$query_limit_agenda_area = sprintf("%s LIMIT %d, %d", $query_agenda_area, $startRow_agenda_area, $maxRows_agenda_area);
$agenda_area = mysql_query($query_limit_agenda_area, $gf_souto_conect) or die(mysql_error());
$row_agenda_area = mysql_fetch_assoc($agenda_area);

if (isset($_GET['totalRows_agenda_area'])) {
  $totalRows_agenda_area = $_GET['totalRows_agenda_area'];
} else {
  $all_agenda_area = mysql_query($query_agenda_area);
  $totalRows_agenda_area = mysql_num_rows($all_agenda_area);
}
$totalPages_agenda_area = ceil($totalRows_agenda_area/$maxRows_agenda_area)-1;

$maxRows_mudanca_entrada = 30;
$pageNum_mudanca_entrada = 0;
if (isset($_GET['pageNum_mudanca_entrada'])) {
  $pageNum_mudanca_entrada = $_GET['pageNum_mudanca_entrada'];
}
$startRow_mudanca_entrada = $pageNum_mudanca_entrada * $maxRows_mudanca_entrada;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_mudanca_entrada = "SELECT * FROM mudanca	WHERE entrada_saida = 0 ORDER BY mudanca.eventDate DESC";
$query_limit_mudanca_entrada = sprintf("%s LIMIT %d, %d", $query_mudanca_entrada, $startRow_mudanca_entrada, $maxRows_mudanca_entrada);
$mudanca_entrada = mysql_query($query_limit_mudanca_entrada, $gf_souto_conect) or die(mysql_error());
$row_mudanca_entrada = mysql_fetch_assoc($mudanca_entrada);

if (isset($_GET['totalRows_mudanca_entrada'])) {
  $totalRows_mudanca_entrada = $_GET['totalRows_mudanca_entrada'];
} else {
  $all_mudanca_entrada = mysql_query($query_mudanca_entrada);
  $totalRows_mudanca_entrada = mysql_num_rows($all_mudanca_entrada);
}
$totalPages_mudanca_entrada = ceil($totalRows_mudanca_entrada/$maxRows_mudanca_entrada)-1;



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$maxRows_mudanca_saida = 30;
$pageNum_mudanca_saida = 0;
if (isset($_GET['pageNum_mudanca_saida'])) {
  $pageNum_mudanca_saida = $_GET['pageNum_mudanca_saida'];
}
$startRow_mudanca_saida = $pageNum_mudanca_saida * $maxRows_mudanca_saida;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_mudanca_saida = "SELECT * FROM mudanca 	WHERE entrada_saida = 1  ORDER BY mudanca.eventDate DESC";
$query_limit_mudanca_saida = sprintf("%s LIMIT %d, %d", $query_mudanca_saida, $startRow_mudanca_saida, $maxRows_mudanca_saida);
$mudanca_saida = mysql_query($query_limit_mudanca_saida, $gf_souto_conect) or die(mysql_error());
$row_mudanca_saida = mysql_fetch_assoc($mudanca_saida);

if (isset($_GET['totalRows_mudanca_saida'])) {
  $totalRows_mudanca_saida = $_GET['totalRows_mudanca_saida'];
} else {
  $all_mudanca_saida = mysql_query($query_mudanca_saida);
  $totalRows_mudanca_saida = mysql_num_rows($all_mudanca_saida);
}
$totalPages_mudanca_saida = ceil($totalRows_mudanca_saida/$maxRows_mudanca_saida)-1;


// Initialize the Alternate Color counter
$ac_sw1 = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><a href="http://www.dsdigital.com.br" title="By DS Digital" target="_blank"><img src="logo-para-painel-adm.gif" alt="By DS Digital" width="300" height="68" border="0" /></a></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t03">&nbsp;</td>
  </tr>
  <tr>
  <td height="200" align="center" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="578" align="center" valign="top"><span class="t03">Livro ocorr&ecirc;ncias</span></td>
      <td width="412" align="center" valign="top"><span class="t03">&Uacute;ltimos acessos ao sistema</span></td>
      </tr>
    <tr>
      <td align="center" valign="top"><?php if ($row_ocorrencia['id_cond'] == "") {} else {?>
	  <?php 
	




do { 

	
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$row_ocorrencia['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

?>
        <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td colspan="2" align="left" bgcolor="#EDEDED"><span class="t02">Cond.: <b><?php echo $row_condominio['nome_cond']; ?></b> / Uni: <b><?php echo $row_ocorrencia['id_unidade']; ?></b> - Data: <?php 
			
			$data_noticia_da_hora =  $row_ocorrencia['data_ocorr']; //hora vinda do servidor

			

	$data=explode("-",$data_noticia_da_hora);
    	$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	 //echo($dataFinal);
	//  11 19:28:38/05/2010
	$dia = substr($dataFinal,0,2);    // retorna "bcdef"
    	$mes = substr($dataFinal, 12, 2); // retorna "bcd"
    	$ano = substr($dataFinal, 15, 4); // retorna "abcd"
	$hora = substr($dataFinal, 3, 8); // retorna "abcd"
	//$autor = $row_noticia_da_hora['autor_noticia'];
	$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora;
	//$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora . " por ". $autor;
	//$dataok = $dia ."/". $mes . "/". $ano;
	echo $dataok;
		
		?> - <a href="cadastrar_respostas_ocorrencias.php?cod_ocorr=<?php echo $row_ocorrencia['id_ocorr']; ?>">Responder</a></span></td>
            </tr>
          <tr>
            <td width="10%" align="left" bgcolor="#EDEDED"><b><span class="t02">Nome:</span></b></td>
            <td width="90%" align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_ocorrencia['nome']; ?></span></td>
            </tr>
          <tr>
            <td align="left" bgcolor="#EDEDED"><b><span class="t02">E-mail:</span></b></td>
            <td align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<a href="mailto:<?php echo $row_ocorrencia['email']; ?>"><?php echo $row_ocorrencia['email']; ?></a></span></td>
            </tr>
          <tr>
            <td align="left" bgcolor="#EDEDED" class="t02"><b><span class="t02">Fone:</span></b></td>
            <td align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_ocorrencia['fone']; ?></span></td>
            </tr>
          <tr>
            <td align="left" valign="top" bgcolor="#EDEDED" class="t02">Ocorr&ecirc;ncia:</td>
            <td align="left" valign="top" bgcolor="#FFFFCC" class="t02">&nbsp;<?php echo $row_ocorrencia['text_ocorr']; ?></td>
            </tr>
          <tr>
            <td colspan="2" align="right" bgcolor="#EDEDED" class="t02"></td>
            </tr>
          <tr>
            <td align="left" bgcolor="#EDEDED">&nbsp;</td>
            <td align="left" bgcolor="#EDEDED">&nbsp;</td>
            </tr>
          <tr>
            <td align="left">&nbsp;</td>
            <td align="left">&nbsp;</td>
          </tr>
          </table>
        <?php } while ($row_ocorrencia = mysql_fetch_assoc($ocorrencia)); ?>
        
        <?php }?></td>
      <td width="412" rowspan="12" align="center" valign="top" bgcolor="#EDEDED"><?php if ($row_nomes['nivel'] >= 2 ) { ?>
        <table width="400" border="0" cellspacing="0" cellpadding="0">
          <tr class="t02">
            <td height="30" align="left"><strong>Nome</strong></td>
            <td align="left">&nbsp;</td>
            <td align="left"><strong>data/hora</strong></td>
            </tr>
          <?php do { ?>
            <tr bgcolor="<?php echo ($ac_sw1++%2==0)?"#ededed":"#FFFFFF"; ?>" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#FFFFCC'" class="t02">
              <td align="left"><?php echo $row_logs['nome_admin']; ?>&nbsp;</td>
              <td align="left">&nbsp;&nbsp;--&gt;</td>
  <td align="left"><?php 
	
	$data_noticia_da_hora = $row_logs['data_hora'];
	$data=explode("-",$data_noticia_da_hora);
    $dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
    //echo($dataFinal);
	//  11 19:28:38/05/2010
	$dia = substr($dataFinal,0,2);    // retorna "bcdef"
    $mes = substr($dataFinal, 12, 2); // retorna "bcd"
    $ano = substr($dataFinal, 15, 4); // retorna "abcd"
	$hora = substr($dataFinal, 3, 8); // retorna "abcd"
	//$autor = $row_noticia_da_hora['autor_noticia'];
	$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora;
	//$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora . " por ". $autor;
	//$dataok = $dia ."/". $mes . "/". $ano;
	echo $dataok;
	
	?></td>
              </tr>
            <?php } while ($row_logs = mysql_fetch_assoc($logs)); ?>
          </table>
        <?php }?></td>
      </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
      </tr>
    <tr>
      <td align="center" valign="top"><span class="t03">Agendamento &aacute;reas</span></td>
    </tr>
    <tr>
      <td align="center" valign="top">
    <?php do {  ?>
		<?php $today = date('Y-m-d') ; if ($row_agenda_area['eventDate'] >= $today) {?>
			<?php 
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$row_agenda_area['id_cond'];
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

?>
          <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td colspan="2" align="left" bgcolor="#EDEDED"><span class="t02">Cond.: <b><?php echo $row_condominio['nome_cond']; ?></b> / Uni: <b><?php echo $row_agenda_area['id_unidade']; ?></b> - Data: <?php 
			   
		$data_noticia_da_hora =  $row_agenda_area['eventDate']; //hora vinda do servidor

	    $data=explode("-",$data_noticia_da_hora);
    	$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	//echo($dataFinal);
	//  11 19:28:38/05/2010
	    $dia = substr($dataFinal,0,2);    // retorna "bcdef"
        $mes = substr($dataFinal, 3, 2); // retorna "bcd"
        $ano = substr($dataFinal, 6, 4); // retorna "abcd"
	    $dataok = $dia ."/". $mes . "/". $ano;
	    echo $dataok;
	
	?> - <a href="listar_agendamento_areas.php?id_cond=<?php echo $row_agenda_area['id_cond']; ?>">ver</a></span></td>
            </tr>
            <tr>
              <td width="10%" align="left" bgcolor="#EDEDED"><b><span class="t02">Nome:</span></b></td>
              <td width="90%" align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_agenda_area['nome']; ?></span></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
          </table> <?php }?>
          <?php } while ($row_agenda_area = mysql_fetch_assoc($agenda_area)); ?>
        
       </td>
    </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td align="center" valign="top"><span class="t03">Agendamento mudan&ccedil;a Entrada</span></td>
      </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td align="center" valign="top">
		  
		  <?php if ($row_mudanca_entrada['id_cond'] == "") {} else {?>

        <?php do {  ?>
		
		<?php $today = date('Y-m-d') ; if ($row_mudanca_entrada['eventDate'] >= $today) {?>
			
            <?php 
            
			mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
			$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$row_mudanca_entrada['id_cond'];
			$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
			$row_condominio = mysql_fetch_assoc($condominio);
			$totalRows_condominio = mysql_num_rows($condominio);
			



?>
          <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td colspan="2" align="left" bgcolor="#EDEDED"><span class="t02">Cond.: <b><?php echo $row_condominio['nome_cond']; ?></b> / Uni: <b><?php echo $row_mudanca_entrada['id_unidade']; ?></b> - Data: <?php 
			  
			  $data_noticia_da_hora = $row_mudanca_entrada['eventDate']; 
			  
			   $data=explode("-",$data_noticia_da_hora);
    	$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	//echo($dataFinal);
	//  11 19:28:38/05/2010
	    $dia = substr($dataFinal,0,2);    // retorna "bcdef"
        $mes = substr($dataFinal, 3, 2); // retorna "bcd"
        $ano = substr($dataFinal, 6, 4); // retorna "abcd"
	    $dataok = $dia ."/". $mes . "/". $ano;
	    echo $dataok;?> - <a href="listar_agendamento_mudanca.php?id_cond=<?php echo $row_mudanca_entrada['id_cond']; ?>">ver</a></span></td>
            </tr>
            <tr>
              <td width="10%" align="left" bgcolor="#EDEDED"><b><span class="t02">Nome:</span></b></td>
              <td width="90%" align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_mudanca_entrada['nome']; ?></span></td>
            </tr>
            <tr>
              <td colspan="2" align="right" bgcolor="#EDEDED" class="t02"></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
          </table><?php }?>
          <?php } while ($row_mudanca_entrada = mysql_fetch_assoc($mudanca_entrada)); ?>
           
           <?php }?></td>
    </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td align="center" valign="top"><span class="t03">Agendamento mudan&ccedil;a Saida</span></td>
    </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
    </tr>
    <tr>
      <td align="center" valign="top"> <?php if ($row_mudanca_saida['id_cond'] == "") {} else {?>

        <?php do {  ?>
		
		<?php $today = date('Y-m-d') ; if ($row_mudanca_saida['eventDate'] >= $today) {?>
			
            <?php 
            
			mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
			$query_condominio = "SELECT condominios.nome_cond FROM condominios WHERE condominios.id_cond = ".$row_mudanca_saida['id_cond'];
			$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
			$row_condominio = mysql_fetch_assoc($condominio);
			$totalRows_condominio = mysql_num_rows($condominio);
			



?>
          <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td colspan="2" align="left" bgcolor="#EDEDED"><span class="t02">Cond.: <b><?php echo $row_condominio['nome_cond']; ?></b> / Uni: <b><?php echo $row_mudanca_saida['id_unidade']; ?></b> - Data: <?php 
			  
			  $data_noticia_da_hora = $row_mudanca_saida['eventDate']; 
			  
			   $data=explode("-",$data_noticia_da_hora);
    	$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	//echo($dataFinal);
	//  11 19:28:38/05/2010
	    $dia = substr($dataFinal,0,2);    // retorna "bcdef"
        $mes = substr($dataFinal, 3, 2); // retorna "bcd"
        $ano = substr($dataFinal, 6, 4); // retorna "abcd"
	    $dataok = $dia ."/". $mes . "/". $ano;
	    echo $dataok;?> - <a href="listar_agendamento_mudanca.php?id_cond=<?php echo $row_mudanca_saida['id_cond']; ?>">ver</a></span></td>
            </tr>
            <tr>
              <td width="10%" align="left" bgcolor="#EDEDED"><b><span class="t02">Nome:</span></b></td>
              <td width="90%" align="left" bgcolor="#EDEDED"><span class="t02">&nbsp;<?php echo $row_mudanca_saida['nome']; ?></span></td>
            </tr>
            <tr>
              <td colspan="2" align="right" bgcolor="#EDEDED" class="t02"></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
          </table><?php }?>
          <?php } while ($row_mudanca_saida = mysql_fetch_assoc($mudanca_saida)); ?>
           
           <?php }?></td>
    </tr>
  </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);

mysql_free_result($ocorrencia);

mysql_free_result($agenda_area);

mysql_free_result($mudanca_entrada);
mysql_free_result($mudanca_saida);
mysql_free_result($condominio);
?>
