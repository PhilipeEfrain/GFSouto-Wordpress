<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php 

//MX Widgets3 include
require_once('../includes/wdg/WDG.php');

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


	// resgato os valores de login
	
	$loginUsername = $_SESSION['MM_Username'];
	$data_agora = date("Y-m-d H:i:s"); // 2010-07-30 01:15:28
	
	// cadastrar log de acesso no banco de dados
	
  	$insertSQL = sprintf("INSERT INTO logs_acesso (data_hora, nome_admin) VALUES (%s, %s)",
                       GetSQLValueString($data_agora, "date"),
                       GetSQLValueString($loginUsername, "text"));

  	mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
  	$Result1 = mysql_query($insertSQL, $gf_souto_conect) or die(mysql_error());
   
    
	// redireciono para a administra��o
	$redirecionar = "admin.php";
	header("Location: $redirecionar");


?>