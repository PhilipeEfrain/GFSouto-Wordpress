<?php require_once('../Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
// Load the common classes
require_once('../includes/common/KT_common.php');
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "erro.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
// Load the tNG classes
require_once('../includes/tng/tNG.inc.php');

// Load the KT_back class
require_once('../includes/nxt/KT_back.php');

// Make a transaction dispatcher instance
$tNGs = new tNG_dispatcher("../");

// Make unified connection variable
$conn_gf_souto_conect = new KT_connection($gf_souto_conect, $database_gf_souto_conect);

// Start trigger
$formValidation = new tNG_FormValidation();
$formValidation->addField("nome_cond", true, "text", "", "", "", "");
$formValidation->addField("nome_superlogica", true, "text", "", "", "", "");
$formValidation->addField("email_cond", true, "text", "", "", "", "");
$formValidation->addField("usuario_sist_cond", true, "text", "", "", "", "");
$formValidation->addField("senha_sist_cond", true, "text", "", "", "", "");
$tNGs->prepareValidation($formValidation);
// End trigger

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$id = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_nomes = "SELECT * FROM `admin` WHERE `login` = '$id' LIMIT 1";
$nomes = mysql_query($query_nomes, $gf_souto_conect) or die(mysql_error());
$row_nomes = mysql_fetch_assoc($nomes);
$totalRows_nomes = mysql_num_rows($nomes);

// Make an insert transaction instance
$ins_condominios = new tNG_multipleInsert($conn_gf_souto_conect);
$tNGs->addTransaction($ins_condominios);
// Register triggers
$ins_condominios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Insert1");
$ins_condominios->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$ins_condominios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$ins_condominios->setTable("condominios");
$ins_condominios->addColumn("nome_cond", "STRING_TYPE", "POST", "nome_cond");
$ins_condominios->addColumn("nome_superlogica", "STRING_TYPE", "POST", "nome_superlogica");
$ins_condominios->addColumn("email_cond", "STRING_TYPE", "POST", "email_cond");
$ins_condominios->addColumn("email_sindico", "STRING_TYPE", "POST", "email_sindico");
$ins_condominios->addColumn("usuario_sist_cond", "STRING_TYPE", "POST", "usuario_sist_cond");
$ins_condominios->addColumn("senha_sist_cond", "STRING_TYPE", "POST", "senha_sist_cond");
$ins_condominios->setPrimaryKey("id_cond", "NUMERIC_TYPE");

// Make an update transaction instance
$upd_condominios = new tNG_multipleUpdate($conn_gf_souto_conect);
$tNGs->addTransaction($upd_condominios);
// Register triggers
$upd_condominios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Update1");
$upd_condominios->registerTrigger("BEFORE", "Trigger_Default_FormValidation", 10, $formValidation);
$upd_condominios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$upd_condominios->setTable("condominios");
$upd_condominios->addColumn("nome_cond", "STRING_TYPE", "POST", "nome_cond");
$upd_condominios->addColumn("nome_superlogica", "STRING_TYPE", "POST", "nome_superlogica");
$upd_condominios->addColumn("email_cond", "STRING_TYPE", "POST", "email_cond");
$upd_condominios->addColumn("email_sindico", "STRING_TYPE", "POST", "email_sindico");
$upd_condominios->addColumn("usuario_sist_cond", "STRING_TYPE", "POST", "usuario_sist_cond");
$upd_condominios->addColumn("senha_sist_cond", "STRING_TYPE", "POST", "senha_sist_cond");
$upd_condominios->setPrimaryKey("id_cond", "NUMERIC_TYPE", "GET", "id_cond");

// Make an instance of the transaction object
$del_condominios = new tNG_multipleDelete($conn_gf_souto_conect);
$tNGs->addTransaction($del_condominios);
// Register triggers
$del_condominios->registerTrigger("STARTER", "Trigger_Default_Starter", 1, "POST", "KT_Delete1");
$del_condominios->registerTrigger("END", "Trigger_Default_Redirect", 99, "../includes/nxt/back.php");
// Add columns
$del_condominios->setTable("condominios");
$del_condominios->setPrimaryKey("id_cond", "NUMERIC_TYPE", "GET", "id_cond");

// Execute all the registered transactions
$tNGs->executeTransactions();

// Get the transaction recordset
$rscondominios = $tNGs->getRecordset("condominios");
$row_rscondominios = mysql_fetch_assoc($rscondominios);
$totalRows_rscondominios = mysql_num_rows($rscondominios);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ADMINISTRA&Ccedil;&Atilde;O</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #000;
}
-->
</style>
<link href="CSS.css" rel="stylesheet" type="text/css" />
<link href="../includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<script src="../includes/common/js/base.js" type="text/javascript"></script>
<script src="../includes/common/js/utility.js" type="text/javascript"></script>
<script src="../includes/skins/style.js" type="text/javascript"></script>
<?php echo $tNGs->displayValidationRules();?>
<script src="../includes/nxt/scripts/form.js" type="text/javascript"></script>
<script src="../includes/nxt/scripts/form.js.php" type="text/javascript"></script>
<script type="text/javascript">
$NXT_FORM_SETTINGS = {
  duplicate_buttons: false,
  show_as_grid: true,
  merge_down_value: true
}
</script>
</head>

<body>
<table width="990" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" bgcolor="#FFFFFF"><table width="990" border="0" cellspacing="0" cellpadding="10">
      <tr>
        <td width="474" align="left"><img src="logo-para-painel-adm.gif" width="300" height="68" /></td>
        <td width="476" align="center" class="t01">GF SOUTO<br />
          <span class="t02">Voc&ecirc; est&aacute; logado como: </span><span class="erro"><?php echo $row_nomes['nome']; ?></span></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#ededed"><?php require_once('menu.php'); ?>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF" class="t01">Atualizar Condom&iacute;nios <?php $nome_pagina = "Atualizar condominios";?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF"><?php /*?>&nbsp;
      <?php
	echo $tNGs->getErrorMsg();
?>
      <div class="KT_tng">
        <h1>
          <?php 
// Show IF Conditional region1 
if (@$_GET['id_cond'] == "") {
?>
            <?php echo NXT_getResource("Insert_FH"); ?>
            <?php 
// else Conditional region1
} else { ?>
            <?php echo NXT_getResource("Update_FH"); ?>
            <?php } 
// endif Conditional region1
?>
          Condominios<?php */?> </h1>
        <div class="KT_tngform">
          <form method="post" id="form1" action="<?php echo KT_escapeAttribute(KT_getFullUri()); ?>">
            <?php $cnt1 = 0; ?>
            <?php do { ?>
              <?php $cnt1++; ?>
          <?php 
// Show IF Conditional region1 
if (@$totalRows_rscondominios > 1) {
?>
                <h2><?php echo NXT_getResource("Record_FH"); ?> <?php echo $cnt1; ?></h2>
                <?php } 
// endif Conditional region1
?>
              <table cellpadding="2" cellspacing="0" class="KT_tngtable">
                <tr>
                  <td class="KT_th"><label for="nome_cond_<?php echo $cnt1; ?>">Condom�nio:</label></td>
                  <td><input type="text" name="nome_cond_<?php echo $cnt1; ?>" id="nome_cond_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['nome_cond']); ?>" size="32" maxlength="150"  <?php if ($row_nomes['nivel'] <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                    <?php echo $tNGs->displayFieldHint("nome_cond");?> <?php echo $tNGs->displayFieldError("condominios", "nome_cond", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="nome_superlogica_<?php echo $cnt1; ?>">Nome Superlogica:</label></td>
                  <td><input name="nome_superlogica_<?php echo $cnt1; ?>" type="text" id="nome_superlogica_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['nome_superlogica']); ?>" size="32" maxlength="50" <?php if ($row_nomes['nivel'] <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                  <?php echo $tNGs->displayFieldHint("nome_superlogica");?> <?php echo $tNGs->displayFieldError("condominios", "nome_superlogica", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="email_cond_<?php echo $cnt1; ?>">Email:</label></td>
                  <td><input type="text" name="email_cond_<?php echo $cnt1; ?>" id="email_cond_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['email_cond']); ?>" size="32" maxlength="150"  <?php if ($row_nomes['nivel'] <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                    <?php echo $tNGs->displayFieldHint("email_cond");?> <?php echo $tNGs->displayFieldError("condominios", "email_cond", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="email_cond_<?php echo $cnt1; ?>2">Email s&iacute;ndico:</label></td>
                  <td><input type="text" name="email_sindico_<?php echo $cnt1; ?>" id="email_sindico_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['email_sindico']); ?>" size="32" maxlength="150"  <?php if ($row_nomes['nivel'] <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                  <?php echo $tNGs->displayFieldHint("email_sindico");?> <?php echo $tNGs->displayFieldError("condominios", "email_sindico", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="usuario_sist_cond_<?php echo $cnt1; ?>">Usu�rio:</label></td>
                  <td><input type="text" name="usuario_sist_cond_<?php echo $cnt1; ?>" id="usuario_sist_cond_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['usuario_sist_cond']); ?>" size="30" maxlength="30"  <?php if ($row_nomes['nivel'] <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                    <?php echo $tNGs->displayFieldHint("usuario_sist_cond");?> <?php echo $tNGs->displayFieldError("condominios", "usuario_sist_cond", $cnt1); ?></td>
                </tr>
                <tr>
                  <td class="KT_th"><label for="senha_sist_cond_<?php echo $cnt1; ?>">Senha:</label></td>
                  <td><input type="text" name="senha_sist_cond_<?php echo $cnt1; ?>" id="senha_sist_cond_<?php echo $cnt1; ?>" value="<?php echo KT_escapeAttribute($row_rscondominios['senha_sist_cond']); ?>" size="20" maxlength="20"  <?php if ($row_nomes['nivel']  <= 2 ) { ?>readonly="readonly" disabled="disabled" <?php }?> />
                    <?php echo $tNGs->displayFieldHint("senha_sist_cond");?> <?php echo $tNGs->displayFieldError("condominios", "senha_sist_cond", $cnt1); ?></td>
                </tr>
              </table>
          <input type="hidden" name="kt_pk_condominios_<?php echo $cnt1; ?>" class="id_field" value="<?php echo KT_escapeAttribute($row_rscondominios['kt_pk_condominios']); ?>" />
              <?php } while ($row_rscondominios = mysql_fetch_assoc($rscondominios)); ?>
            <div class="KT_bottombuttons">
              <div>
                <?php 
      // Show IF Conditional region1
      if (@$_GET['id_cond'] == "") {
      ?>
                  <?php 
      // else Conditional region1
      } else { ?>
                  <?php if ($row_nomes['nivel'] >= 2 ) { ?> <input type="submit" name="KT_Update1" value="<?php echo NXT_getResource("Update_FB"); ?>" /><?php }?>
                  <?php }
      // endif Conditional region1
      ?>
                <input type="button" name="KT_Cancel1" value="<?php echo NXT_getResource("Cancel_FB"); ?>" onclick="return UNI_navigateCancel(event, '../includes/nxt/back.php')" />
              </div>
            </div>
          </form>
        </div>
        <br class="clearfixplain" />
    </div></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF99">
      <table width="700" border="0" cellspacing="3" cellpadding="0">
      <tr>
        <td colspan="3" align="center" bgcolor="#CCCCCC"><b>&Uacute;ltimos acessos</b></td>
        </tr>
      <tr>
        <td width="232"><b>Login</b></td>
        <td width="303"><b>A&ccedil;&atilde;o</b></td>
        <td width="153"><b>Data / Hora</b></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="60" align="center" bgcolor="#FFFFFF"><a href="http://www.dsdigital.com.br" target="_blank">By DS Digital</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($nomes);
?>