<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "condominio.php?id_cond=".$_GET['id_cond']."&erro=1";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

$id_cond = $_GET['id_cond'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT * FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

$unidade = $_SESSION['MM_Username'];
//$senha = 
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_unidade_cliente = "SELECT * FROM unidade_clientes WHERE unidade_clientes.unidade = '$unidade' AND unidade_clientes.id_cond = '$id_cond'";
$unidade_cliente = mysql_query($query_unidade_cliente, $gf_souto_conect) or die(mysql_error());
$row_unidade_cliente = mysql_fetch_assoc($unidade_cliente);
$totalRows_unidade_cliente = mysql_num_rows($unidade_cliente);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->

<link type="text/css" href="css/ui-lightness/jquery-ui-1.8.7.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.7.custom.min.js"></script>
	    <script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
	    <script type="text/javascript">
	
	$(function() {
			   
					   
			var unavailableDates = [
									<?php if ($row_data_agenda_area['eventDate'] == "") { echo '"10-10-2000"'; } else {?>
									<?php do { ?>
									<?php $data_noticia_da_hora =  $row_data_agenda_area['eventDate']; //hora vinda do servidor
	$data=explode("-",$data_noticia_da_hora);
    $dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
    $dia = substr($dataFinal,0,2);    // retorna "bcdef"
    $mes = substr($dataFinal, 3, 2); // retorna "bcd"
    $ano = substr($dataFinal, 6, 4); // retorna "abcd"
    $dataok = $dia ."-". $mes . "-". $ano;
	echo '"'.$dataok.'",';
	?>
	<?php } while ($row_data_agenda_area = mysql_fetch_assoc($data_agenda_area)); ?>
	
	<?php 
	echo '"10-10-2000"';
	
	?><?php }?>];

			function unavailable(date) {
			  dmy = date.getDate() + "-" + (date.getMonth()+1) + "-" + date.getFullYear();
			  if ($.inArray(dmy, unavailableDates) == -1) {
				return [true, ""];
			  } else {
				return [false,"","N�O DISPON�VEL"];
			  }
			}
			
			$('#datepicker10').datepicker({ beforeShowDay: unavailable, minDate: "<?php 
										  
										  function SomarData($data, $dias, $meses, $ano)
																{
																   /*www.brunogross.com*/
																   //passe a data no formato dd/mm/yyyy 
																   $data = explode("-", $data);
																   $newData = date("j-n-Y", mktime(0, 0, 0, $data[1] + $meses,
																   $data[0] + $dias, $data[2] + $ano) );
																   return $newData;
																}

echo SomarData(date("j-n-Y"), 2, 0,0); ?>" });
			$('#agenda_data').datepicker({ beforeShowDay: unavailable, minDate: "<?php echo SomarData(date("j-n-Y"), 1, 0,0); ?>" });
			//$('#agenda_data').datepicker({ beforeShowDay: unavailable, minDate: "<?php //echo date('j-n-Y'); ?>" });
			//$("#datepicker10").datepicker({ minDate: <?php// echo $dias_total10 ?> });
			//$('#datepicker10').datePicker({ startDate: '09/09/2011', endDate: (new Date()).asString()});
			
			//$("#datepicker11").datepicker({ minDate: <?php //echo $dias_total11 ?> });
			 
			 
			 
			

});

        </script>
</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond">
  	  <table width="990" border="0" cellspacing="0" cellpadding="0">
  	    <tr>
  	      <td width="330">&nbsp;</td>
  	      <td width="660">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td rowspan="6"><a href="./"><img src="logo-marca-gf-souto.png" width="327" height="117" border="0" /></a></td>
  	      <td align="center"><strong>&Aacute;REA DO CLIENTE</strong></td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">Bem vindo <span class="cliente">
          <?php //echo $row_cliente['nome']; ?>
          <?php 
		  
		  
		  		if ($row_unidade_cliente['unidade'] == "") {
			  
			   		header("Location: ?doLogout=true");
			  	}
		  
		  echo $row_unidade_cliente['unidade']; 
		  
		  
		  
		  ?>
          </span> - <a href="<?php echo $logoutAction ?>">Sair</a></td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
      </table>
  	</div>
    <div id="nome_cond">
   	  <!--<div id="logo_cond"></div>-->
      <div id="nome_cond_titulo"><?php echo $row_condominio['nome_cond']; ?></div>
    </div>
    <div id="bannerflash">
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="980" height="90">
        <param name="movie" value="baner_condominios.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="baner_condominios.swf" width="980" height="90">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="opaque" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
      <div id="conteudocentro">
      <table width="970" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="208" align="center" valign="top"><?php include_once('menu_condominios.php'); ?></td>
              <td colspan="2" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="30" bgcolor="#D8D8D8" class="t06">&nbsp;&nbsp;Caixa de sugest&otilde;es</td>
                </tr>
                <tr>
                  <td><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sugira, d&ecirc; a sua opini&atilde;o, ela &eacute; importante. Melhore cada vez mais o seu condom&iacute;nio</span></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="center"><form id="contato" name="contato" method="post" action="caixa_de_sugestoes_ok.php?id_cond=<?php echo $_GET['id_cond']; ?>&amp;id_area=<?php echo $_GET['id_area']; ?>"    onsubmit="return checa_contato()">
                    <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="22%">&nbsp;</td>
                        <td width="56%">&nbsp;</td>
                        <td width="22%">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">Nome</td>
                        <td height="30" align="left"><label>
                          <input name="nome_contato" type="text" class="input2" id="nome_contato" />
                          </label></td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">Email</td>
                        <td height="30" align="left"><input name="email_contato" type="text" class="input2" id="email_contato" /></td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">Telefone</td>
                        <td height="30" align="left"><input name="telefone_contato" type="text" class="input2" id="telefone_contato" /></td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td rowspan="2" align="left" valign="top" class="t01">Sugest&atilde;o:</td>
                        <td rowspan="2" align="left"><label>
                          <textarea name="mensagem_contato" id="mensagem_contato" cols="45" rows="5"></textarea>
                        </label></td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <!--<tr>
                        <td align="left" class="t01">Hor&aacute;rio</td>
                        <td align="left"><table width="70%" border="0" align="left" cellpadding="0" cellspacing="0">
                          <tr>
                              <td width="42%">De
                                <select name="de" id="de">
                                <option value="06:00" selected="selected">06:00</option>
                                <option value="07:00">07:00</option>
                                <option value="08:00">08:00</option>
                                <option value="09:00">09:00</option>
                                <option value="10:00">10:00</option>
                                <option value="11:00">11:00</option>
                                <option value="12:00">12:00</option>
                                <option value="13:00">13:00</option>
                                <option value="14:00">14:00</option>
                                <option value="15:00">15:00</option>
                                <option value="16:00">16:00</option>
                                <option value="17:00">17:00</option>
                                <option value="18:00">18:00</option>
                                <option value="19:00">19:00</option>
                                <option value="20:00">20:00</option>
                                <option value="21:00">21:00</option>
                                <option value="22:00">22:00</option>
                                <option value="23:00">23:00</option>
                                <option value="00:00">00:00</option>
                              </select></td>
                              <td width="58%">&aacute;s
<select name="ass" id="ass">
                                <option value="06:00" selected="selected">06:00</option>
                                <option value="07:00">07:00</option>
                                <option value="08:00">08:00</option>
                                <option value="09:00">09:00</option>
                                <option value="10:00">10:00</option>
                                <option value="11:00">11:00</option>
                                <option value="12:00">12:00</option>
                                <option value="13:00">13:00</option>
                                <option value="14:00">14:00</option>
                                <option value="15:00">15:00</option>
                                <option value="16:00">16:00</option>
                                <option value="17:00">17:00</option>
                                <option value="18:00">18:00</option>
                                <option value="19:00">19:00</option>
                                <option value="20:00">20:00</option>
                                <option value="21:00">21:00</option>
                                <option value="22:00">22:00</option>
                                <option value="23:00">23:00</option>
                                <option value="00:00">00:00</option>
                              </select></td>
                            </tr>
                          </table></td>
                      </tr>-->
                      <tr>
                        <td align="left"><input name="assunto" type="hidden" id="assunto" value="asdf asdf asdf" /></td>
                      </tr>
                      <tr>
                        <td align="left">&nbsp;</td>
                        <td align="left"><label>
                          <input name="button" type="submit" class="botao" id="button" value="Enviar" />
                        </label></td>
                        <td align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td><input name="agenda_unidade" type="hidden" id="agenda_unidade" value="<?php echo $unidade ?>" />
                          <input name="nome_area" type="hidden" id="nome_area" value="<?php echo $row_n_area['nome_area']; ?>" /></td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td class="t04">&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                    </table>
                  </form></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
          </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
        </table>
        </div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape"><?php include_once('rodape2.php'); ?></div>
  </div>
</div>
<script type="text/javascript">
var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
swfobject.registerObject("FlashID");
</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($condominio);

/*mysql_free_result($cliente);*/

mysql_free_result($unidade_cliente);

?>
