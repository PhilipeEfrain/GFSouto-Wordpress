<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}



if (isset($_POST['unidade'])) {
	
  
  
  $nome_supe=$_POST['nome_super'];// resgata o nome do condominio
  
	mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
	$query_nome_super = "SELECT condominios.id_cond, condominios.nome_superlogica FROM condominios WHERE condominios.nome_superlogica = '$nome_supe'";
	$nome_super = mysql_query($query_nome_super, $gf_souto_conect) or die(mysql_error());
	$row_nome_super = mysql_fetch_assoc($nome_super);
	$totalRows_nome_super = mysql_num_rows($nome_super);
	
	$id_cond = $row_nome_super['id_cond'];// pega do form
	
	/////////////////////////////////////////
  
  $loginUsername=$_POST['unidade'];
  $password=$_POST['senha_unidade'];
  $condiminio = $id_cond;
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "condominio_logado.php?id_cond=".$id_cond;
  $MM_redirectLoginFailed = "condominio.php?id_cond=".$id_cond."&erro=1";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
  
 
  
  
  
  $LoginRS__query=sprintf("SELECT id_cond, unidade, senha FROM unidade_clientes WHERE id_cond=%s AND unidade=%s AND senha=%s",
   GetSQLValueString($condiminio, "text"), GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $gf_souto_conect) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;
	$_SESSION['MM_senha'] = $_POST['senha_unidade'];
	

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<?php
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

//$id_cond = $_GET['id_cond'];
/*
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.id_cond, condominios.nome_cond, condominios.logo_cond FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);*/

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->


<script src="https://s3-sa-east-1.amazonaws.com/widgets.superlogica.net/embed.js" ></script>

</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond"><table width="990" border="0" cellspacing="0" cellpadding="0">
  	    <tr>
  	      <td width="496">&nbsp;</td>
  	      <td width="494">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td rowspan="3" align="left"><a href="./"><img src="logo-marca-gf-souto.png" width="327" height="117" border="0" /></a></td>
  	      <td>&nbsp;</td>
        </tr>
  	    <tr>
  	      <td>&nbsp;</td>
        </tr>
  	    <tr>
  	      <td>&nbsp;</td>
        </tr>
  	    <tr>
  	      <td>&nbsp;</td>
  	      <td>&nbsp;</td>
        </tr>
      </table></div>
    <div id="nome_cond">
   	  <!--<div id="logo_cond"></div>-->
      <div id="nome_cond_titulo">Acesso restrito<?php //echo $row_condominio['nome_cond']; ?></div>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
        <div id="titulo_informativo">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="13%" align="center"><img src="alert-xxl.png" alt="" width="61" height="61" /></td>
              <td width="87%" align="center">
                <p>Prezado Cliente,em busca de aperfei&ccedil;oarmos nosso atendimento e servi&ccedil;o passamos por uma atualiza&ccedil;&atilde;o em nosso sistema. </p></td>
            </tr>
          </table>
          <p>&nbsp;</p>
      </div>
        <div id="texto_bemvindo" style="font-size:13px">
          <p>Para o novo acesso siga os seguintes passos:</p>
          <p>&nbsp;</p>
          <ol>
            <li>Desabilite  a janela poup-up do seu navegador. <br />
              <br />
            </li>
            <li>Digite  o e-mail do seu cadastro junto ao Condom&iacute;nio. IMPORTANTE: Caso  esteja desatualizado ou n&atilde;o se recorde, favor entrar em contato atrav&eacute;s do  telefone (84) 3323-1250, op&ccedil;&atilde;o atualiza&ccedil;&atilde;o de cadastro ou ent&atilde;o encaminhe um  e-mail para <a href="mailto:adm@gfsouto.com.br">adm@gfsouto.com.br</a>.<br />
              <br />
            </li>
            <li>O sistema reconhecer&aacute; seu e-mail e solicitar&aacute;  uma senha, como &eacute; o primeiro novo acesso, clique em esqueci a senha.<br />
              <br />
            </li>
            <li>Voc&ecirc; receber&aacute; um e-mail em sua caixa de entrada  (verificar tamb&eacute;m no lixo eletr&ocirc;nico) com as instru&ccedil;&otilde;es para nova senha e o  login.<br />
              <br />
            </li>
            <li>Pronto agora voc&ecirc; ter&aacute; acesso a segunda via de  boletos e outros documentos do seu Condom&iacute;nio.</li>
          </ol>
          <p>&nbsp;</p><br />
<script type="text/javascript">
/*{literal}<![CDATA[*/
function renderizarModulo(){
superlogica.require("condominios");
superlogica.condominios("areadocondomino","","gfsouto");
}
/*]]>{/literal}*/
</script>
<div>
<button class="bt-areacondomino botao" onclick="renderizarModulo();">Acessar aqui</button>
</div>

        </div>
        <div id="conteudocentro"></div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape"><?php include_once('rodape.php'); ?></div>
  </div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
<?php
mysql_free_result($titulo);

?>
