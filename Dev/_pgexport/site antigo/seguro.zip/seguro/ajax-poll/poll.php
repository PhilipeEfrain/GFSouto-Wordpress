<?php

/* $conn=mysql_connect('localhost', 'root', '') or die("N�o conectou ao host Mysql.");
mysql_select_db('oab_poll') or die("N�o conectou ao banco de dados da enquete.");
*/

$conn=mysql_connect('localhost', 'dsdigital', 'tzpfv9BqMctqwSvH') or die("N�o conectou ao host Mysql.");
mysql_select_db('gfsouto_2011') or die("N�o conectou ao banco de dados da enquete.");


if(!$_POST['poll'] || !$_POST['pollid']){
	$query=mysql_query("SELECT id, ques FROM questions ORDER BY id DESC LIMIT 1");
	while($row=mysql_fetch_assoc($query)){
		//display question
		echo "<p class=\"pollques\" >".$row['ques']."</p>";
		$poll_id=$row['id'];
	}
	if($_GET["result"]==1 || $_COOKIE["voted".$poll_id]=='yes'){
		//if already voted or asked for result
		showresults($poll_id);
		exit;
	}
	else{
	//display options with radio buttons
		$query=mysql_query("SELECT id, value FROM options WHERE ques_id=$poll_id");
		if(mysql_num_rows($query)){
			echo '<div id="formcontainer" ><form method="post" id="pollform" action="'.$_SERVER['PHP_SELF'].'" >';
			echo '<input type="hidden" name="pollid" value="'.$poll_id.'" />';
			while($row=mysql_fetch_assoc($query)){
				echo '<p class=\"resposta\"><input type="radio" name="poll" value="'.$row['id'].'" id="option-'.$row['id'].'" /> 
				<label for="option-'.$row['id'].'" >'.$row['value'].'</label></p>';
			}
			echo '<br/><input type="submit"  value="   " class="botao_fom2"/>&nbsp;&nbsp;&nbsp;<a href="'.$_SERVER['PHP_SELF'].'?result=1" id="viewresult">Ver parcial</a></form>';
			// echo ' <a href="'.$_SERVER['PHP_SELF'].'?result=1" id="viewresult">Ver parcial</a></div>'; // editado por denilson
			
		}
	}
}
else{
	if($_COOKIE["voted".$_POST['pollid']]!='yes'){
		
		//Check if selected option value is there in database?
		$query=mysql_query("SELECT * FROM options WHERE id='".intval($_POST["poll"])."'");
		if(mysql_num_rows($query)){
			$query="INSERT INTO votes(option_id, voted_on, ip) VALUES('".$_POST["poll"]."', '".date('Y-m-d H:i:s')."', '".$_SERVER['REMOTE_ADDR']."')";
			if(mysql_query($query))
			{
				//Vote added to database
				//setcookie("voted".$_POST['pollid'], 'yes', time()+86400*300); 1 ano
				setcookie("voted".$_POST['pollid'], 'yes', time()+82800*1);	// 23 horas			
			}
			else
				echo "There was some error processing the query: ".mysql_error();
		}
	}
	showresults(intval($_POST['pollid']));
}
function showresults($poll_id){
	global $conn;
	$query=mysql_query("SELECT COUNT(*) as totalvotes FROM votes WHERE option_id IN(SELECT id FROM options WHERE ques_id='$poll_id')");
	while($row=mysql_fetch_assoc($query))
		$total=$row['totalvotes'];
	$query=mysql_query("SELECT options.id, options.value, COUNT(*) as votes FROM votes, options WHERE votes.option_id=options.id AND votes.option_id IN(SELECT id FROM options WHERE ques_id='$poll_id') GROUP BY votes.option_id");
	while($row=mysql_fetch_assoc($query)){
		$percent=round(($row['votes']*100)/$total);
		echo '<div class="option" ><p>'.$row['value'].' <br/>(<em>'.$percent.'%, '.$row['votes'].' votos</em>)</p>';
		echo '<div class="bar2"><div class="bar';
		if($_POST['poll']==$row['id']) echo ' seu voto';
		echo '" style="width: '.$percent.'%; " ></div></div></div>';
	}
	echo '
		
	<p>Total de Votos: '.$total.'</p>';
}