<?php 
    // Obtendo n�mero de visitas
    $txt        = "visitas.txt";
    $arquivo = fopen($txt,"r");
    $visitas   = fgets($arquivo,1024); 
    fclose($arquivo);

    // Atualizando n�mero de visitas
   // $arquivo  = fopen($txt,"r+");
   // $visitas = $visitas + 1;
   // fwrite($arquivo,$visitas);
   // fclose($arquivo);
?>
	  <?php
   // Imprime n�mero de visitas
    echo "$visitas";
?>