<table width="990" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="390" align="left">&nbsp;</td>
          <td width="556" align="left" valign="top">&nbsp;</td>
          <td width="44" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td align="left"><span class="t02">&copy; <?php echo date("Y"); ?> - GF Souto - Todos os direitos reservados</span></td>
          <td width="556" align="left" valign="top">&nbsp;</td>
          <td width="44" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td align="left">&nbsp;</td>
          <td width="556" align="left" valign="top">&nbsp;</td>
          <td width="44" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td rowspan="3" align="left"><table width="380" cellpadding="0" cellspacing="0"  class="t02">
            <tr align="center">
              <td colspan="2" align="left"><span class="t02">Rua Amaro Duarte, 241, Nova Bet&acirc;nia</span></td>
            </tr>
            <tr align="center">
              <td colspan="2" align="left"><span class="t02">CEP 59.603.030 - Mossor&oacute; / RN </span></td>
            </tr>
            <tr>
              <td width="13%" align="left"><span class="t02">Fone:</span></td>
              <td width="87%" align="left"><span class="t02"> (84) 3323 - 1250</span></td>
            </tr>
            <tr>
              <td align="left"><span class="t02">E-mail: </span></td>
              <td align="left"><a href="mailto:contato@gfsouto.com.br">contato@gfsouto.com.br</a></td>
            </tr>
          </table></td>
          <td width="556" align="left" valign="top">&nbsp;</td>
          <td width="44" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td width="556" align="left" valign="top">&nbsp;</td>
          <td width="44" align="left">&nbsp;</td>
        </tr>
        <tr>
          <td width="556" rowspan="3" align="right"><img src="CADEADO-SEGURANCA-DS-DIGITAL2.png" alt="" width="50" height="50" border="0" align="absmiddle" /><span class="t02">Site seguro&nbsp;&nbsp;&nbsp;&nbsp;</span></td>
          <td rowspan="3" align="center"><a href="http://www.dsdigital.com.br" title="BY DS DIGITAL" target="_blank"><img src="assinatura_ds_digital.png" alt="BY DS DIGITAL" width="38" height="35" border="0" /></a></td>
        </tr>
        <tr>
          <td align="left" class="t02">&nbsp;</td>
        </tr>
        <tr>
          <td align="left" class="t02"><a href="politica_privacidade_seguranca.php">Pol&iacute;tica de privacidade e seguran&ccedil;a</a></td>
        </tr>
        <tr>
          <td><span  class="f_rod">Visitas:
              <?php include_once('contar_visitas.php'); ?>
          </span></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>