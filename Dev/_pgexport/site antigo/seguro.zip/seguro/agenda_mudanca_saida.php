<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "condominio.php?id_cond=".$_GET['id_cond']."&erro=1";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

$id_cond = $_GET['id_cond'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT * FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

$unidade = $_SESSION['MM_Username'];
//$senha = 
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_unidade_cliente = "SELECT * FROM unidade_clientes WHERE unidade_clientes.unidade = '$unidade' AND unidade_clientes.id_cond = '$id_cond'";
$unidade_cliente = mysql_query($query_unidade_cliente, $gf_souto_conect) or die(mysql_error());
$row_unidade_cliente = mysql_fetch_assoc($unidade_cliente);
$totalRows_unidade_cliente = mysql_num_rows($unidade_cliente);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_mudanca = "SELECT *,  DATE_FORMAT(eventDate, '%c-%e-%Y') AS dataok  FROM mudanca WHERE mudanca.id_cond = '$id_cond ' AND mudanca.ativo = 1";
$mudanca = mysql_query($query_mudanca, $gf_souto_conect) or die(mysql_error());
$row_mudanca = mysql_fetch_assoc($mudanca);
$totalRows_mudanca = mysql_num_rows($mudanca);


/*mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_cliente = "SELECT cadastro_clientes.id_cliente, cadastro_clientes.nome FROM cadastro_clientes WHERE cadastro_clientes.id_cliente =".$row_unidade_cliente['id_cliente'];
$cliente = mysql_query($query_cliente, $gf_souto_conect) or die(mysql_error());
$row_cliente = mysql_fetch_assoc($cliente);
$totalRows_cliente = mysql_num_rows($cliente);*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->

		<link type="text/css" href="css/ui-lightness/jquery-ui-1.8.7.custom.css" rel="stylesheet" />	
		<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
	    <script type="text/javascript" src="js/jquery-ui-1.8.7.custom.min.js"></script>
        
        <script type="text/javascript">
	
	/* create an array of days which need to be disabled */
				/*var disabledDays = ["8-07-2012", "7-17-2012", "7-17-2020"];*/
			var disabledDays = [<?php do { ?>
								<?php echo '"'.$row_mudanca['dataok'].'",'; ?>
																				 <?php } while ($row_mudanca = mysql_fetch_assoc($mudanca)); ?>
	<?php echo '"7-17-2020"';?>];
			
			/* utility functions */
			function nationalDays(date) {
			  var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
			  //console.log('Checking (raw): ' + m + '-' + d + '-' + y);
			  for (i = 0; i < disabledDays.length; i++) {
				if($.inArray((m+1) + '-' + d + '-' + y,disabledDays) != -1 || new Date() > date) {
				  //console.log('bad:  ' + (m+1) + '-' + d + '-' + y + ' / ' + disabledDays[i]);
				  return [false];
				}
			  }
			  //console.log('good:  ' + (m+1) + '-' + d + '-' + y);
			  return [true];
			}
			function noWeekendsOrHolidays(date) {
			  var noWeekend = jQuery.datepicker.noWeekends(date);
			  return noWeekend[0] ? nationalDays(date) : noWeekend;
			}
			
			/* create datepicker */
			jQuery(document).ready(function() {
			  jQuery('#agenda_data').datepicker({
				minDate: new Date(2012, 0, 1),
				maxDate: new Date(2019, 5, 31),
				dateFormat: 'd-mm-yy', //Sexta, Julho, 27, 2012
				//dateFormat: 'DD, MM, d, ', //Sexta, Julho, 27, 2012
				constrainInput: true,
				//beforeShowDay: noBefore
				beforeShowDay: noWeekendsOrHolidays
			  });
			});

</script>
        <script src="includes/common/js/base.js" type="text/javascript"></script>
        <script src="includes/common/js/utility.js" type="text/javascript"></script>
        <script type="text/javascript" src="includes/wdg/classes/MXWidgets.js"></script>
        <script type="text/javascript" src="includes/wdg/classes/MXWidgets.js.php"></script>
        <script type="text/javascript" src="includes/wdg/classes/MaskedInput.js"></script>
        <link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond">
  	  <table width="990" border="0" cellspacing="0" cellpadding="0">
  	    <tr>
  	      <td width="330">&nbsp;</td>
  	      <td width="660">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td rowspan="6"><a href="./"><img src="logo-marca-gf-souto.png" width="327" height="117" border="0" /></a></td>
  	      <td align="center"><strong>&Aacute;REA DO CLIENTE</strong></td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">Bem vindo <span class="cliente">
          <?php //echo $row_cliente['nome']; ?>
          <?php 
		  
		  
		  		if ($row_unidade_cliente['unidade'] == "") {
			  
			   		header("Location: ?doLogout=true");
			  	}
		  
		  echo $row_unidade_cliente['unidade']; 
		  
		  
		  
		  ?>
          </span> - <a href="<?php echo $logoutAction ?>">Sair</a></td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
      </table>
  	</div>
    <div id="nome_cond">
   	  <!--<div id="logo_cond"></div>-->
      <div id="nome_cond_titulo"><?php echo $row_condominio['nome_cond']; ?></div>
    </div>
    <div id="bannerflash">
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="980" height="90">
        <param name="movie" value="baner_condominios.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="baner_condominios.swf" width="980" height="90">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="opaque" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
      <div id="conteudocentro">
      <table width="970" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="208" align="center" valign="top"><?php include_once('menu_condominios.php'); ?></td>
              <td colspan="2" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="30" bgcolor="#D8D8D8" class="t06">&nbsp;&nbsp;&nbsp;Agendamento - mudan&ccedil;a de sa&iacute;da<img src="CADEADO-SEGURANCA-DS-DIGITAL3.png" alt="" width="25" height="25" border="0" align="absmiddle" /><span class="t01">&nbsp;&nbsp;&nbsp;Site seguro</span></td>
                </tr>
                <tr>
                  <td>&nbsp;<!--<iframe src="reservas_mudanca.php?id_cond=<?php// echo $_GET['id_cond']; ?>" width="100%" height="400" scrolling="no" frameborder="0"></iframe>--><!--<div id="datepicker10"></div>--></td>
                </tr>
                <tr>
                  <td><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Preencha os campos abaixo para fazer o agendamento de sua mudan&ccedil;a. <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Por favor, ap&oacute;s preencher e enviar seu agendamento imprima o aviso e entregue  na portaria do condom&iacute;nio.</span></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="center"><?php if ($_GET['id_cond'] == 2) { echo "Agendamentos pela internet cancelados pela sindica!!";} else {?><form id="agenda" name="agenda" method="post" action="agenda_mudanca_saida_ok.php?id_cond=<?php echo $_GET['id_cond']; ?>"  onsubmit="return checa_agenda_saida()">
                    <table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr align="left">
                        <td height="40" colspan="4"><b>DADOS DO CONDOM&Iacute;NIO</b></td>
                        </tr>
                      <tr>
                        <td width="23%" height="30" align="left" class="t01">Condom&iacute;nio*</td>
                        <td width="30%" height="30" align="left"><label>
                          <input name="agenda_condominio" type="text" class="input2" id="agenda_condominio" value="<?php echo $row_condominio['nome_cond']; ?>" readonly="readonly" />
                        </label></td>
                        <td width="23%" height="30" align="left"><span class="t01">Unidade(ap, casa)*</span></td>
                        <td width="24%" height="30" align="left"><input name="agenda_unidade" type="text" class="input2" id="agenda_unidade" value="<?php  echo $row_unidade_cliente['unidade'];?>" readonly="readonly" /></td>
                      </tr>
                      <tr align="left">
                        <td height="40" colspan="4"><b>DADOS PESSOAIS</b></td>
                        </tr>
                      <tr>
                        <td height="30" align="left" class="t01">Seu Nome*</td>
                        <td height="30" align="left"><input name="agenda_nome" type="text" class="input2" id="agenda_nome" /></td>
                        <td height="30" align="left">&nbsp;</td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">&nbsp;</td>
                        <td height="30" align="left">&nbsp;</td>
                        <td height="30" align="left">&nbsp;</td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">E-mail*</td>
                        <td height="30" colspan="2" align="left"><label>
                          <input name="agenda_email" type="text" class="input2" id="agenda_email" />
                        </label></td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">&nbsp;</td>
                        <td height="30" colspan="2" align="left" class="t01">&nbsp;</td>
                        <td height="30" align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td height="30" align="left" class="t01">Fone residencial*</td>
                        <td height="30" align="left"><input name="agenda_telefone" class="input2" id="agenda_telefone" value="" wdg:subtype="MaskedInput" wdg:mask="(99) 9999 - 9999" wdg:restricttomask="no" wdg:type="widget" /></td>
                        <td height="30" align="left"><span class="t01">Celular*</span></td>
                        <td height="30" align="left"><input name="agenda_celular" class="input2" id="agenda_celular" value="" wdg:subtype="MaskedInput" wdg:mask="(99) 9999 - 9999" wdg:restricttomask="no" wdg:type="widget" /></td>
                      </tr>
                      <tr align="left">
                        <td height="40" colspan="4"><b>DATA E HORA DA MUDAN&Ccedil;A</b></td>
                      </tr>
                      <tr>
                        <td height="30" align="center">Data</td>
                        <td height="30" align="center"><input name="agenda_data" type="text" class="input2" id="agenda_data" readonly="readonly" /></td>
                        <td height="30" align="center">Hora </td>
                        <td height="30" align="center"><select name="dataehora" id="dataehora">
                          <option value="08h &agrave;s 11h e 14h &agrave;s 17h">08h &agrave;s 11h e 14h &agrave;s 17h</option>
                          <option value="S&aacute;b 08h ao 12h">S&aacute;b 08h ao 12h</option>
                        </select></td>
                        </tr>
                      <tr>
                        <td align="left" class="t01">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td colspan="4" align="left" class="t01"><p>IMPORTANTE! </p>
                          <p>1 - N&atilde;o agendamos para dom&iacute;ngos e feriados.</p>
                          <p>2 - Os agendamentos ser&atilde;o feitos de segunda &agrave; sexta de 8:00 &agrave;s 11:00 e 14:00 &agrave;s 17:00.</p>
                          <p>3 - S&aacute;bados somente de 8:00 &agrave;s 12:00.</p>
                          <p>4 - Por favor, ap&oacute;s preencher e enviar seu agendamento imprima o aviso e entregue  na portaria do condom&iacute;nio.</p></td>
                        </tr>
                      <tr>
                        <td align="left" class="t01">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td align="left" valign="top" class="t01">&nbsp;</td>
                        <td colspan="3" align="left" valign="top">&nbsp;</td>
                        </tr>
                      <tr>
                        <td align="left">&nbsp;</td>
                        <td align="left"><label>
                          <input name="button" type="submit" class="botao" id="button" value="Enviar" />
                        </label></td>
                        <td align="left">&nbsp;</td>
                        <td align="left">&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td><input name="agenda_unidade" type="hidden" id="agenda_unidade" value="<?php echo $unidade ?>" />
                          <input name="mudanca" type="hidden" id="mudanca" value="1" />
                        <!--  mudanca de entrada = 0 saida= 1 --></td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                      <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                    </table>
                  </form><?php } ; ?></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </table>
        </div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape"><?php include_once('rodape2.php'); ?></div>
  </div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($condominio);

/*mysql_free_result($cliente);*/

mysql_free_result($unidade_cliente);

mysql_free_result($mudanca);
?>
