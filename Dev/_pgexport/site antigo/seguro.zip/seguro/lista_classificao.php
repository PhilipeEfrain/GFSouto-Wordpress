<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_classificado = "SELECT * FROM gf_categorias ORDER BY nome_gf_clas";
$classificado = mysql_query($query_classificado, $gf_souto_conect) or die(mysql_error());
$row_classificado = mysql_fetch_assoc($classificado);
$totalRows_classificado = mysql_num_rows($classificado);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_lista_estabe = "SELECT * FROM gf_classificado WHERE gf_classificado.categoria_gf_clas =".$_GET['i'];
$lista_estabe = mysql_query($query_lista_estabe, $gf_souto_conect) or die(mysql_error());
$row_lista_estabe = mysql_fetch_assoc($lista_estabe);
$totalRows_lista_estabe = mysql_num_rows($lista_estabe);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_classificado2 = "SELECT * FROM gf_categorias WHERE gf_categorias.id_gf_cat =".$_GET['i'];
$classificado2 = mysql_query($query_classificado2, $gf_souto_conect) or die(mysql_error());
$row_classificado2 = mysql_fetch_assoc($classificado2);
$totalRows_classificado2 = mysql_num_rows($classificado2);

// Initialize the Alternate Color counter
$ac_sw1 = 0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id="conteiner_topo">
  <div id="topo">
    <div id="logomarca">
      <p><a href="./" title="GF SOUTO"><img src="imagens/logo-marca-gf-souto.png" alt="GF SOUTO" width="330" height="191" border="0" /></a></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p class="t05">Quando voc&ecirc; precisa, 
  <br />
  n&oacute;s estamos aqui. </p>
</div>
    <div id="menu"> 
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="600" height="355">
        <param name="movie" value="menu_topo_gfsouto.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="transparent" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="menu_topo_gfsouto.swf" width="600" height="355">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="transparent" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
        <div id="titulo_informativo">Ache aqui - <b><?php echo  $row_classificado2['nome_gf_clas']?></b></div>
        <div id="texto_bemvindo">Ache Empresas e Servi�os em Mossor&oacute; e Regi&atilde;o</div>
      	<div id="conteudocentro">
      	  <table width="970" border="0" cellspacing="0" cellpadding="0">
      	    <tr>
      	      <td width="200">&nbsp;</td>
      	      <td width="720">&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td align="left" valign="top">
              <div id="menu_classificado">
               <table width="100%" border="0" cellpadding="0" cellspacing="0">
      	        <?php do { ?>
      	          <tr bgcolor="<?php echo ($ac_sw1++%2==0)?"#F7F7F7":"#FFFFFF"; ?>" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#FFFF99'">
      	            <td height="20"><a href="lista_classificao.php?i=<?php echo $row_classificado['id_gf_cat']; ?>"><?php echo $row_classificado['nome_gf_clas']; ?></a></td>
   	              </tr>
      	          <?php } while ($row_classificado = mysql_fetch_assoc($classificado)); ?>
              </table>
              </div></td>
      	      <td align="center" valign="top" class="t03">
			  
              <?php if (empty($row_lista_estabe['nome_estabelecimento'])) { echo "Nenhum resultado encontrado para <b>". $row_classificado2['nome_gf_clas']."</b><br />
SEJA O PRIMEIRO, ENTRE EM CONTATO CONOSCO!";} else {?>
              
			  <?php do { ?>
   	            <div id="gf_lista">
   	              <table width="700" border="0" cellpadding="0" cellspacing="0">
   	                <tr>
   	                  <td width="190" rowspan="9" align="center">
					  <?php if ($row_lista_estabe['logomarca'] != "") {?>
					  
					  <?php if ($row_lista_estabe['website'] != "") {?><div><a href="http://<?php echo $row_lista_estabe['website']; ?>" title="VISITAR" target="_blank"><img src="classificados_gf_souto/<?php echo $row_lista_estabe['id_gf_clas']; ?>/<?php echo $row_lista_estabe['logomarca']; ?>" alt="VISITAR" width="150" border="0"/></a></div><?php } else {?><div><img src="classificados_gf_souto/<?php echo $row_lista_estabe['id_gf_clas']; ?>/<?php echo $row_lista_estabe['logomarca']; ?>" alt="" width="150"/></div><?php }?>
                      
                      <?php }?></td>
   	                  <td align="center">&nbsp;</td>
                    </tr>
   	                <tr>
   	                  <td align="left"><b><?php echo $row_lista_estabe['nome_estabelecimento']; ?></b></td>
                    </tr>
   	                <tr>
   	                  <td width="510" align="left">&nbsp;</td>
                    </tr>
   	                <tr>
   	                  <td align="left"><span class="t04">Fone(s): <b><?php echo $row_lista_estabe['telefone1']; ?> <?php if ($row_lista_estabe['telefone2'] != "") {?>/ <?php echo $row_lista_estabe['telefone2']; ?><?php }?>
   	                  </b></span></td>
                    </tr>
   	                <tr>
   	                  <td align="left"><span class="t04">End.: <?php echo $row_lista_estabe['endereco']; ?></span></td>
                    </tr>
   	                <tr>
   	                  <td align="left"><span class="t04">E-mail: <a href="mailto:<?php echo $row_lista_estabe['email1']; ?>"><?php echo $row_lista_estabe['email1']; ?></a> <?php if ($row_lista_estabe['google_Maps'] != "") {?>/ Localiza&ccedil;&atilde;o no Mapa <a href="<?php echo $row_lista_estabe['google_Maps']; ?>" title="VER NO LOCALIZA&Ccedil;&Atilde;O NO GOOGLE MAPS" target="_blank"><img src="Google_maps_logo.jpg" alt="VER NO LOCALIZA&Ccedil;&Atilde;O NO GOOGLE MAPS" width="100" height="21" border="0" align="absmiddle" /></a><?php }?></span></td>
                    </tr>
   	                <tr>
   	                  <td align="left"><span class="t04"><?php echo $row_lista_estabe['descricao']; ?></span></td>
                    </tr>
   	                <tr>
   	                  <td align="left"><?php if ($row_lista_estabe['website'] != "") {?>Site:<a href="http://<?php echo $row_lista_estabe['website']; ?>" title="VISITAR" target="_blank"><?php echo $row_lista_estabe['website']; ?></a><?php }?></td>
                    </tr>
   	                <tr>
   	                  <td>&nbsp;</td>
                    </tr>
                  </table>
                </div>
   	          <?php } while ($row_lista_estabe = mysql_fetch_assoc($lista_estabe)); ?>
              
              <?php }?>
              
              
              </td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
   	      </table>
      	</div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape">
    <?php include_once('rodape2.php'); ?>
    </div>
  </div>
</div>
<script type="text/javascript">
<!--
swfobject.registerObject("FlashID");
//-->
</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($classificado);

mysql_free_result($lista_estabe);
?>
