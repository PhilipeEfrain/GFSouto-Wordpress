<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('includes/wdg/WDG.php');
?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "condominio.php?id_cond=".$_GET['id_cond']."&erro=1";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

$id_cond = $_GET['id_cond'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT * FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

$unidade = $_SESSION['MM_Username'];
//$senha = 
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_unidade_cliente = "SELECT * FROM unidade_clientes WHERE unidade_clientes.unidade = '$unidade' AND unidade_clientes.id_cond = '$id_cond'";
$unidade_cliente = mysql_query($query_unidade_cliente, $gf_souto_conect) or die(mysql_error());
$row_unidade_cliente = mysql_fetch_assoc($unidade_cliente);
$totalRows_unidade_cliente = mysql_num_rows($unidade_cliente);


##//////////////////// REGISTRANDO NO BANCO DE DADOS /////////////////////////////////////////////////////////


//PEGANDO DADOS DO FORM

$agenda_nome = $_POST['agenda_nome'];
$agenda_email = $_POST['agenda_email'];
$agenda_telefone = $_POST['agenda_telefone'];
$agenda_unidade = $_POST['agenda_unidade'];
$agenda_data = $_POST['agenda_data'];
$agenda_mensagem = $_POST['agenda_mensagem'];
$nome_area = $_POST['nome_area'];
$dataehora = $_POST['dataehora'];
$de = $dataehora;
$ass = "00";
/*$de = $_POST['de'];
$ass = $_POST['ass'];*/

$id_cliente = "";
$ativo = "1";
$id_area = $_GET['id_area'];
	///MODIFCANDO A DATA

	$data_noticia_da_hora = $agenda_data; //hora vinda do servidor

	$data=explode("-",$data_noticia_da_hora);
    $dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	//echo($dataFinal);
	//  11 19:28:38/05/2010
	$dia = substr($dataFinal,8,2);    // retorna "bcdef"
    $mes = substr($dataFinal, 5, 2); // retorna "bcd"
    $ano = substr($dataFinal, 0, 4); // retorna "2011"
	//$hora = substr($dataFinal, 3, 8); // retorna "abcd"
	//$autor = $row_noticia_da_hora['autor_noticia'];
	$dataok = $ano ."-". $mes . "-". $dia;
	//$dataok = $dia ."/". $mes . "/". $ano .  " &agrave;s ". $hora . " por ". $autor;
	//$dataok = $dia ."/". $mes . "/". $ano;
	//echo $dataok;
	
	//////////////FIM DA MODIFICA��O DA DATA

  $insertSQL = sprintf("INSERT INTO areas_agenda (id, id_cond, id_unidade, id_area, eventDate, eventTitle, eventContent, nome, email, fone, de, ass, ativo) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString("", "int"),
                       GetSQLValueString($id_cond, "text"),
					   GetSQLValueString($unidade, "text"),
                       GetSQLValueString($id_area, "text"),
                       GetSQLValueString($dataok, "date"),
                       GetSQLValueString($agenda_unidade, "text"),
                       GetSQLValueString($agenda_unidade, "text"),
                       GetSQLValueString($agenda_nome, "text"),
                       GetSQLValueString($agenda_email, "text"),
                       GetSQLValueString($agenda_telefone, "text"),
					   GetSQLValueString($de, "text"),
					   GetSQLValueString($ass, "text"),
                       GetSQLValueString($ativo, "text"));

  mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
  $Result1 = mysql_query($insertSQL, $gf_souto_conect) or die(mysql_error());
  


/////////////////////// ENVIANDO E-MAIL PARA O SETOR RESPONS�VEL ///////////////////////
$email_cadastrado = "atendimento@gfsouto.com.br";
////////////////////////////////////////////////////////////////////////////////////////

/* Destinat�rio */ 
$to = $email_cadastrado ; 
/* Assunto */ 
$subject = "Reserva ".$nome_area." - ".$row_condominio['nome_cond']; 
/* Mensagem */ 
$message = '<table width="600" border="0" align="center" cellpadding="5" cellspacing="5">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2" align="center" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="4" color="#000000">GF SOUTO</font><font face="Arial, Helvetica, sans-serif" size="4" color="#000000"><br />
          Agendamento - '. $nome_area.'</font></td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td width="23%" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
        <td width="77%" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Condom&iacute;nio&nbsp;</font></b></td>
        <td width="77%" align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $row_condominio['nome_cond'] .'</font></b></td>
      </tr>
      
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Unidade</font></b></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $agenda_unidade .'</font></b></td>
      </tr>
      <tr bgcolor="#EFEFEF">
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Data</font></b></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_data.' - de ('. $de.'</font></b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">) <b>&aacute;s ('. $ass.' )</b></font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Nome</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_nome.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">E-mail</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><a href="mailto:'. $agenda_email .'"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_email .'</font></a></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Fone</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_telefone.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Observa&ccedil;&otilde;es</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_mensagem.'</font></td>
      </tr>
    </table></td>
  </tr>
</table>'; 

$headers = "MIME-Version: 1.0\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\n"; 
$headers .= "From:". $agenda_email ."\n"; // de
$headers .= "Cc: Reserva - GF Souto <operacional@gfsouto.com.br>\n"; // copia
//$headers .= "Bcc: Mudan�a - GF Souto <teste@desenhartstudio.com.br>\n"; // erro/teste
$headers .= "Return-Path: Reserva GF Souto <".$email_cadastrado.">\n"; // email de retorno

$data = date("j/n/Y");// data atual

$headers2 = "MIME-Version: 1.0\n"; 
$headers2 .= "Content-type: text/html; charset=iso-8859-1\n"; 
$headers2 .= "From: Reserva - GF Souto <". $email_cadastrado.">\n"; // para
/* Enviando a mensagem */ 

$to2 = $agenda_nome . "<". $agenda_email .">\n";
$subject2 = "Reserva Recebida" ;
$message2 = '<table width="600" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="100" align="center"><strong style="font-size: 24px; font-family: Arial, Helvetica, sans-serif;">GF SOUTO</strong></td>
      </tr>
      <tr>
        <td><table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF"><font face="Verdana, Geneva, sans-serif" size="2">
              <p>Ol&aacute; Sr.(a) <font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_nome .'</font>. !</p>
              <p>Este e-mail indica que a sua reserva foi recebida com sucesso, confira os dados abaixo.</p>
              <p>&nbsp;</p>
            </font></td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="23%" align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Condom&iacute;nio&nbsp;</font></b></td>
        <td width="77%" align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $row_condominio['nome_cond'] .'</font></b></td>
      </tr>
      
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Unidade</font></b></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $agenda_unidade .'</font></b></td>
      </tr>
	  <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Area</font></b></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. 
          $nome_area .'</font></b></td>
      </tr>
      <tr bgcolor="#EFEFEF">
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Data</font></b></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><b><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_data.'</font></b></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Nome</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_nome.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">E-mail</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><a href="mailto:'. $agenda_email .'"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_email .'</font></a></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">Fone</font></td>
        <td align="left" valign="top" bgcolor="#F5F5F5"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_telefone.'</font></td>
      </tr>
      <tr>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Observa&ccedil;&otilde;es</font></td>
        <td align="left" valign="top" bgcolor="#FFFFFF"><font face="Arial, Helvetica, sans-serif" size="2" color="#000000">'. $agenda_mensagem.'</font></td>
      </tr>
    </table></td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td align="left" bgcolor="#FFFFFF"><p>&nbsp;</p>
              <p><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><b>GF SOUTO</b> <br>
                Rua Amaro Duarte, 241, Nova Bet&acirc;nia<br />
                CEP 59.603.030 - Mossor&oacute; / RN<br />
                Fone: 	(84) 3314 - 1703<br />
                E-mail: 	<a href="mailto:contato@gfsouto.com.br">contato@gfsouto.com.br</a></font></p>
              <p>&nbsp;</p></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF"><font color="#000000" size="2">Salve nossos e-mails em sua lista de e-mails segura ou lista branca.</font> </td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>';
mail($to, $subject, $message, $headers);
mail($to2, $subject2, $message2, $headers2);


/*mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_cliente = "SELECT cadastro_clientes.id_cliente, cadastro_clientes.nome FROM cadastro_clientes WHERE cadastro_clientes.id_cliente =".$row_unidade_cliente['id_cliente'];
$cliente = mysql_query($query_cliente, $gf_souto_conect) or die(mysql_error());
$row_cliente = mysql_fetch_assoc($cliente);
$totalRows_cliente = mysql_num_rows($cliente);*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->

<script type="text/javascript" src="includes/common/js/sigslot_core.js"></script>
<script src="includes/common/js/base.js" type="text/javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript"></script>
<script type="text/javascript" src="includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="includes/wdg/classes/Calendar.js"></script>
<script type="text/javascript" src="includes/wdg/classes/SmartDate.js"></script>
<script type="text/javascript" src="includes/wdg/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="includes/wdg/calendar/calendar-setup_stripped.js"></script>
<script src="includes/resources/calendar.js"></script>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
<!--
@media print {

#topo_cond{
display: none;
}
#linha{
display: none;
}
#rodape_fundo{
display: none;
}
#menu1{
display: none;
}
#rodape{
display: none;
}
#esconder{
display: none;
}

}

-->

</style>
</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond">
  	  <table width="990" border="0" cellspacing="0" cellpadding="0">
  	    <tr>
  	      <td width="330">&nbsp;</td>
  	      <td width="660">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td rowspan="6"><a href="./"><img src="logo-marca-gf-souto.png" width="327" height="117" border="0" /></a></td>
  	      <td align="center"><strong>&Aacute;REA DO CLIENTE</strong></td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">Bem vindo <span class="cliente">
          <?php //echo $row_cliente['nome']; ?>
          <?php 
		  
		  
		  		if ($row_unidade_cliente['unidade'] == "") {
			  
			   		header("Location: ?doLogout=true");
			  	}
		  
		  echo $row_unidade_cliente['unidade']; 
		  
		  
		  
		  ?>
          </span> - <a href="<?php echo $logoutAction ?>">Sair</a></td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
      </table>
  	</div>
    <div id="nome_cond">
   	  <!--<div id="logo_cond"></div>-->
      <div id="nome_cond_titulo"><?php echo $row_condominio['nome_cond']; ?></div>
    </div>
    <div id="bannerflash">
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="980" height="90">
        <param name="movie" value="baner_condominios.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="baner_condominios.swf" width="980" height="90">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="opaque" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
<div id="conteudocentro">
<table width="970" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="208" align="center" valign="top"><?php include_once('menu_condominios.php'); ?></td>
              <td colspan="2" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="30" bgcolor="#D8D8D8" class="t06">&nbsp;&nbsp;&nbsp;Agenda de &aacute;reas comuns</td>
                </tr>
                <tr>
                  <td><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fa&ccedil;a a sua reserva antecipada, com no m&iacute;nimo 48 horas de anteced&ecirc;ncia</span>.<br />
                    <span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Por favor, ap&oacute;s preencher e enviar seu agendamento imprima o aviso e entregue  na portaria do condom&iacute;nio.<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; O agendamento somente ser&aacute; confirmado ap&oacute;s o aviso ter sido impresso e entregue na portaria. <br />
                  </span></td>
                </tr>
                <tr>
                  <td><div id="imprimir"><table width="700" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="100" align="center"><font face="Verdana, Geneva, sans-serif" style="font-size: 50px; font-family: 'Arial Black', Gadget, sans-serif;"><img src="http://www.gfsouto.com.br/novo/logo-marca-gf-souto.png" width="117" height="117" /></font></td>
      </tr>
      <tr>
        <td><table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="right" bgcolor="#FFFFFF"><p>&nbsp;</p>
              <p><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: large">Mossor&oacute; (RN),  <?php echo $data ;?></font></p></td>
          </tr>
          <tr>
            <td height="100" align="left" bgcolor="#FFFFFF"><p><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: x-large">Aos senhores cond&ocirc;minos do</font></p></td>
          </tr>
          <tr>
            <td height="100" align="left" bgcolor="#FFFFFF"><font size="2" face="Verdana, Geneva, sans-serif"><span style="font-size: 36px; font-weight: bold;"><font color="#000000"><?php echo $row_condominio['nome_cond']; ?></font></span></font></td>
          </tr>
          <tr>
            <td height="100" align="left" bgcolor="#FFFFFF"><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: x-large">Prezados (as) Senhores (as)</font></td>
          </tr>
          <tr>
            <td height="300" align="left" bgcolor="#FFFFFF"><p><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: x-large">Informamos que no dia  <strong><?php 
			
				$data_noticia_da_hora = $_POST['agenda_data']; //hora vinda do servidor

				$data=explode("-",$data_noticia_da_hora);
				$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
				$dia = substr($dataFinal,8,2);    // retorna "bcdef"
				$mes = substr($dataFinal, 5, 2); // retorna "bcd"
				$ano = substr($dataFinal, 0, 4); // retorna "2011"
				$dataok = $dia ."/". $mes . "/". $ano;
	            echo $dataok;
	?> </strong>das <strong><?php echo $dataehora ;?></strong>, foi reservado &agrave; &aacute;rea <b><?php echo $nome_area ;?></b>  para a unidade <strong><?php echo $agenda_unidade ?></strong>.</font></p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: x-large">Cordialmente,</font></p>
              <p><font size="2" face="Verdana, Geneva, sans-serif" style="font-size: x-large">A Administra&ccedil;&atilde;o.</font></p></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF"><p>&nbsp;</p>
              <p><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><b>GF SOUTO</b> <br>
                Rua Amaro Duarte, 241, Nova Bet&acirc;nia<br />
                CEP 59.603.030 - Mossor&oacute; / RN<br />
                Fone: 	(84) 3314 - 1703 ( segunda &agrave; Sexta: 8:00 &agrave;s 11:00 e 13:30 &agrave;s 17:30)<br />
                E-mail: 	<a href="mailto:contato@gfsouto.com.br">contato@gfsouto.com.br</a></font></p></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
          <tr>
            <td align="center" bgcolor="#FFFFFF"><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fa&ccedil;a a sua reserva antecipada, com no m&iacute;nimo 48 horas de anteced&ecirc;ncia</span>.<br />
              <span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Por favor, ap&oacute;s preencher e enviar seu agendamento imprima o aviso e entregue  na portaria do condom&iacute;nio.<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; O agendamento somente ser&aacute; confirmado ap&oacute;s o aviso ter sido impresso e entregue na portaria. <br />
              </span></td>
          </tr>
          <tr>
            <td bgcolor="#FFFFFF">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table></div></td>
                </tr>
                <tr>
                  <td align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="center"><input id="button" name="button" type="button" class="botao" onclick="imprimir()" value="IMPRIMIR" /></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          </table>
        </div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape"><?php include_once('rodape2.php'); ?></div>
  </div>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($condominio);

/*mysql_free_result($cliente);*/

mysql_free_result($unidade_cliente);
?>
