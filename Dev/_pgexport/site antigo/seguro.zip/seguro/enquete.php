<?php $id_cond = $_GET['id_cond']; ?>
<!--INICIO ENQUETE POLL-->
<link rel="stylesheet" type="text/css" href="ajax-poll/styles.css" />
<script type="text/javascript" src="ajax-poll/js/jquery-1.3.2.js" ></script>
<script type="text/javascript" >
$(function(){
	var loader=$('#loader');
	var pollcontainer=$('#pollcontainer');
	loader.fadeIn();
	//Load the poll form
	$.get('ajax-poll/poll.php?id_cond=<?php $id_cond = $_GET['id_cond']; ?>', '', function(data, status){
		pollcontainer.html(data);
		animateResults(pollcontainer);
		pollcontainer.find('#viewresult').click(function(){
			//if user wants to see result
			loader.fadeIn();
			$.get('ajax-poll/poll.php?id_cond=<?php $id_cond = $_GET['id_cond']; ?>', 'result=1', function(data,status){
				pollcontainer.fadeOut(1000, function(){
					$(this).html(data);
					animateResults(this);
				});
				loader.fadeOut();
			});
			//prevent default behavior
			return false;
		}).end()
		.find('#pollform').submit(function(){
			var selected_val=$(this).find('input[name=poll]:checked').val();
			if(selected_val!=''){
				//post data only if a value is selected
				loader.fadeIn();
				$.post('ajax-poll/poll.php', $(this).serialize(), function(data, status){
					$('#formcontainer').fadeOut(100, function(){
						$(this).html(data);
						animateResults(this);
						loader.fadeOut();
					});
				});
			}
			//prevent form default behavior
			return false;
		});
		loader.fadeOut();
	});
	
	function animateResults(data){
		$(data).find('.bar').hide().end().fadeIn('slow', function(){
							$(this).find('.bar').each(function(){
								var bar_width=$(this).css('width');
								$(this).css('width', '0').animate({ width: bar_width }, 1000);
							});
						});
	}
	
});
</script>
<!--FIM ENQUETE POLL-->
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<!--INICIO ENQUETE POLL-->
<div id="container" >
		<div id="enquete"></div>
		<div id="pollcontainer" >
</div>
		<p id="loader" >Carregando...</p>
	</div>
    <!--FINAL ENQUETE POLL-->