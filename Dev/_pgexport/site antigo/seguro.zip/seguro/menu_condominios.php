<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css">

<table width="200" border="0" cellpadding="0" cellspacing="0" id="menu1"><tr><td><form action="Http://superlogica.com/hpserver/indexb.php" method="post" target="_blank">
                <input type="image" src="boletosgif.gif" />
                <br />
                <input name="apelido" type="hidden" id="apelido" value="<?php echo $row_condominio['nome_superlogica']; ?>" />
                <input name="login" type="hidden" id="login" value="<?php echo $row_unidade_cliente['unidade'];?>" />
                <input name="senha" type="hidden" id="senha" value="<?php echo $_SESSION['MM_senha']; ?>" />
              </form></td></tr>
  <tr>
    <td><ul id="MenuBar1" class="MenuBarVertical">
<li><a href="condominio_logado.php?id_cond=<?php echo $_GET['id_cond']; ?>">In&iacute;cio</a></li>
<li><a href="classificados.php" target="_blank"><img src="viewmag.png" width="22" height="22" border="0" align="absmiddle" />&nbsp;&nbsp;ACHE AQUI</a></li>
<?php /*?><li><a href="reservas.php?id_cond=<?php echo $_GET['id_cond']; ?>">Agendamento  de &aacute;reas</a></li>
<li><a href="agenda_mudanca.php?id_cond=<?php echo $_GET['id_cond']; ?>">Agend. mudan&ccedil;a entrada</a></li>
<li><a href="agenda_mudanca_saida.php?id_cond=<?php echo $_GET['id_cond']; ?>">Agend. mudan&ccedil;a sa&iacute;da</a></li>
<li><a href="classificados_condominios.php?id_cond=<?php echo $_GET['id_cond']; ?>">Classificados</a></li><?php */?>
<li><a href="caixa_de_sugestoes.php?id_cond=<?php echo $_GET['id_cond']; ?>">Caixa de sugest�es</a></li>
<li><a href="livro_de_ocorrencia.php?id_cond=<?php echo $_GET['id_cond']; ?>">Livro de Ocorr&ecirc;ncia</a></li>
<li><a href="fale_com_o_sindico.php?id_cond=<?php echo $_GET['id_cond']; ?>">Fale com o s&iacute;ndico</a></li>
<?php /*?><li><a href="status_de_obras.php?id_cond=<?php echo $_GET['id_cond']; ?>">Status de obras</a></li><?php */?>
<li><a href="Funcionarios.php?id_cond=<?php echo $_GET['id_cond']; ?>">Funcion&aacute;rios</a></li>
<?php /*?><li><a href="enquetes.php?id_cond=<?php echo $_GET['id_cond']; ?>">Enquete</a></li><?php */?>
    </ul></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><a href="livro_de_ocorrencia.php?id_cond=<?php echo $_GET['id_cond']; ?>"><img src="gfimg_03.jpg" width="200" height="70" border="0" /></a></td>
  </tr>
  <tr>
    <td><a href="reservas.php?id_cond=<?php echo $_GET['id_cond']; ?>"><img src="reservas_03.jpg" width="200" height="70" border="0" /></a></td>
  </tr>
  <tr>
    <td><a href="caixa_de_sugestoes.php?id_cond=<?php echo $_GET['id_cond']; ?>"><img src="sugestoes.jpg" width="201" height="70" border="0" /></a></td>
  </tr>
  <tr>
    <td></td>
  </tr>
</table>

<script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
