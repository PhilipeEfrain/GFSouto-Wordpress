<?php
define('KT_CAPTCHA_TEMP_FOLDER', dirname(__FILE__).'/../../_temp/.captcha/');
define('KT_CAPTCHA_TEMP_URL', 'includes/common/_temp/.captcha/');
?>