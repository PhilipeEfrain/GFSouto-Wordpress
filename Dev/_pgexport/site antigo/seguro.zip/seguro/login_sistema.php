<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['unidade'])) {
  $loginUsername=$_POST['unidade'];
  $password=$_POST['senha_unidade'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "condominio_logado.php?id_cond=".$_GET['id_cond'];
  $MM_redirectLoginFailed = "condominio.php?id_cond=1&erro=1";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
  
  $LoginRS__query=sprintf("SELECT unidade, senha FROM unidade_clientes WHERE unidade=%s AND senha=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $gf_souto_conect) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<?php
mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

$id_cond = $_GET['id_cond'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT condominios.id_cond, condominios.nome_cond, condominios.logo_cond FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->
</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond"></div>
    <div id="nome_cond">
   	  <div id="logo_cond"></div>
      <div id="nome_cond_titulo"><?php echo $row_condominio['nome_cond']; ?></div>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
        <div id="titulo_informativo">Login</div>
        <div id="texto_bemvindo">&Aacute;rea restrita para clientes GF Souto</div>
        <div id="conteudocentro">
          <form id="login_cond" name="login_cond" method="POST" action="<?php echo $loginFormAction; ?>"  onsubmit="return checarlogin()">
            <table width="350" border="0" cellpadding="0" cellspacing="0" id="logindocliente">
              <tr>
                <td align="center">Unidade</td>
              </tr>
              <tr>
                <td align="center" class="erro"><?php 
				
						if (isset($_GET['erro'])) {
							if ($_GET['erro'] == "1") {echo "Sua unidade ou senha est&atilde;o errados." ;
							}
							
						}
						
						
						?></td>
              </tr>
              <tr>
                <td align="center"><label>
                  <input name="unidade" type="text" class="input" id="unidade" />
                </label></td>
              </tr>
              <tr>
                <td align="center">&nbsp;</td>
              </tr>
              <tr>
                <td align="center">Senha</td>
              </tr>
              <tr>
                <td align="center">&nbsp;</td>
              </tr>
              <tr>
                <td align="center"><label>
                  <input name="senha_unidade" type="password" class="input" id="senha_unidade" />
                </label></td>
              </tr>
              <tr>
                <td align="center">&nbsp;</td>
              </tr>
              <tr>
                <td align="center"><label>
                  <input name="button" type="submit" class="botao" id="button" value="Ok" />
                </label></td>
              </tr>
            </table>
            <input name="id_cond" type="hidden" id="id_cond" value="a<?php echo $_GET['id_cond']; ?>" />
          </form>
        </div>
    </div>
    <div id="linha"></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape">&nbsp;</div>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($condominio);
?>
