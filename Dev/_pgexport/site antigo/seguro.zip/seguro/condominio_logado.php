<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "condominio.php?id_cond=".$_GET['id_cond']."&erro=1";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

$id_cond = $_GET['id_cond'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_condominio = "SELECT * FROM condominios WHERE condominios.id_cond = '$id_cond'";
$condominio = mysql_query($query_condominio, $gf_souto_conect) or die(mysql_error());
$row_condominio = mysql_fetch_assoc($condominio);
$totalRows_condominio = mysql_num_rows($condominio);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_mural = "SELECT * FROM mural WHERE mural.id_cond = '$id_cond'";
$mural = mysql_query($query_mural, $gf_souto_conect) or die(mysql_error());
$row_mural = mysql_fetch_assoc($mural);
$totalRows_mural = mysql_num_rows($mural);

$unidade = $_SESSION['MM_Username'];

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_unidade_cliente = "SELECT * FROM unidade_clientes WHERE unidade_clientes.unidade = '$unidade' AND unidade_clientes.id_cond = '$id_cond'";
$unidade_cliente = mysql_query($query_unidade_cliente, $gf_souto_conect) or die(mysql_error());
$row_unidade_cliente = mysql_fetch_assoc($unidade_cliente);
$totalRows_unidade_cliente = mysql_num_rows($unidade_cliente);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_aviso_geral = "SELECT * FROM aviso_geral WHERE aviso_geral.ativo = 1";
$aviso_geral = mysql_query($query_aviso_geral, $gf_souto_conect) or die(mysql_error());
$row_aviso_geral = mysql_fetch_assoc($aviso_geral);
$totalRows_aviso_geral = mysql_num_rows($aviso_geral);

$maxRows_documentos = 5;
$pageNum_documentos = 0;
if (isset($_GET['pageNum_documentos'])) {
  $pageNum_documentos = $_GET['pageNum_documentos'];
}
$startRow_documentos = $pageNum_documentos * $maxRows_documentos;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_documentos = "SELECT * FROM documentos WHERE documentos.id_cond =  '$id_cond'";
$query_limit_documentos = sprintf("%s LIMIT %d, %d", $query_documentos, $startRow_documentos, $maxRows_documentos);
$documentos = mysql_query($query_limit_documentos, $gf_souto_conect) or die(mysql_error());
$row_documentos = mysql_fetch_assoc($documentos);

if (isset($_GET['totalRows_documentos'])) {
  $totalRows_documentos = $_GET['totalRows_documentos'];
} else {
  $all_documentos = mysql_query($query_documentos);
  $totalRows_documentos = mysql_num_rows($all_documentos);
}
$totalPages_documentos = ceil($totalRows_documentos/$maxRows_documentos)-1;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_classificado = "SELECT * FROM classificado WHERE classificado.id_cond = '$id_cond' AND classificado.ativo = 1";
$classificado = mysql_query($query_classificado, $gf_souto_conect) or die(mysql_error());
$row_classificado = mysql_fetch_assoc($classificado);
$totalRows_classificado = mysql_num_rows($classificado);

$maxRows_agendamudanca = 10;
$pageNum_agendamudanca = 0;
if (isset($_GET['pageNum_agendamudanca'])) {
  $pageNum_agendamudanca = $_GET['pageNum_agendamudanca'];
}
$startRow_agendamudanca = $pageNum_agendamudanca * $maxRows_agendamudanca;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_agendamudanca = "SELECT * FROM mudanca WHERE mudanca.id_cond = '$id_cond' AND mudanca.ativo = 1";
$query_limit_agendamudanca = sprintf("%s LIMIT %d, %d", $query_agendamudanca, $startRow_agendamudanca, $maxRows_agendamudanca);
$agendamudanca = mysql_query($query_limit_agendamudanca, $gf_souto_conect) or die(mysql_error());
$row_agendamudanca = mysql_fetch_assoc($agendamudanca);

if (isset($_GET['totalRows_agendamudanca'])) {
  $totalRows_agendamudanca = $_GET['totalRows_agendamudanca'];
} else {
  $all_agendamudanca = mysql_query($query_agendamudanca);
  $totalRows_agendamudanca = mysql_num_rows($all_agendamudanca);
}
$totalPages_agendamudanca = ceil($totalRows_agendamudanca/$maxRows_agendamudanca)-1;

$maxRows_agendamentoarea = 10;
$pageNum_agendamentoarea = 0;
if (isset($_GET['pageNum_agendamentoarea'])) {
  $pageNum_agendamentoarea = $_GET['pageNum_agendamentoarea'];
}
$startRow_agendamentoarea = $pageNum_agendamentoarea * $maxRows_agendamentoarea;

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_agendamentoarea = "SELECT * FROM areas_agenda WHERE areas_agenda.id_cond = '$id_cond' AND areas_agenda.ativo = 1";
$query_limit_agendamentoarea = sprintf("%s LIMIT %d, %d", $query_agendamentoarea, $startRow_agendamentoarea, $maxRows_agendamentoarea);
$agendamentoarea = mysql_query($query_limit_agendamentoarea, $gf_souto_conect) or die(mysql_error());
$row_agendamentoarea = mysql_fetch_assoc($agendamentoarea);

if (isset($_GET['totalRows_agendamentoarea'])) {
  $totalRows_agendamentoarea = $_GET['totalRows_agendamentoarea'];
} else {
  $all_agendamentoarea = mysql_query($query_agendamentoarea);
  $totalRows_agendamentoarea = mysql_num_rows($all_agendamentoarea);
}
$totalPages_agendamentoarea = ceil($totalRows_agendamentoarea/$maxRows_agendamentoarea)-1;


// Initialize the Alternate Color counter
$ac_sw2 = 0;

// Initialize the Alternate Color counter
$ac_sw3 = 0;

// Initialize the Alternate Color counter
$ac_sw1 = 0;

/*mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_cliente = "SELECT cadastro_clientes.id_cliente, cadastro_clientes.nome FROM cadastro_clientes WHERE cadastro_clientes.id_cliente =".$row_unidade_cliente['id_cliente'];
$cliente = mysql_query($query_cliente, $gf_souto_conect) or die(mysql_error());
$row_cliente = mysql_fetch_assoc($cliente);
$totalRows_cliente = mysql_num_rows($cliente);*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<!--INICIO JQUERY DS DIGITAL  -->
<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
<script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
<!--FIM JQUERY DS DIGITAL-->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>
<div id="conteiner_topo_cond">
  <div id="topo_cond">
  	<div id="menu_cond">
  	  <table width="990" border="0" cellspacing="0" cellpadding="0">
  	    <tr>
  	      <td width="177">&nbsp;</td>
  	      <td width="813">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td rowspan="6"><a href="./"><img src="logo-marca-gf-souto.png" width="327" height="117" border="0" /></a></td>
  	      <td align="center"><strong>&Aacute;REA DO CLIENTE</strong></td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="center">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
  	    <tr>
  	      <td align="right">Bem vindo <span class="cliente">
          <?php //echo $row_cliente['nome']; ?>
          <?php 
		  
		  

		  
		  echo $row_unidade_cliente['unidade']; 
		  
		  
		  
		  ?>
          </span> - <a href="<?php echo $logoutAction ?>">Sair</a></td>
        </tr>
  	    <tr>
  	      <td align="right">&nbsp;</td>
        </tr>
      </table>
  	</div>
    <div id="nome_cond">
   	  <!--<div id="logo_cond"></div>-->
      <div id="nome_cond_titulo"><?php echo $row_condominio['nome_cond']; ?></div>
    </div>
    <div id="bannerflash">
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="980" height="90">
        <param name="movie" value="baner_condominios.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="baner_condominios.swf" width="980" height="90">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="opaque" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
    <div id="bannertopo"><?php include_once('banner_topo.php'); ?></div>
      <div id="conteudocentro">
      <table width="970" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="208" rowspan="9" align="center" valign="top"><?php include_once('menu_condominios.php'); ?></td>
              <td colspan="2" valign="top"><?php if ($row_aviso_geral['ativo'] == 0) {} else {?><div id="aviso"><span class="cliente">Importante!</span><br />
                <b><?php echo $row_aviso_geral['chamada_galeria']; ?></b><br />
                <br />
                <?php echo $row_aviso_geral['texto']; ?><br />
                <br />
              <?php 
			  
			 	$data_noticia_da_hora =  $row_aviso_geral['data_cadastro']; //hora vinda do servidor

				$data=explode("-",$data_noticia_da_hora);
				$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
			//echo($dataFinal);
			//  11 19:28:38/05/2010
				$dia = substr($dataFinal,0,2);    // retorna "bcdef"
				$mes = substr($dataFinal, 3, 2); // retorna "bcd"
				$ano = substr($dataFinal, 6, 4); // retorna "abcd"
				$dataok = $dia ."/". $mes . "/". $ano;
				echo $dataok;
		
		?></div><?php }?></td>
            </tr>
            <tr>
              <td width="376" valign="top" class="t07">&nbsp;</td>
              <td valign="top" class="t07">&nbsp;</td>
            </tr>
            <tr>
              <td valign="top" class="t07">&nbsp;<img src="signature.png" width="32" height="32" align="absmiddle" />&nbsp;&nbsp;QUADRO DE AVISO</td>
              <td valign="top" class="t07">&nbsp;<img src="todo.png" width="32" height="32" align="absmiddle" />&nbsp;&nbsp;ENQUETE</td>
            </tr>
            <tr>
              <td valign="top"><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Voc&ecirc; sempre informado sobre seu condom&iacute;nio</span></td>
              <td valign="top"><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sua opni&atilde;o &eacute; muito importante</span></td>
            </tr>
            <tr>
              <td align="center" valign="top"><div id="mural">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#FFFFCC"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" bgcolor="#CCCCCC"><strong>
          <?php
			  
			  
			    $data_noticia_da_hora = $row_mural['data_publi']; //hora vinda do servidor

				$data=explode("-",$data_noticia_da_hora);
				$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
				$dia = substr($dataFinal,0,2);    // retorna "bcdef"
				$mes = substr($dataFinal, 3, 2); // retorna "bcd"
				$ano = substr($dataFinal, 6, 4); // retorna "abcd"
				$dataok = $dia ."/". $mes . "/". $ano;
	            echo $dataok;
				
				
				?>
        </strong></td>
        </tr>
      <tr class="t04">
        <td align="center">&nbsp;</td>
        </tr>
      <tr class="t04">
        <td align="center"><?php echo $row_mural['texto_mural']; ?></td>
      </tr>
      <tr class="t04">
        <td align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFCC"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#CCCCCC"><strong>Mudan&ccedil;as agendadas</strong></td>
      </tr>
      <tr>
        <td align="left" bgcolor="#FFFFCC"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr class="t04">
            <td width="26%" align="center"><b>UNIDADE</b></td>
            <td width="29%" align="center"><b>DATA</b></td>
            <td width="45%" align="center"><b>HORA</b></td>
            </tr>
          <?php do { ?>
            <tr bgcolor="<?php echo ($ac_sw3++%2==0)?"#EDEDED":"#FFFFCC"; ?>" class="t04" onmouseover="this.style.backgroundColor='#66CCFF'" onmouseout="this.style.backgroundColor=''">
              <td align="center"><?php echo $row_agendamudanca['id_unidade']; ?></td>
              <td align="center"><?php
			  
			  
			    $data_noticia_da_hora = $row_agendamudanca['eventDate']; //hora vinda do servidor

				$data=explode("-",$data_noticia_da_hora);
				$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
				$dia = substr($dataFinal,0,2);    // retorna "bcdef"
				$mes = substr($dataFinal, 3, 2); // retorna "bcd"
				$ano = substr($dataFinal, 6, 4); // retorna "abcd"
				$dataok = $dia ."/". $mes . "/". $ano;
	            echo $dataok;
				
				
				?></td>
              <td align="center"><?php echo $row_agendamudanca['dataehora']; ?></td>
            </tr>
            <?php } while ($row_agendamudanca = mysql_fetch_assoc($agendamudanca)); ?>
        </table></td>
      </tr>
      <tr>
        <td align="left" bgcolor="#FFFFCC">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#CCCCCC"><strong>&Aacute;reas comuns agendadas</strong></td>
      </tr>
      <tr>
        <td align="center" bgcolor="#FFFFCC"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr class="t04">
            <td width="26%" align="center"><b>UNIDADE</b></td>
            <td width="29%" align="center"><b>&Aacute;REA</b></td>
            <td width="22%" align="center"><b>DATA</b></td>
            <td width="23%" align="center"><b>HORA</b></td>
            </tr>
          <?php do { ?>
            <tr bgcolor="<?php echo ($ac_sw2++%2==0)?"#EDEDED":"#FFFFCC"; ?>" class="t04" onmouseover="this.style.backgroundColor='#66CCFF'" onmouseout="this.style.backgroundColor=''">
              <td align="center"><?php echo $row_agendamentoarea['id_unidade']; ?></td>
              <td align="center"><?php 
			  
			  
								mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
								$query_nomearea = "SELECT * FROM areas_nome WHERE areas_nome.id_area = ".$row_agendamentoarea['id_area'];
								$nomearea = mysql_query($query_nomearea, $gf_souto_conect) or die(mysql_error());
								$row_nomearea = mysql_fetch_assoc($nomearea);
								$totalRows_nomearea = mysql_num_rows($nomearea);
								
								
								echo $row_nomearea['nome_area'];

?></td>
              <td align="center"><?php
			  
			   
			  $data_noticia_da_hora = $row_agendamentoarea['eventDate']; //hora vinda do servidor

				$data=explode("-",$data_noticia_da_hora);
    	$dataFinal=$data[2].'/'.$data[1].'/'.$data[0];
   	//echo($dataFinal);
	//  11 19:28:38/05/2010
	$dia = substr($dataFinal,0,2);    // retorna "bcdef"
        $mes = substr($dataFinal, 3, 2); // retorna "bcd"
        $ano = substr($dataFinal, 6, 4); // retorna "abcd"
	$dataok = $dia ."/". $mes . "/". $ano;
	            echo $dataok;
				
				?></td>
              <td align="center"><?php echo $row_agendamentoarea['de']; ?></td>
            </tr>
            <?php } while ($row_agendamentoarea = mysql_fetch_assoc($agendamentoarea)); ?>
        </table></td>
      </tr>
      <tr>
        <td align="right" bgcolor="#FFFFCC">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFCC">&nbsp;</td>
  </tr>
                </table>

              </div></td>
              <td valign="top"><div id="enquete"><?php //require_once('iframe_enquete.php'); ?><iframe src="enquete.php?id_cond=<?php echo $id_cond; ?>" width="100%" height="400" scrolling="no" frameborder="0"  allowtransparency="true"></iframe></div></td>
            </tr>
            <tr>
              <td valign="top" class="t07">&nbsp;</td>
              <td width="386" valign="top" class="t07">&nbsp;</td>
            </tr>
            <!--<tr>
              <td colspan="2" valign="top" class="t07"><img src="news_subscribe.png" width="32" height="32" align="absmiddle" />&nbsp;&nbsp;CLASSIFICADOS - <?php echo $row_condominio['nome_cond']; ?></td>
            </tr>-->
            <!--<tr>
              <td colspan="2" valign="top"><span class="t04">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;An&uacute;ncie, venda, alugue ou divulgue &eacute; gr&aacute;tis</span></td>
            </tr>-->
            <tr>
              <td colspan="2" align="center" valign="top"><!--<div id="classificados"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?php do { ?><tr bgcolor="<?php echo ($ac_sw1++%2==0)?"#CCCCCC":"#F1F1F1"; ?>" onmouseout="this.style.backgroundColor=''" onmouseover="this.style.backgroundColor='#FFFF99'">
                      <td>
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="99" rowspan="3" align="center" valign="middle"><img src="classificados_condominios/<?php echo $row_classificado['foto']; ?>.jpg" width="70" height="70" /></td>
                              <td width="651" align="left" valign="top"><b class="t03"><?php echo $row_classificado['chamada']; ?></b></td>
                            </tr>
                            <tr>
                              <td height="50" valign="top" class="t03"><?php echo $row_classificado['texto_clas']; ?></td>
                            </tr>
                            <tr>
                              <td align="left" valign="top" class="t04"><b>Contatos: <?php echo $row_classificado['nome']; ?>, unid. <?php echo $row_classificado['unidade']; ?>, Fone: <?php echo $row_classificado['telefone']; ?></b></td>
                            </tr>
                          </table>
                      </td>
                    </tr><?php } while ($row_classificado = mysql_fetch_assoc($classificado)); ?>
                  </table><br />
                <a href="#">Clique aqui para anunciar</a></div>--></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td colspan="2">&nbsp;<span class="t07"><!--INFORMATIVOS--></span></td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="2"><div id="link_informativo"><!--<!--<script language="JavaScript" type="text/JavaScript" charset="iso-8859-1" src="http://superlogica.com/js/?noticias"></script>--></div></td>
            </tr>
          </table>
        </div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape"><?php include_once('rodape2.php'); ?></div>
  </div>
</div>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($condominio);

mysql_free_result($mural);

/*mysql_free_result($cliente);*/

mysql_free_result($unidade_cliente);

mysql_free_result($aviso_geral);

mysql_free_result($documentos);

mysql_free_result($classificado);

mysql_free_result($agendamudanca);

mysql_free_result($agendamentoarea);

mysql_free_result($nomearea);
?>
