<?php require_once('Connections/gf_souto_conect.php'); ?>
<?php
//MX Widgets3 include
require_once('includes/wdg/WDG.php');

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_titulo = "SELECT * FROM titulo";
$titulo = mysql_query($query_titulo, $gf_souto_conect) or die(mysql_error());
$row_titulo = mysql_fetch_assoc($titulo);
$totalRows_titulo = mysql_num_rows($titulo);

mysql_select_db($database_gf_souto_conect, $gf_souto_conect);
$query_politica = "SELECT * FROM politica_de_privacidade";
$politica = mysql_query($query_politica, $gf_souto_conect) or die(mysql_error());
$row_politica = mysql_fetch_assoc($politica);
$totalRows_politica = mysql_num_rows($politica);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:wdg="http://ns.adobe.com/addt">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $row_titulo['titulo']; ?></title>
<link href="css_gf_souto.css" rel="stylesheet" type="text/css" />
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
		<!--INICIO JQUERY DS DIGITAL  -->
		<script src="jquery/jquery-1.6.1.min.js" type="text/javascript"></script>
        <script src="jquery/DS_Digital_Funcoes.js" type="text/javascript"></script>
        <!--FIM JQUERY DS DIGITAL-->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-12239726-19']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script src="includes/common/js/base.js" type="text/javascript"></script>
<script src="includes/common/js/utility.js" type="text/javascript"></script>
<script type="text/javascript" src="includes/wdg/classes/MXWidgets.js"></script>
<script type="text/javascript" src="includes/wdg/classes/MXWidgets.js.php"></script>
<script type="text/javascript" src="includes/wdg/classes/MaskedInput.js"></script>
<link href="includes/skins/mxkollection3.css" rel="stylesheet" type="text/css" media="all" />
</head>

<body>
<div id="conteiner_topo">
  <div id="topo">
    <div id="logomarca">
      <p><a href="./" title="GF SOUTO"><img src="imagens/logo-marca-gf-souto.png" alt="GF SOUTO" width="330" height="191" border="0" /></a></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p class="t05">Quando voc&ecirc; precisa, 
  <br />
  n&oacute;s estamos aqui. </p>
</div>
    <div id="menu"> 
      <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="600" height="355">
        <param name="movie" value="menu_topo_gfsouto.swf" />
        <param name="quality" value="high" />
        <param name="wmode" value="transparent" />
        <param name="swfversion" value="6.0.65.0" />
        <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don�t want users to see the prompt. -->
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
        <!--[if !IE]>-->
        <object type="application/x-shockwave-flash" data="menu_topo_gfsouto.swf" width="600" height="355">
          <!--<![endif]-->
          <param name="quality" value="high" />
          <param name="wmode" value="transparent" />
          <param name="swfversion" value="6.0.65.0" />
          <param name="expressinstall" value="Scripts/expressInstall.swf" />
          <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
          <div>
            <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
            <p><a href="http://www.adobe.com/go/getflashplayer">CLIQUE AQUI PARA INSTALAR E USAR ESTE APLICATIVO.</a></p>
          </div>
          <!--[if !IE]>-->
        </object>
        <!--<![endif]-->
      </object>
    </div>
  </div>
  <div id="centro">
    <div id="conteudo">
        <div id="titulo_informativo">Solicita&ccedil;&atilde;o de proposta de administra&ccedil;&atilde;o de condom&iacute;nio</div>
        <div id="texto_bemvindo">use o formul&aacute;rio abaixo para solicitar sua proposta de administra&ccedil;&atilde;o, preencha todos os campos.</div>
      	<div id="conteudocentro">
      	  <form action="solicite_proposta_ok.php" method="post" id="proposta" name="proposta"  onsubmit="return checa_proposta()"><table width="970" border="0" cellspacing="0" cellpadding="0">
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td>Nome*</td>
      	      <td><label>
      	        <input name="proposta_nome" type="text" class="input" id="proposta_nome" />
   	          </label></td>
   	        </tr>
      	    <tr>
      	      <td>E-mail*</td>
      	      <td><input name="proposta_email" type="text" class="input" id="proposta_email" /></td>
   	        </tr>
      	    <tr>
      	      <td>Telefone*</td>
      	      <td><input name="proposta_telefone" class="input" id="proposta_telefone" value="" wdg:subtype="MaskedInput" wdg:mask="(99) 9999 - 9999 (99) 9999 - 9999 (99) 9999 - 9999" wdg:restricttomask="no" wdg:type="widget" />
(99) 9999 - 9999</td>
   	        </tr>
      	    <tr>
      	      <td>Assunto*</td>
      	      <td><input name="assunto" type="text" class="input" id="assunto" value="Proposta para administra&ccedil;&atilde;o" /></td>
   	        </tr>
      	    <tr>
      	      <td>Mensagem*</td>
      	      <td><label>
      	        <textarea name="proposta_mensagem" id="proposta_mensagem" cols="45" rows="5"></textarea>
   	          </label></td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td><table width="360" border="0" align="left" cellpadding="0" cellspacing="0">
      	        <tr>
      	          <td><label>
      	            <input name="button" type="submit" class="botao" id="button" value="Enviar" />
    	            </label></td>
      	          <td><label>
      	            <input name="button2" type="reset" class="botao" id="button2" value="Limpar" />
    	            </label></td>
    	          </tr>
   	          </table></td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td class="t04">(*) campos obrigat&oacute;rios</td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
      	    <tr>
      	      <td>&nbsp;</td>
      	      <td>&nbsp;</td>
   	        </tr>
   	      </table></form>
      	</div>
    </div>
    <div id="linha"><?php include_once('menu_rodape.php'); ?></div>
  </div>
  <div id="rodape_fundo">
    <div id="rodape">
    <?php include_once('rodape2.php'); ?>
    </div>
  </div>
</div>
<script type="text/javascript">
<!--
swfobject.registerObject("FlashID");
//-->
</script>
</body>
</html>
<?php
mysql_free_result($titulo);

mysql_free_result($politica);
?>
